<?php

use \kartik\widgets\ActiveForm;
use yii\helpers\Html;
use kartik\builder\Form;
use yii\helpers\ArrayHelper;
use common\modules\portal\models\Uom;

/* @var $this yii\web\View */
/* @var $model common\modules\accounts\models\TrCode */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="uom-form">

    <?php
    $form = ActiveForm::begin([
                'type' => ActiveForm::TYPE_VERTICAL,
                'formConfig' => ['labelSpan' => 4],]);

    echo Form::widget([
        'model' => $model,
        'form' => $form,
        'columns' => 3,
        'attributes' => [
            'name' => ['type' => Form::INPUT_TEXT, 'value' => 0,],
            'prefix' => ['type' => Form::INPUT_TEXT, 'value' => 0,],
            'part_of' => [
                'type' => Form::INPUT_DROPDOWN_LIST,
                'items' => [ArrayHelper::map(Uom::find()->all(), 'id', 'name')]
            ], 
            'part_of_factor' => ['type' => Form::INPUT_TEXT, 'value' => 0,],
        ]
    ]);
    ?> 

    <div class="form-group">
<?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>

</div>
