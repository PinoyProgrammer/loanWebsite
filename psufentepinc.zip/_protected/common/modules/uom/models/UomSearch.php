<?php

namespace common\modules\uom\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\modules\uom\models\Uom;

/**
 * UomSearch represents the model behind the search form about `common\modules\portal\models\Uom`.
 */
class UomSearch extends Uom
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'part_of', 'part_of_factor'], 'integer'],
            [['name'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Uom::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'part_of' => $this->part_of,
            'part_of_factor' => $this->part_of_factor,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name]);

        return $dataProvider;
    }
}
