<?php

namespace common\modules\uom\models;

use Yii;

/**
 * This is the model class for table "{{%unit_of_measure}}".
 *
 * @property integer $id
 * @property string $name
 * @property integer $part_of
 * @property string $part_of_factor
 * @property string $prefix
 */
class Uom extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%unit_of_measure}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['part_of'], 'integer'],
            [['part_of_factor'], 'number'],
            [['name'], 'string', 'max' => 50],
            [['prefix'], 'string', 'max' => 3],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'part_of' => Yii::t('app', 'Part Of'),
            'part_of_factor' => Yii::t('app', 'Part Of Factor'),
            'prefix' => Yii::t('app', 'Prefix'),
        ];
    }

    public function getPartOf() {
        return $this->hasOne(Uom::className(), ['id' => 'part_of']);
    }

}
