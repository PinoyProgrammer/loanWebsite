<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\modules\option\models\OptionLine */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="option-line-form">
    <?php
    $form = ActiveForm::begin();
    echo Form::widget([
        'model' => $model,
        'form' => $form,
        'columns' => 3,
        'attributes' => [
            'parent_id' => ['type' => Form::INPUT_DROPDOWN_LIST, 
                'items' => [ArrayHelper::map(\common\modules\option\models\OptionLine::find()->all(), 'option_line_id', 'description')]],
            'option_line_code' => ['type' => Form::INPUT_TEXT,],
            'description' => ['type' => Form::INPUT_TEXT,],
            'priority' => ['type' => Form::INPUT_TEXT,],
            'description' => ['type' => Form::INPUT_TEXT,],
            'status' => ['type' => Form::INPUT_CHECKBOX,],
        ]
    ]);
    ?>
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'option_line_code')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'description')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'priority')->textInput() ?>

    <?= $form->field($model, 'status')->textInput() ?>

    <?= $form->field($model, 'created_at')->textInput() ?>

    <?= $form->field($model, 'updated_at')->textInput() ?>

    <?= $form->field($model, 'created_by')->textInput() ?>

    <?= $form->field($model, 'updated_by')->textInput() ?>

    <?= $form->field($model, 'parent_id')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
