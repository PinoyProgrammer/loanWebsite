<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\modules\option\models\OptionLine */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Option Line',
]) . $model->option_line_id;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Option Lines'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->option_line_id, 'url' => ['view', 'id' => $model->option_line_id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="option-line-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
