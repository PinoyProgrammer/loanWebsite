<?php

use yii\helpers\Html;
use kartik\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel common\modules\option\models\OptionLineSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Option Lines');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="option-line-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Option Line'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'resizableColumns' => false,
        'showPageSummary' => false,
        'headerRowOptions' => ['class' => 'kartik-sheet-style'],
        'filterRowOptions' => ['class' => 'kartik-sheet-style'],
        'responsive' => true,
        'hover' => true,
        'panel' => [
            'heading' => '<h3 class="panel-title">Option Lines</h3>',
            'type' => 'primary',
            'showFooter' => false
        ],
        'columns' => [
            [
                'attribute' => 'parent_id',
                'value' => 'optionParent.description',
                'filter' => \yii\helpers\ArrayHelper::map(\common\modules\option\models\OptionLine::find()->all(), 'option_line_id', 'description')
            ],
            'description',
            'status:boolean',
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]);
    ?>

</div>
