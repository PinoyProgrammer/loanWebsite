<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\modules\option\models\OptionHeader */

$this->title = Yii::t('app', 'Create Option Header');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Option Headers'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="option-header-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
