<?php

use yii\helpers\Html;
use kartik\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel common\modules\option\models\OptionHeaderSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Option Headers');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="option-header-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Option Header'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'resizableColumns' => false,
        'showPageSummary' => false,
        'headerRowOptions' => ['class' => 'kartik-sheet-style'],
        'filterRowOptions' => ['class' => 'kartik-sheet-style'],
        'responsive' => true,
        'hover' => true,
        'panel' => [
            'heading' => '<h3 class="panel-title"> Option Header</h3>',
            'type' => 'primary',
            'showFooter' => false
        ],
        'columns' => [
            [
                'attribute' => 'option_header_id',
            ],
            [
                'attribute' => 'option_type',
            ],
            ['attribute' => 'description',
            ],
            [
                'attribute' => 'status',
                'format' => 'boolean',
                'filter' => ['1' => 'Yes', '0' => 'No']
            ],
            ['class' => 'kartik\grid\ActionColumn'],
        ],
    ]);
    ?>

</div>
