<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\modules\option\models\OptionHeaderSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="option-header-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'option_header_id') ?>

    <?= $form->field($model, 'access_level') ?>

    <?= $form->field($model, 'option_type') ?>

    <?= $form->field($model, 'description') ?>

    <?= $form->field($model, 'module_code') ?>

    <?php // echo $form->field($model, 'option_assignments') ?>

    <?php // echo $form->field($model, 'efid') ?>

    <?php // echo $form->field($model, 'status') ?>

    <?php // echo $form->field($model, 'rev_enabled') ?>

    <?php // echo $form->field($model, 'rev_number') ?>

    <?php // echo $form->field($model, 'created_by') ?>

    <?php // echo $form->field($model, 'creation_date') ?>

    <?php // echo $form->field($model, 'last_update_by') ?>

    <?php // echo $form->field($model, 'last_update_date') ?>

    <?php // echo $form->field($model, 'company_id') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
