<?php

namespace common\modules\option\models;

use Yii;

/**
 * This is the model class for table "{{%option_line}}".
 *
 * @property integer $option_line_id
 * @property string $option_line_code
 * @property string $description
 * @property integer $priority
 * @property integer $status
 * @property string $created_at
 * @property string $updated_at
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $parent_id
 */
class OptionLine extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%option_line}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['priority', 'status'], 'required'],
            [['priority', 'status', 'created_by', 'updated_by', 'parent_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['option_line_code', 'description'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'option_line_id' => Yii::t('app', 'Option Line ID'),
            'option_line_code' => Yii::t('app', 'Option Line Code'),
            'description' => Yii::t('app', 'Description'),
            'priority' => Yii::t('app', 'Priority'),
            'status' => Yii::t('app', 'Status'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
            'parent_id' => Yii::t('app', 'Parent ID'),
        ];
    }

    public function getOptionParent() {
        return $this->hasOne(OptionLine::className(), ['option_line_id' => 'parent_id']);
    }

    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = Yii::$app->user->id;
            $this->created_at = date("Y-m-d H:i");
            $this->update_by = Yii::$app->user->id;
            $this->updated_at = date("Y-m-d H:i");
            return true;
        } else {
            $this->update_by = Yii::$app->user->id;
            $this->updated_at = date("Y-m-d H:i");
            return true;
        }
    }

}
