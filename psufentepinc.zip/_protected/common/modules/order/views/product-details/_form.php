<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $productDetail common\modules\order\models\ProductDetails */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="product-details-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($productDetail, 'product_id')->textInput() ?>

    <?= $form->field($productDetail, 'p_height')->textInput() ?>

    <?= $form->field($productDetail, 'p_width')->textInput() ?>

    <?= $form->field($productDetail, 'p_length')->textInput() ?>

    <?= $form->field($productDetail, 'unit_cost')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($productDetail->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $productDetail->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
