<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $product common\modules\order\models\Products */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="products-form">

    <?php $form = ActiveForm::begin(); ?>
    

    <?= $form->field($product, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($product, 'is_stock_item')->checkbox() ?>

    <?= $form->field($product, 'is_active')->checkbox() ?>

    
    <?= $form->field($productDetail, 'category_id')->hiddenInput(['value'=>1])->label(false); ?>
    <?= $form->field($productDetail, 'p_height')->textInput() ?>

    <?= $form->field($productDetail, 'p_width')->textInput() ?>

    <?= $form->field($productDetail, 'p_length')->textInput() ?>

    <?= $form->field($productDetail, 'unit_cost')->textInput() ?>
    <?= $form->field($productDetail, 'product_id')->hiddenInput(['value'=>$productDetail->product_id])->label(false); ?>
    <div class="form-group">
        <?= Html::submitButton($product->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $product->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
