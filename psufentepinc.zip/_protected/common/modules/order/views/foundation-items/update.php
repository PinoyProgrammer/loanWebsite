<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $product common\modules\order\models\Products */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
            'modelClass' => 'Products',
        ]) . $product->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Products'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $product->name, 'url' => ['view', 'id' => $product->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="products-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?=
    $this->render('_form', [
        'product' => $product,
        'productDetail' => $productDetail,
    ])
    ?>

</div>
