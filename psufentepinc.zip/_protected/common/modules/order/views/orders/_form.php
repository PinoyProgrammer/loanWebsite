<?php

use common\modules\order\models\Orders;
use common\modules\order\models\OrderDetails;

$this->title = "Estimator Software for Costing Construction";
$all_products = \common\modules\order\models\Products::find()->where(["is_active" => 1])->all();

function select_product($products, $cat_id, $id = 0) {
    $select = '<option value="">Select</option>';

    foreach ($products as $product) {
        if ($cat_id == $product->category_id) {
            $select.='<option value="' . $product->id . '" ' . ($id == $product->id ? "selected" : '') . '>' . $product->name . '</option>';
        }
    }
    return $select;
}

$roof = $products = \common\modules\order\models\ProductDetails::find()->where(["product_id" => 147])->one();
$wall = $products = \common\modules\order\models\ProductDetails::find()->where(["product_id" => 148])->one();
$floor = $products = \common\modules\order\models\ProductDetails::find()->where(["product_id" => 149])->one();
$id = $model->id;
$panels = OrderDetails::find()->where(["p_type" => 2, 'order_id' => $id])->all();
$windows = OrderDetails::find()->where(["p_type" => 3, 'order_id' => $id])->all();
$doors = OrderDetails::find()->where(["p_type" => 4, 'order_id' => $id])->all();
$claddings = OrderDetails::find()->where(["p_type" => 5, 'order_id' => $id])->all();
$others = OrderDetails::find()->where(["p_type" => 6, 'order_id' => $id])->all();
$relatives = OrderDetails::find()->where(["p_type" => 7, 'order_id' => $id])->all();
?>

<div id="new-qoute">
    <form class="form-horizontal" id="form1">
        <div class="col-md-10">
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Dimensions</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="table-dimensions">
                        <thead><tr><th>Date</th><th>Length</th><th>Width</th><th>Height</th></tr></thead>
                        <tbody>
                            <tr>
                                <td>
                                    <input type='text' id='datetimepicker8' class="form-control" name="txdate" value="<?= $model->txdate ?>"/>
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="d-length" value="<?= $model->o_length ?>" name="d-length" onchange="find_no_panels()">
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="d-width" value="<?= $model->o_width ?>" name="d-width" onchange="find_no_panels()">
                                </td>
                                <td>
                                    <input type="text" class="form-control" id="d-height" value="<?= $model->o_height ?>" name="d-height" onchange="find_no_panels()">
                                </td>
                            </tr>


                        </tbody>
                    </table>

                </div>
            </div>
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Windows</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"  id="table-3">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Length</th>
                                <th>Width</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th><span class="btn btn-info" onclick="addWindows()" title="Add Windows"><i class="fa fa-plus"></i></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            $i = 0;
                            $tableIndex = 3;
                            foreach ($windows as $window) {
                                ?>
                                <tr>   
                                    <td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this, 3)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>
                                    <td><?= $i + 1 ?></td>
                                    <td>
                                        <select type="text" class="form-control" name="table-3-id-<?= $i ?>" onchange="calculatePanels(this, 3,<?= $i ?>)">
                                            <?= select_product($all_products, 3, $window->product_id) ?>
                                        </select>
                                    </td>
                                    <td><input type="text" class="form-control" name="table-3-l-<?= $i ?>"   size="4" readonly="readonly" value="<?= $window->p_length ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-3-w-<?= $i ?>"   size="6" readonly="readonly" value="<?= $window->p_width ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-3-u-<?= $i ?>"   size="6" readonly="readonly" value="<?= $window->unit_cost ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-3-q-<?= $i ?>"   size="6"  value="<?= $window->qty ?>"  onchange="find_row_totals(3,<?= $i ?>)"/></td>
                                    <td><input type="text" class="form-control" name="table-3-t-<?= $i ?>"   size="6" readonly="readonly" value="<?= $window->total ?>"/></td>
                                    <td></td>
                                </tr>

                                <?php
                                $total+=$window->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="5">
                                    Total
                                </th>
                                <th>

                                    <input type="hidden" name="table-value-3" name="table-value-3" value="0.00"/>
                                    <span id="table-total-3"><?=$total?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Doors</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"  id="table-4">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Length</th>
                                <th>Width</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th><span class="btn btn-info" onclick="addDoors()" title="Add Doors"><i class="fa fa-plus"></i></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php
                            $total = 0;
                            $i = 0;
                            $tableIndex = 4;
                            foreach ($doors as $door) {
                                ?>
                                <tr>   
                                    <td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this, 4)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>
                                    <td><?= $i + 1 ?></td>
                                    <td>
                                        <select type="text" class="form-control" name="table-4-id-<?= $i ?>" onchange="calculatePanels(this, 4,<?= $i ?>)">
                                            <?= select_product($all_products, 4, $door->product_id) ?>
                                        </select>
                                    </td>
                                    <td><input type="text" class="form-control" name="table-4-l-<?= $i ?>"   size="4" readonly="readonly" value="<?= $door->p_length ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-4-w-<?= $i ?>"   size="6" readonly="readonly" value="<?= $door->p_width ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-4-u-<?= $i ?>"   size="6" readonly="readonly" value="<?= $door->unit_cost ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-4-q-<?= $i ?>"   size="6"  value="<?= $door->qty ?>"  onchange="find_row_totals(4,<?= $i ?>)"/></td>
                                    <td><input type="text" class="form-control" name="table-4-t-<?= $i ?>"   size="6" readonly="readonly" value="<?= $door->total ?>"/></td>
                                    <td></td>
                                </tr>

                                <?php
                                $total+=$door->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="5">
                                    Total
                                </th>
                                <th>

                                    <input type="hidden" name="table-value-4" name="table-value-4" value="<?=$total?>"/>
                                    <span id="table-total-4"><?=$total?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Additional Components</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"   id="table-6">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Length</th>
                                <th>Width</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th><span class="btn btn-info" onclick="addOther()" title="Add Additional Components"><i class="fa fa-plus"></i></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php
                            $total = 0;
                            $i = 0;
                            $tableIndex = 6;
                            foreach ($others as $other) {
                                ?>
                                <tr>   
                                    <td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this, 6)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>
                                    <td><?= $i + 1 ?></td>
                                    <td>
                                        <select type="text" class="form-control" name="table-6-id-<?= $i ?>" onchange="calculatePanels(this, 6,<?= $i ?>)">
                                            <?= select_product($all_products, 6, $other->product_id) ?>
                                        </select>
                                    </td>
                                    <td><input type="text" class="form-control" name="table-6-l-<?= $i ?>"   size="4" readonly="readonly" value="<?= $other->p_length ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-6-w-<?= $i ?>"   size="6" readonly="readonly" value="<?= $other->p_width ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-6-u-<?= $i ?>"   size="6" readonly="readonly" value="<?= $other->unit_cost ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-6-q-<?= $i ?>"   size="6"  value="<?= $other->qty ?>"  onchange="find_row_totals(6,<?= $i ?>)"/></td>
                                    <td><input type="text" class="form-control" name="table-6-t-<?= $i ?>"   size="6" readonly="readonly" value="<?= $other->total ?>"/></td>
                                    <td></td>
                                </tr>

                                <?php
                                $total+=$other->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="5">
                                    Total
                                </th>
                                <th>

                                    <input type="hidden" name="table-value-6" name="table-value-6" value="<?=$total?>"/>
                                    <span id="table-total-6"><?=$total?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Relative Costs</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"  id="table-7">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th><span class="btn btn-info" onclick="addRelative()" title="Add Relative Costs"><i class="fa fa-plus"></i></span></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php
                            $total = 0;
                            $i = 0;
                            $tableIndex = 7;
                            foreach ($relatives as $relative) {
                                ?>
                                <tr>   
                                    <td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this, 7)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>
                                    <td><?= $i + 1 ?></td>
                                    <td>
                                        <select type="text" class="form-control" name="table-7-id-<?= $i ?>" onchange="calculatePanels(this, 7,<?= $i ?>)">
                                            <?= select_product($all_products, 7, $relative->product_id) ?>
                                        </select>
                                    </td>
                                   <td><input type="text" class="form-control" name="table-7-u-<?= $i ?>"   size="6" readonly="readonly" value="<?= $relative->unit_cost ?>"  /></td>
                                    <td><input type="text" class="form-control" name="table-7-q-<?= $i ?>"   size="6"  value="<?= $relative->qty ?>"  onchange="find_row_totals(7,<?= $i ?>)"/></td>
                                    <td><input type="text" class="form-control" name="table-7-t-<?= $i ?>"   size="6" readonly="readonly" value="<?= $relative->total ?>"/></td>
                                    <td></td>
                                </tr>

                                <?php
                                $total+=$relative->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="3">
                                    Total
                                </th>
                                <th>

                                    <input type="hidden" name="table-value-7" name="table-value-7" value="<?=$total?>"/>
                                    <span id="table-total-7"><?=$total?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="panel panel-success">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <td>
                                <span class="btn btn-info" onclick="save_order()">Process <i class="fa fa-save" title="Save" aria-hidden="true"></i></span>
                            </td>
                        </tr>
                    </table> 
                </div>
            </div>

        </div>
        <div class="col-md-2">
            <div style="position: fixed;width: 200px" >
                <div class="panel panel-success">
                    <!-- Default panel contents -->
                    <div class="panel-heading"><h4 class="sub-header">Total Costs</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered"  id="table-8">
                            <tbody>
                                <tr>
                                    <th>Quote Total</th>
                                    <td>
                                        &euro;<span id="total-quote">0.00</span>
                                        <input type="hidden" name="roof" id="roof" value="<?= $roof->unit_cost ?>"/>
                                        <input type="hidden" name="id" id="id" value="<?= $id ?>"/>
                                        <input type="hidden" name="floor" id="floor" value="<?= $floor->unit_cost ?>"/>
                                        <input type="hidden" name="wall" id="wall" value="<?= $wall->unit_cost ?>"/>
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <script type="text/javascript">
        $(function () {
            $('#datetimepicker8').datetimepicker({format: 'DD-MM-YYYY'});
            find_totals();
            if($('#table-3 tbody tr').length===0){
                addWindows();
            }
            if($('#table-4 tbody tr').length===0){
                addDoors();
            }
            if($('#table-6 tbody tr').length===0){
                addOther();
            }
            if($('#table-7 tbody tr').length===0){
                addRelative();
            }
        });
        function resetRows(tableIndex) {
            var n = $("#table-" + tableIndex + " tbody tr").length;
            for (var i = 0; i < n; i++) {
                var row = $("#table-" + tableIndex + " tbody tr:eq(" + i + ")");
                $('td:eq(1)', row).html(i + 1);
            }
        }

        function removeThisRow(source, tableIndex) {
            var index = $(source).closest('tr').index();
            var row = $("#table-" + tableIndex + " tbody tr:eq(" + index + ")");
            if (confirm("Do you want to remove row?")) {
                row.remove();
                resetRows(tableIndex);
                find_table_totals(tableIndex);
            }
        }
        function addPanels() {
            var n = $('#table-2 tbody tr').length;
            var tds = "";
            tds += '<tr>';// Create a new row    
            if (n !== 0) {

                tds += '<td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this,2)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>\n';
            } else {
                tds += '<td>&nbsp</td>\n';
            }
            tds += '<td>' + (parseInt(n) + 1) + '</td>';
            tds += '<td><select type="text" name="table-2-id-' + n + '" onchange="calculatePanels(this,2,' + n + ')"><?= select_product($all_products, 2, 0) ?></select></td>\n';
            tds += '<td><input type="text" name="table-2-l-' + n + '"   size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-2-w-' + n + '"   size="10" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-2-u-' + n + '"   size="10" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-2-q-' + n + '"   size="10" value="1" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-2-t-' + n + '"   size="10" readonly="readonly"/></td>\n';
            tds += '\n</tr>';
            $('#table-2 tbody').append(tds);

        }
        function find_row_totals(tableIndex, rowIndex) {
            var row = $("#table-" + tableIndex + " tbody tr:eq(" + rowIndex + ")");
            var qty = parseFloat($('td input[name=table-' + tableIndex + '-q-' + rowIndex + ']', row).val());
            var cost = parseFloat($('td input[name=table-' + tableIndex + '-u-' + rowIndex + ']', row).val());
            var total = 0;
            if (!isNaN(qty) && !isNaN(cost)) {
                total = cost * qty;
            }
            $('td input[name=table-' + tableIndex + '-t-' + rowIndex + ']', row).val(total.toFixed(2));
            find_table_totals(tableIndex);
        }
        function find_table_totals(tableIndex) {
            var n = $("#table-" + tableIndex + " tbody tr").length;
            var total = 0;
            for (var i = 0; i < n; i++) {
                var row = $("#table-" + tableIndex + " tbody tr:eq(" + i + ")");
                var row_total = parseFloat($('td input[name^=table-' + tableIndex + '-t-]', row).val());
                if (!isNaN(row_total)) {
                    total += row_total;
                }
            }
            $('#table-total-' + tableIndex).html(total.toFixed(2));
            $('#table-value-' + tableIndex).val(total.toFixed(2));
            find_totals();

        }
        function find_totals() {
            var total = 0;
            var roof = parseFloat($("#roof").val());
            var wall = parseFloat($("#wall").val());
            var floor = parseFloat($("#floor").val());
            var dlength = parseFloat($("#d-length").val());
            var dwidth = parseFloat($("#d-width").val());
            var dheight = parseFloat($("#d-height").val());
            var floor_cost = 0;
            var wall_cost = 0;
            var roof_cost = 0;
            if (!isNaN(dlength) && !isNaN(dwidth) && !isNaN(dheight) && dheight > 0 && dlength > 0 && dwidth > 0) {
                if (!isNaN(dlength) && !isNaN(dwidth)) {
                    floor_cost = dlength * dwidth * floor;
                }
                if (!isNaN(dlength) && !isNaN(dwidth) && !isNaN(dheight)) {
                    wall_cost = (dlength + dwidth) * 2 * dheight * wall;
                }
                if (!isNaN(dlength) && !isNaN(dwidth) && !isNaN(roof)) {
                    roof_cost = ((dlength + 0.4) * (dwidth + 0.8)) * roof;
                }
            }
            for (var i = 2; i <= 7; i++) {
                var row_total = parseFloat($('#table-total-' + i).html());
                if (!isNaN(row_total)) {
                    total += row_total;
                }
            }
            total += roof_cost + floor_cost + wall_cost;
            $('#total-quote').html(total.toFixed(2));
        }

        function find_no_panels() {
            var d_length = parseFloat($("input[name=d-length]").val());
            var d_width = parseFloat($("input[name=d-width]").val());
            var d_height = parseFloat($("input[name=d-height]").val());

            var p_length = parseFloat($("input[name=table-2-l-0]").val());
            var p_width = parseFloat($("input[name=table-2-w-0]").val());
            var p_height = parseFloat($("input[name=table-2-h-0]").val());
            var panels = 0;
            if (isNaN(d_length) && isNaN(d_width) && isNaN(p_width)) {

            } else {
                var total_length = 2 * (d_length + d_width);
                panels = total_length / p_width;
            }
            var n = $('#table-4 tbody tr').length;
            var doors = 0;
            for (var i = 0; i < n; i++) {
                var row = $("#table-" + 4 + " tbody tr:eq(" + i + ")");
                var qty = parseFloat($('td input[name^=table-' + 4 + '-q-]', row).val());
                doors += (isNaN(qty)) ? 0 : qty;

            }
            var windows = 0;
            var n = $('#table-3 tbody tr').length;
            for (var i = 0; i < n; i++) {
                var row = $("#table-" + 3 + " tbody tr:eq(" + i + ")");
                var qty = parseFloat($('td input[name^=table-' + 3 + '-q-]', row).val());
                windows += (isNaN(qty)) ? 0 : qty;

            }
            var panels_minus_doors = panels - doors;
            if (windows > 0) {
                windows = windows / 2;
            }
            var panels_minus_windows = panels_minus_doors - windows;
            $("input[name=table-2-q-0]").val(isNaN(qty) ? 0.00 : panels_minus_windows.toFixed());
            find_row_totals(2, 0);

        }
        function addWindows() {
            var n = $('#table-3 tbody tr').length;
            var tds = "";
            tds += '<tr>';// Create a new row    
            if (n !== 0) {

                tds += '<td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this,3)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>\n';
            } else {
                tds += '<td>&nbsp</td>\n';
            }
            tds += '<td>' + (parseInt(n) + 1) + '</td>';
            tds += '<td><select type="text" class="form-control" name="table-3-id-' + n + '" onchange="calculatePanels(this,3,' + n + ')"><?= select_product($all_products, 3, 0) ?></select></td>\n';
            tds += '<td><input type="text" name="table-3-l-' + n + '" class="form-control"   size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" class="form-control" name="table-3-w-' + n + '"   size="6" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" class="form-control" name="table-3-u-' + n + '"   size="6" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" class="form-control" name="table-3-q-' + n + '"   size="6"   value="1"  onchange="find_row_totals(3,' + n + ')"/></td>\n';
            tds += '<td><input type="text" class="form-control" name="table-3-t-' + n + '"   size="6" readonly="readonly"/></td>\n';
            tds += '<td>&nbsp</td>\n';
            tds += '\n</tr>';

            $('#table-3 tbody').append(tds);

        }
        function addDoors() {
            var n = $('#table-4 tbody tr').length;
            var tds = "";
            tds += '<tr>';// Create a new row    
            if (n !== 0) {

                tds += '<td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this,4)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>\n';
            } else {
                tds += '<td>&nbsp</td>\n';
            }
            tds += '<td>' + (parseInt(n) + 1) + '</td>';
            tds += '<td><select type="text" name="table-4-id-' + n + '" class="form-control" onchange="calculatePanels(this,4,' + n + ')"><?= select_product($all_products, 4, 0) ?></select></td>\n';
            tds += '<td><input type="text" name="table-4-l-' + n + '"  class="form-control"   size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-4-w-' + n + '"  class="form-control"   size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-4-u-' + n + '"  class="form-control"   size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-4-q-' + n + '"  class="form-control"   size="4" value="1" onchange="find_row_totals(4,' + n + ')"/></td>\n';
            tds += '<td><input type="text" name="table-4-t-' + n + '"  class="form-control"   size="4" readonly="readonly"/></td>\n';
            tds += '<td>&nbsp</td>\n';
            tds += '\n</tr>';
            $('#table-4 tbody').append(tds);

        }
        function addCladding() {
            var n = $('#table-5 tbody tr').length;
            var tds = "";
            tds += '<tr>';// Create a new row    
            if (n !== 0) {

                tds += '<td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this,5)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>\n';
            } else {
                tds += '<td>&nbsp</td>\n';
            }
            tds += '<td>' + (parseInt(n) + 1) + '</td>';
            tds += '<td><select type="text" name="table-5-id-' + n + '" onchange="calculatePanels(this,5,' + n + ')"><?= select_product($all_products, 5, 0) ?></select></td>\n';
            tds += '<td><input type="text" name="table-5-l-' + n + '"   size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-5-w-' + n + '"   size="10" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-5-u-' + n + '"   size="10"/></td>\n';
            tds += '<td><input type="text" name="table-5-q-' + n + '"   size="10"  value="1"  onchange="find_row_totals(5,' + n + ')"/></td>\n';
            tds += '<td><input type="text" name="table-5-t-' + n + '"   size="10" readonly="readonly"/></td>\n';
            tds += '<td>&nbsp</td>\n';
            tds += '\n</tr>';
            $('#table-5 tbody').append(tds);
        }
        function addOther() {
            var n = $('#table-6 tbody tr').length;
            var tds = "";
            tds += '<tr>';// Create a new row    
            if (n !== 0) {

                tds += '<td><span class="btn btn-danger btn-mini" onclick="removeThisRow(this,4)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>\n';
            } else {
                tds += '<td>&nbsp</td>\n';
            }
            tds += '<td>' + (parseInt(n) + 1) + '</td>';
            tds += '<td><select type="text" name="table-6-id-' + n + '" class="form-control" onchange="calculatePanels(this,6,' + n + ')"><?= select_product($all_products, 6, 0) ?></select></td>\n';
            tds += '<td><input type="text" name="table-6-l-' + n + '"   class="form-control" size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-6-w-' + n + '"   class="form-control" size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-6-u-' + n + '"   class="form-control" size="4" readonly="readonly"/></td>\n';
            tds += '<td><input type="text" name="table-6-q-' + n + '"   class="form-control" size="4"  value="1" onchange="find_row_totals(6,)"/></td>\n';
            tds += '<td><input type="text" name="table-6-t-' + n + '"   class="form-control" size="4" readonly="readonly"/></td>\n';
            tds += '<td>&nbsp</td>\n';
            tds += '\n</tr>';
            $('#table-6 tbody').append(tds);
        }
        function addRelative() {
            var n = $('#table-7 tbody tr').length;
            var tds = "";
            tds += '<tr>';// Create a new row    
            if (n !== 0) {
                tds += '<td><span class="btn btn-danger btn-mini" href="#" onclick="removeThisRow(this,7)"><i class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></span></td>\n';
            } else {
                tds += '<td>&nbsp</td>\n';
            }
            tds += '<td>' + (parseInt(n) + 1) + '</td>';
            tds += '<td><select type="text" name="table-7-id-' + n + '" class="form-control" onchange="calculatePanels(this,7,' + n + ')"><?= select_product($all_products, 7, 0) ?></select></td>\n';
            tds += '<td><input type="text" name="table-7-u-' + n + '"   class="form-control" size="4" readonly="readonly" value="0.00"/></td>\n';
            tds += '<td><input type="text" name="table-7-q-' + n + '"   class="form-control" size="4" value="1" onchange="find_row_totals(7,' + n + ')"/></td>\n';
            tds += '<td><input type="text" name="table-7-t-' + n + '"   class="form-control" size="4" readonly="readonly"/></td>\n';
            tds += '<td>&nbsp</td>\n';
            tds += '\n</tr>';
            $('#table-7 tbody').append(tds);
        }
        function calculatePanels(source, tableIndex, rowIndex) {
            if ($(source).val() === '') {
                return;
            }
            $.ajax({
                type: "GET",
                url: "<?= yii\helpers\Url::base() ?>/order/products/detail-view/?id=" + $(source).val(),
                dataType: "JSON",
                success: function (json) {
                    var index = $(source).closest('tr').index();
                    var row = $("#table-" + tableIndex + " tbody tr:eq(" + index + ")");
                    $('td input[name=table-' + tableIndex + '-l-' + rowIndex + ']', row).val(json.p_length);
                    $('td input[name=table-' + tableIndex + '-w-' + rowIndex + ']', row).val(json.p_width);
                    $('td input[name=table-' + tableIndex + '-h-' + rowIndex + ']', row).val(json.p_height);
                    $('td input[name=table-' + tableIndex + '-u-' + rowIndex + ']', row).val(json.unit_cost);
                    find_row_totals(tableIndex, rowIndex);
                    if (tableIndex === 2 || tableIndex === 3 || tableIndex === 4) {
                        find_no_panels();
                    }


                }
            });
        }
        function save_order() {
            if (!confirm("Are you sure want to continue?")) {
                return;
            }
            var data = $("#form1").serialize();
            var rows2 = $('#table-2 tbody tr').length;
            var rows3 = $('#table-3 tbody tr').length;
            var rows4 = $('#table-4 tbody tr').length;
            var rows5 = $('#table-5 tbody tr').length;
            var rows6 = $('#table-6 tbody tr').length;
            var rows7 = $('#table-7 tbody tr').length;
            var csrfToken = $('meta[name="csrf-token"]').attr("content");
            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: "<?= yii\helpers\Url::base() ?>/order/orders/process-order/",
                data: data + "&rows2=" + rows2 + "&rows3=" + rows3 + "&rows4=" + rows4 + "&rows5=" + rows5 + "&rows6=" + rows6 + "&rows7=" + rows7 + "&_csrf=" + csrfToken,
                success: function (response) {
                    if (response.error === "success") {
                        $("#new-qoute").html(response.html);
                    } else {
                        alert(response.html);
                    }
                }
            });
        }
    </script>