<?php

use common\modules\order\models\Orders;
use common\modules\order\models\OrderDetails;

$this->title = "Estimator Software for Costing Construction";

$order = Orders::findOne($id);
$panels = OrderDetails::find()->where(["p_type" => 2, 'order_id' => $id])->all();
$windows = OrderDetails::find()->where(["p_type" => 3, 'order_id' => $id])->all();
$doors = OrderDetails::find()->where(["p_type" => 4, 'order_id' => $id])->all();
$claddings = OrderDetails::find()->where(["p_type" => 5, 'order_id' => $id])->all();
$others = OrderDetails::find()->where(["p_type" => 6, 'order_id' => $id])->all();
$relatives = OrderDetails::find()->where(["p_type" => 7, 'order_id' => $id])->all();
?>

<div id="new-qoute">
    <form class="form-horizontal" id="form1">
        <div class="col-md-10">
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Dimensions</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="table-dimensions">
                        <thead><tr><th>Date</th><th>Length</th><th>Width</th><th>Height</th></tr></thead>
                        <tbody>
                            <tr>
                                <td>
                                    <?= Yii::$app->formatter->format($order->txdate, 'date') ?>
                                </td>
                                <td>
                                    <?= Yii::$app->formatter->format($order->o_length, 'integer') ?>
                                </td>
                                <td>
                                    <?= Yii::$app->formatter->format($order->o_width, 'integer') ?>
                                </td>
                                <td>
                                    <?= Yii::$app->formatter->format($order->o_height, 'integer') ?>
                                </td>
                            </tr>


                        </tbody>
                    </table>

                </div>
            </div>
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Windows</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"  id="table-3">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Length</th>
                                <th>Width</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            $i = 1;
                            foreach ($windows as $window) {
                                ?>
                                <tr>
                                    <td></td>
                                    <td><?= $i ?></td>
                                    <td><?= $window->product->name ?></td>
                                    <td><?= Yii::$app->formatter->format($window->p_width, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($window->p_length, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($window->unit_cost, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($window->qty, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($window->total, 'currency') ?></td>
                                </tr>

                                <?php
                                $total+=$window->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>

                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="5">
                                    Total
                                </th>
                                <th>
                                    <span id="table-total-3" name="table-total-2"><?= Yii::$app->formatter->format($total, 'currency') ?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Doors</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"  id="table-4">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Length</th>
                                <th>Width</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            $i = 1;
                            foreach ($doors as $door) {
                                ?>
                                <tr>
                                    <td></td>
                                    <td><?= $i ?></td>
                                    <td><?= $door->product->name ?></td>
                                    <td><?= Yii::$app->formatter->format($door->p_width, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($door->p_length, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($door->unit_cost, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($door->qty, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($door->total, 'currency') ?></td>
                                </tr>

                                <?php
                                $total+=$door->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="5">
                                    Total
                                </th>
                                <th>
                                    <span id="table-total-3" name="table-total-2"><?= Yii::$app->formatter->format($total, 'currency') ?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Additional Components</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"   id="table-6">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Length</th>
                                <th>Width</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $total = 0;
                            $i = 1;
                            foreach ($others as $other) {
                                ?>
                                <tr>
                                    <td></td>
                                    <td><?= $i ?></td>
                                    <td><?= $other->product->name ?></td>
                                    <td><?= Yii::$app->formatter->format($other->p_width, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($other->p_length, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($other->unit_cost, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($other->qty, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($other->total, 'currency') ?></td>
                                </tr>

                                <?php
                                $total+=$other->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>

                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="5">
                                    Total
                                </th>
                                <th>
                                    <span id="table-total-3" name="table-total-2"><?= Yii::$app->formatter->format($total, 'currency') ?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="panel panel-success">
                <!-- Default panel contents -->
                <div class="panel-heading"><h4 class="sub-header">Relative Costs</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered"  id="table-7">
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>Description</th>
                                <th>Unit Cost</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $total = 0;
                            $i = 1;
                            foreach ($relatives as $relative) {
                                ?>
                                <tr>
                                    <td></td>
                                    <td><?= $i ?></td>
                                    <td><?= $relative->product->name ?></td>
                                    <td><?= Yii::$app->formatter->format($relative->unit_cost, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($relative->qty, ['decimal', 2]) ?></td>
                                    <td><?= Yii::$app->formatter->format($relative->total, 'currency') ?></td>
                                </tr>

                                <?php
                                $total+=$window->total;
                                $i++;
                            }
                            ?>
                        </tbody>
                        <tfoot>

                            <tr>
                                <th></th>
                                <th>#</th>
                                <th colspan="3">
                                    Total
                                </th>
                                <th>
                                    <span id="table-total-3" name="table-total-2"><?= Yii::$app->formatter->format($total, 'currency') ?></span>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="panel panel-success">
                <div class="table-responsive">
                    <table>
                        <tr>
                            <td>
                                <span class="btn btn-info" onclick="print_order()">Print<i class="fa fa-trash-o" title="Print" aria-hidden="true"></i></span>
                                <?= yii\helpers\Html::a(Yii::t('app', 'Update'), ['update', 'id' => $id], ['class' => 'btn btn-primary']) ?>
                            </td>
                        </tr>
                    </table> 
                </div>
            </div>

        </div>
        <div class="col-md-2">
            <div style="position: fixed;width: 200px" >
                <div class="panel panel-success">
                    <!-- Default panel contents -->
                    <div class="panel-heading"><h4 class="sub-header">Total Costs</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered"  id="table-8">
                            <tbody>
                                <tr>
                                    <th>Quote Total</th>
                                    <td>
                                        <span id="total-quote"><?= Yii::$app->formatter->format($order->totalcost, 'currency') ?></span>
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>

    </form>
