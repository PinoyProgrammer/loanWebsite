<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel common\modules\order\models\OrdersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Orders');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="orders-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>

    
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>email</th>
            <th>Search</th>
            <th>Selected</th>
        </tr>
        <?php
        $orders = $dataProvider->getModels();
        foreach ($orders as $order) {
            $comments = explode("|", ($order->comments));
            $selected = isset($comments[0]) ? $comments[0] : "";
            $search = isset($comments[1]) ? $comments[1] : "";
            $details = isset($comments[2]) ? $comments[2] : "";
            $formatter = \Yii::$app->formatter;
            //if (is_object($search->ProfileSearch)) {
            ?>
            <tr>
                <td><?= $order->name ?></td>
                <td><?php
                    $emails = json_decode($details, true);
                    ?>
                    Email:<?= isset($emails["email"]) ? $formatter->asEmail($emails["email"]) : '';?><br/>
                    Number: <?php print_r(isset($emails["phoneno"]) ? $emails["phoneno"] : '');                    ?>
                </td>
                <td><?php
                    $searches = json_decode($search, true);
                    if (isset($searches["ProfileSearch"])) {
                        ?>
                    <ul class="list-group">
                        <li class="list-group-item list-group-item-heading">Subject :<?php print_r($searches["ProfileSearch"]['note']) ?></li>
                            <li class="list-group-item">Level :<?php print_r($searches["ProfileSearch"]['level']) ?></li>
                            <li class="list-group-item">Min Cost :$ <?php print_r($searches["ProfileSearch"]['min_hire_cost']) ?></li>
                            <li class="list-group-item">Location :<?php print_r($searches["ProfileSearch"]['location']) ?></li>
                        </ul>
                    <?php }
                    ?></td>
                <td>
                    <ul class="list-group">
                        <?php
                        $selected_users = json_decode($selected, true);
                        if (is_array($selected_users)) {
                            $i=1;
                            foreach ($selected_users as $selected_user) {
                                $profile = \common\modules\user\models\Profile::findOne(["user_id" => $selected_user]);
                                ?> 
                                <ol class="list-group-item"> 
                                    <?= $i ?>.
                                    Name:<?= $profile->first_name . ' ' . $profile->last_name ?> 
                                    Subject: <?= $profile->note ?>
                                    Price: <?= Yii::$app->formatter->format($profile->min_hire_cost, ['currency']) ?> 
                                    Location: <?= $profile->location ?> 
                                    Level: <?= $profile->location ?>
                                </ol>
                                <?php
                                $i++;
                            }
                        }
                        ?></ul>
                </td>

            </tr>
            <?php
        }
        // }
        ?>
    </table>