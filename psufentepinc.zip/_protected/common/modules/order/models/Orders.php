<?php

namespace common\modules\order\models;

use Yii;

/**
 * This is the model class for table "orders".
 *
 * @property integer $id
 * @property string $name
 * @property integer $o_height
 * @property integer $o_length
 * @property integer $o_width
 * @property double $totalcost
 * @property string $txdate
 * @property string $comments
 */
class Orders extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return static::getDb()->tablePrefix .  'orders';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['o_height', 'o_length', 'o_width'], 'integer'],
            [['totalcost'], 'number'],
            [['txdate'], 'safe'],
            [['comments'], 'string'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'o_height' => Yii::t('app', 'O Height'),
            'o_length' => Yii::t('app', 'O Length'),
            'o_width' => Yii::t('app', 'O Width'),
            'totalcost' => Yii::t('app', 'Totalcost'),
            'txdate' => Yii::t('app', 'Txdate'),
            'comments' => Yii::t('app', 'Comments'),
        ];
    }
}
