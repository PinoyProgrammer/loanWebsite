<?php

namespace common\modules\order\models;

use Yii;

/**
 * This is the model class for table "products".
 *
 * @property integer $id
 * @property string $name
 * @property integer $is_stock_item
 * @property integer $is_active
 * @property integer $category_id
 */
class Products extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return static::getDb()->tablePrefix .  'products';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['name', 'category_id'], 'required'],
            [['is_stock_item', 'is_active', 'category_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'is_stock_item' => Yii::t('app', 'Is Stock Item'),
            'is_active' => Yii::t('app', 'Is Active'),
            'category_id' => Yii::t('app', 'Category ID'),
        ];
    }

    public function getProductDetails() {
        return $this->hasOne(ProductDetails::className(), ['product_id' => 'id']);
    }

    public function getCategory() {
        return $this->hasOne(Category::className(), ['id' => 'category_id']);
    }

    const SCENARIO_CREATE = 'update';
    const SCENARIO_UPDATE= 'create';

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios[self::SCENARIO_CREATE] = ['name' ,'is_stock_item','is_active','category_id'];
        $scenarios[self::SCENARIO_UPDATE] = ['name' ,'is_stock_item','is_active','category_id'];
        return $scenarios;
    }

}
