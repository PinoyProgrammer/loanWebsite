<?php

namespace common\modules\order\models;

use Yii;

/**
 * This is the model class for table "order_details".
 *
 * @property integer $id
 * @property integer $product_id
 * @property integer $order_id
 * @property integer $p_height
 * @property integer $p_width
 * @property integer $p_length
 * @property double $unit_cost
 * @property double $total
 * @property double $qty
 * @property string $txdate
 * @property string $comments
 */
class OrderDetails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return static::getDb()->tablePrefix .  'order_details';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['product_id', 'order_id'], 'required'],
            [['product_id', 'order_id', 'p_height', 'p_width', 'p_length'], 'integer'],
            [['unit_cost', 'total', 'qty','p_type'], 'number'],
            [['txdate'], 'safe'],
            [['comments'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'product_id' => Yii::t('app', 'Product ID'),
            'order_id' => Yii::t('app', 'Order ID'),
            'p_height' => Yii::t('app', 'P Height'),
            'p_width' => Yii::t('app', 'P Width'),
            'p_length' => Yii::t('app', 'P Length'),
            'unit_cost' => Yii::t('app', 'Unit Cost'),
            'total' => Yii::t('app', 'Total'),
            'qty' => Yii::t('app', 'Qty'),
            'p_type' => Yii::t('app', 'Type'),
            'txdate' => Yii::t('app', 'Txdate'),
            'comments' => Yii::t('app', 'Comments'),
        ];
    }
    public function getProduct()
    {
        return $this->hasOne(Products::className(), ['id' => 'product_id']);
    }
}
