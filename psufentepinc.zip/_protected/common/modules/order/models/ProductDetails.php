<?php

namespace common\modules\order\models;

use Yii;

/**
 * This is the model class for table "product_details".
 *
 * @property integer $id
 * @property integer $product_id
 * @property integer $p_height
 * @property integer $p_width
 * @property integer $p_length
 * @property double $unit_cost
 */
class ProductDetails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return static::getDb()->tablePrefix .  'product_details';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['product_id', 'p_height', 'p_width', 'p_length'], 'integer'],
            [['unit_cost'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'product_id' => Yii::t('app', 'Product ID'),
            'p_height' => Yii::t('app', 'Height'),
            'p_width' => Yii::t('app', 'Width'),
            'p_length' => Yii::t('app', 'Length'),
            'unit_cost' => Yii::t('app', 'Unit Cost'),
        ];
    }
    const SCENARIO_CREATE = 'update';
    const SCENARIO_UPDATE= 'create';

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios[self::SCENARIO_CREATE] = ['product_id', 'p_height', 'p_width', 'p_length','unit_cost'];
        $scenarios[self::SCENARIO_UPDATE] = ['product_id', 'p_height', 'p_width', 'p_length','unit_cost'];
        return $scenarios;
    }
    
}
