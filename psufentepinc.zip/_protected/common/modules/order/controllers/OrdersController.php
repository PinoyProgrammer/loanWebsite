<?php

namespace common\modules\order\controllers;

use Yii;
use common\modules\order\models\Orders;
use common\modules\order\models\OrdersSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use \common\modules\order\models\OrderDetails;

/**
 * OrdersController implements the CRUD actions for Orders model.
 */
class OrdersController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Orders models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new OrdersSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Orders model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('order-detials', [
                    'id' => ($id),
        ]);
    }

    /**
     * Creates a new Orders model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new Orders();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Orders model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Orders model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Orders model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Orders the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Orders::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionProcessOrder() {
        if (Yii::$app->request->isPost) {
            $request = Yii::$app->request;
            if ($request->Post("id")) {
                $order = new Orders;
            } else {               
                $order=Orders::findOne($request->Post("id")) == null?new Orders:Orders::findOne($request->Post("id"));
                
            }
            $order->txdate = \Yii::$app->formatter->asDatetime($request->Post("txdate"), "php:Y-m-d");
            $order->name = \Yii::$app->formatter->asDatetime($request->Post("txdate"), "php:Y-m-d");
            $order->o_height = $request->Post("d-height");
            $order->o_length = $request->Post("d-length");
            $order->o_width = $request->Post("d-width");

            $roof = $request->Post("roof");
            $wall = $request->Post("wall");
            $floor = $request->Post("floor");
            $dlength = $request->Post("d-length");
            $dwidth = $request->Post("d-width");
            $dheight = $request->Post("d-height");
            $floor_cost = $dlength * $dwidth * $floor;
            $wall_cost = ($dlength + $dwidth) * 2 * $dheight * $wall;
            $roof_cost = (($dlength + 0.4) * ($dwidth + 0.8)) * $roof;


            $order->save(false);
            $order_id = $order->id;
            OrderDetails::deleteAll(['order_id' => $order_id]);
            $totalcost = 0;
            for ($tableIndex = 2; $tableIndex <= 7; $tableIndex++) {
                $rows = $request->Post("rows$tableIndex");
                for ($rowIndex = 0; $rowIndex < $rows; $rowIndex++) {
                    if ($request->Post("table-$tableIndex-id-$rowIndex")) {
                        $orderDetails = new OrderDetails;
                        $orderDetails->order_id = $order_id;
                        $orderDetails->product_id = $request->Post("table-$tableIndex-id-$rowIndex");
                        $orderDetails->qty = $request->Post("table-$tableIndex-q-$rowIndex");
                        $orderDetails->unit_cost = $request->Post("table-$tableIndex-u-$rowIndex");
                        $orderDetails->total = $request->Post("table-$tableIndex-t-$rowIndex");
                        $totalcost+=$orderDetails->total;
                        $orderDetails->p_type = $tableIndex;
                        $orderDetails->txdate = $order->txdate;
                        if (in_array($tableIndex, array(2, 3, 4))) {
                            $orderDetails->p_length = $request->Post("table-$tableIndex-l-$rowIndex");
                            $orderDetails->p_height = 0;
                            $orderDetails->p_width = $request->Post("table-$tableIndex-w-$rowIndex");
                        } else {
                            $orderDetails->p_length = 0;
                            $orderDetails->p_height = 0;
                            $orderDetails->p_width = 0;
                        }

                        $orderDetails->save(false);
                    }
                }
            }
            $order->totalcost = $totalcost + $floor_cost + $wall_cost + $roof_cost;
            $order->save(false);
            header('Content-Type: application/json');
            $html = $this->renderPartial("order-detials", ["id" => $order_id]);
            return \yii\helpers\Json::encode(array("error" => "success", "html" => $html));
        }
    }

    public function actionExport($id) {
        
    }

}
