<?php

namespace common\modules\order\controllers;

use Yii;
use common\modules\order\models\Products;
use common\modules\order\models\ProductsSearch;
use common\modules\order\models\ProductDetails;
use common\modules\order\models\ProductDetailsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ProductsController implements the CRUD actions for Products model.
 */
class ProductsController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Products models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new ProductsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Products model.
     * @param integer $id
     * @return mixed
     */
    public function actionDetailView($id) {

        $model = Products::findOne($id);
        $productDetail = $model->productDetails;
        $product = array("id" => $model->id,
            'p_length' => $productDetail->p_length,
            'p_width' => $productDetail->p_width,
            'p_height' => $productDetail->p_height,
            'unit_cost' => $productDetail->unit_cost);
        echo \yii\helpers\Json::encode($product);
    }

    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Products model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $product = new Products();
        $productDetail = new ProductDetails;
        
        if (!isset($product, $productDetail)) {
            throw new NotFoundHttpException("The product was not found.");
        }
        
        $product->scenario = 'create';
        $productDetail->scenario = 'create';
        
        if ($product->load(Yii::$app->request->post()) && $productDetail->load(Yii::$app->request->post())) {
            $isValid = $product->validate();
            $isValid = $productDetail->validate() && $isValid;
            if ($isValid) {
                $product->save(false);
                $productDetail->product_id=$product->id;
                $productDetail->save(false);
                return $this->redirect(['view', 'id' => $product->id]);
            }
        }
        
        return $this->render('create', [
            'product' => $product,
            'productDetail' => $productDetail,
        ]);
    }

    /**
     * Updates an existing Products model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $product = Products::findOne($id);
        $productDetail = $product->productDetails;
        
        if (!isset($product, $productDetail)) {
            throw new NotFoundHttpException("The product was not found.");
        }
        
        $product->scenario = 'update';
        $productDetail->scenario = 'update';
        
        if ($product->load(Yii::$app->request->post()) && $productDetail->load(Yii::$app->request->post())) {
            $isValid = $product->validate();
            $isValid = $productDetail->validate() && $isValid;
            if ($isValid) {
                $product->save(false);
                $productDetail->save(false);
                return $this->redirect(['view', 'id' => $id]);
            }
        }
        
        return $this->render('update', [
            'product' => $product,
            'productDetail' => $productDetail,
        ]);
    
    }

    /**
     * Deletes an existing Products model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Products model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Products the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Products::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
