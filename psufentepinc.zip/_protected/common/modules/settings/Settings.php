<?php

namespace common\modules\settings;

class Settings extends \yii\base\Module
{
    public $controllerNamespace = 'common\modules\settings\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
