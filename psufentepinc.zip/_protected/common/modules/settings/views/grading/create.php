<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\modules\settings\models\Grading */

$this->title = 'Create Grading';
$this->params['breadcrumbs'][] = ['label' => 'Gradings', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="grading-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
