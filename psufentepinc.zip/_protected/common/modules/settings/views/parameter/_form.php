<?php

use kartik\builder\Form;
use kartik\form\ActiveForm;
use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\modules\vm\models\ExpenseType */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="levels-form">

    <?php
    $form = ActiveForm::begin([
                'type' => ActiveForm::TYPE_VERTICAL,
                'formConfig' => ['labelSpan' => 4],]);

    echo Form::widget([
        'model' => $model,
        'form' => $form,
        'columns' => 1,
        'attributes' => [
            'code' => ['type' => Form::INPUT_TEXT,],
            'description' => ['type' => Form::INPUT_TEXT,],
            'value' => ['type' => Form::INPUT_TEXT,],
            'format' => [
                'type' => Form::INPUT_DROPDOWN_LIST,
                'items' => [ 'string' => 'String', 'number' => 'Number', 'boolean' => 'Boolean', ], ['prompt' => 'Select']
            ],
        ],
    ]);
    ?>
    <div class="form-group">
<?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>

</div>
