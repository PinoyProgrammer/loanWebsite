<?php

use yii\helpers\Html;
use kartik\detail\DetailView;

/* @var $this yii\web\View */
/* @var $model common\modules\vm\models\ExpenseType */

$this->title = $model->description;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Parameters'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="parameter-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?=
        Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                'method' => 'post',
            ],
        ])
        ?>
    </p>

    <?=
    DetailView::widget([
        'model' => $model,
        'condensed' => true,
        'hover' => true,
        'enableEditMode' => false,
        'mode' => DetailView::MODE_VIEW,
        'hAlign' => 'left',
        'panel' => [
            'heading' => 'Name # ' . $this->title,
            'type' => DetailView::TYPE_INFO,
        ],
        'attributes' => [
            'code',
            'description',
            [
                'attribute' => 'value',
            ],
            [
                'attribute' => 'created_at',
                'value' => $model->created_at,
            ],
            [
                'attribute' => 'updated_at',
                'value' => $model->updated_at,
            ],
        ],
    ])
    ?>

</div>
