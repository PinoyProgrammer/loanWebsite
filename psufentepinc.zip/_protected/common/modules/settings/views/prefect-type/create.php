<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\modules\settings\models\PrefectType */

$this->title = 'Create Prefect Type';
$this->params['breadcrumbs'][] = ['label' => 'Prefect Types', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="prefect-type-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
