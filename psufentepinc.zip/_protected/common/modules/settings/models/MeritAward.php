<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "merit_award".
 *
 * @property integer $merit_award_id
 * @property string $award_description
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_at
 * @property string $update_at
 *
 * @property Users $createdBy
 * @property Users $updatedBy
 */
class MeritAward extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'merit_award';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['award_description', 'created_by'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_at', 'update_at'], 'safe'],
            [['award_description'], 'string', 'max' => 100],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['updated_by' => 'user_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'merit_award_id' => 'Merit Award ID',
            'award_description' => 'Award Description',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'updated_by']);
    }
}
