<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "subject".
 *
 * @property integer $subject_id
 * @property string $description
 * @property string $update_at
 * @property integer $stream_id
 * @property string $subject_code
 * @property string $gov_subject_code
 */
class Subject extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'subject';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description'], 'required'],
            [['update_at'], 'safe'],
            [['stream_id'], 'integer'],
            [['description'], 'string', 'max' => 45],
            [['subject_code'], 'string', 'max' => 5],
            [['gov_subject_code'], 'string', 'max' => 10],
            [['description'], 'unique'],
            [['subject_code'], 'unique'],
            [['gov_subject_code'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'subject_id' => 'Subject ID',
            'description' => 'Description',
            'update_at' => 'Update At',
            'stream_id' => 'Stream ID',
            'subject_code' => 'Subject Code',
            'gov_subject_code' => 'Gov Subject Code',
        ];
    }
}
