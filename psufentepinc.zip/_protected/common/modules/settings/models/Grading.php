<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "grading".
 *
 * @property integer $grading_id
 * @property string $description
 * @property string $grade_acronym
 * @property string $update_at
 */
class Grading extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'grading';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description', 'grade_acronym'], 'required'],
            [['update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
            [['grade_acronym'], 'string', 'max' => 1],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'grading_id' => 'ID',
            'description' => 'Description',
            'grade_acronym' => 'Grade Acronym',
            'update_at' => 'Update At',
        ];
    }
}
