<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "assignment".
 *
 * @property integer $assignment_id
 * @property integer $grade_subject_id
 * @property string $name
 * @property string $date
 * @property string $description
 * @property integer $is_marks
 * @property string $update_at
 */
class Assignment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'assignment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['grade_subject_id', 'name', 'date'], 'required'],
            [['grade_subject_id', 'is_marks'], 'integer'],
            [['date', 'update_at'], 'safe'],
            [['name'], 'string', 'max' => 45],
            [['description'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'assignment_id' => 'Assignment ID',
            'grade_subject_id' => 'Grade Subject ID',
            'name' => 'Name',
            'date' => 'Date',
            'description' => 'Description',
            'is_marks' => 'Is Marks',
            'update_at' => 'Update At',
        ];
    }
}
