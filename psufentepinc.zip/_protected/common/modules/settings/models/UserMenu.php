<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "{{%user_menu}}".
 *
 * @property integer $menu_id
 * @property string $menu_url
 * @property string $description
 * @property integer $active
 * @property integer $company_type
 * @property integer $dept_type
 * @property integer $ord
 */
class UserMenu extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%user_menu}}';
    }

    public static function find() {
        return parent::find()->orderBy([new \yii\db\Expression('-ord desc')]);
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['menu_url', 'description'], 'required'],
            [['active', 'company_type', 'dept_type', 'ord'], 'integer'],
            [['menu_url', 'description'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'menu_id' => Yii::t('app', 'Menu ID'),
            'menu_url' => Yii::t('app', 'Menu Url'),
            'description' => Yii::t('app', 'Description'),
            'active' => Yii::t('app', 'Active'),
            'company_type' => Yii::t('app', 'Company Type'),
            'dept_type' => Yii::t('app', 'Dept Type'),
            'ord' => Yii::t('app', 'Ord'),
        ];
    }

    public static function menuItems($menu_id, $type) {
        $user = \common\modules\user\models\User::findOne(\Yii::$app->user->id);
        $sql = "select a.* from ".UserMenu::tableName()." a join ". \common\modules\user\models\UserPermission::tableName()." 
            b on a.menu_id=b.menu_id
where b.user_id=$user->user_id
union
select a.* from ".UserMenu::tableName()." a join ". \common\modules\user\models\UserGroupPermission::tableName()." b on a.menu_id=b.menu_id
where b.group_id=$user->role_id
order by ord";
        $connection = Yii::$app->getDb();
        $menus = $connection->createCommand($sql)->queryAll();
        $paths = [];
        foreach ($menus as $menu) {
            $paths[$menu['menu_url']] = ['div_class' => $menu['fa'], 'description' => $menu['description']];
        }
        return $paths;
    }

}
