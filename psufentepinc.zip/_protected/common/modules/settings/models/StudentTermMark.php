<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "student_term_mark".
 *
 * @property integer $student_term_marks_id
 * @property integer $stu_master_id
 * @property integer $grade_subject_id
 * @property integer $term_id
 * @property double $marks
 * @property string $comments
 * @property integer $merit_award_id
 * @property integer $is_absent
 * @property integer $edit_mark_state
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_at
 * @property string $update_at
 *
 * @property Users $createdBy
 * @property Users $updatedBy
 * @property MeritAward $meritAward
 * @property StuMaster $stuMaster
 * @property GradeSubject $gradeSubject
 * @property Term $term
 */
class StudentTermMark extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student_term_mark';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['stu_master_id', 'grade_subject_id', 'term_id', 'created_by'], 'required'],
            [['stu_master_id', 'grade_subject_id', 'term_id', 'merit_award_id', 'is_absent', 'edit_mark_state', 'created_by', 'updated_by'], 'integer'],
            [['marks'], 'number'],
            [['created_at', 'update_at'], 'safe'],
            [['comments'], 'string', 'max' => 45],
            [['stu_master_id', 'grade_subject_id', 'term_id'], 'unique', 'targetAttribute' => ['stu_master_id', 'grade_subject_id', 'term_id'], 'message' => 'The combination of Stu Master ID, Grade Subject ID and Term ID has already been taken.'],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['updated_by' => 'user_id']],
            [['merit_award_id'], 'exist', 'skipOnError' => true, 'targetClass' => MeritAward::className(), 'targetAttribute' => ['merit_award_id' => 'merit_award_id']],
            [['stu_master_id'], 'exist', 'skipOnError' => true, 'targetClass' => StuMaster::className(), 'targetAttribute' => ['stu_master_id' => 'stu_master_id']],
            [['grade_subject_id'], 'exist', 'skipOnError' => true, 'targetClass' => GradeSubject::className(), 'targetAttribute' => ['grade_subject_id' => 'grade_subject_id']],
            [['term_id'], 'exist', 'skipOnError' => true, 'targetClass' => Term::className(), 'targetAttribute' => ['term_id' => 'term_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'student_term_marks_id' => 'Student Term Marks ID',
            'stu_master_id' => 'Stu Master ID',
            'grade_subject_id' => 'Grade Subject ID',
            'term_id' => 'Term ID',
            'marks' => 'Marks',
            'comments' => 'Comments',
            'merit_award_id' => 'Merit Award ID',
            'is_absent' => 'Is Absent',
            'edit_mark_state' => 'Edit Mark State',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeritAward()
    {
        return $this->hasOne(MeritAward::className(), ['merit_award_id' => 'merit_award_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuMaster()
    {
        return $this->hasOne(StuMaster::className(), ['stu_master_id' => 'stu_master_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGradeSubject()
    {
        return $this->hasOne(GradeSubject::className(), ['grade_subject_id' => 'grade_subject_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTerm()
    {
        return $this->hasOne(Term::className(), ['term_id' => 'term_id']);
    }
}
