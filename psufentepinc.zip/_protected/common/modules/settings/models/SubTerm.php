<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "sub_term".
 *
 * @property integer $sub_term_id
 * @property integer $term_id
 * @property string $description
 * @property string $from_month
 * @property string $to_month
 * @property string $update_at
 *
 * @property Term $term
 */
class SubTerm extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sub_term';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['term_id', 'description', 'from_month', 'to_month'], 'required'],
            [['term_id'], 'integer'],
            [['from_month', 'to_month', 'update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
            [['term_id'], 'exist', 'skipOnError' => true, 'targetClass' => Term::className(), 'targetAttribute' => ['term_id' => 'term_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'sub_term_id' => 'Sub Term ID',
            'term_id' => 'Term',
            'description' => 'Description',
            'from_month' => 'From Month',
            'to_month' => 'To Month',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTerm()
    {
        return $this->hasOne(Term::className(), ['term_id' => 'term_id']);
    }
}
