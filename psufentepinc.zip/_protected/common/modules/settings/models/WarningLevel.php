<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "warning_level".
 *
 * @property integer $warning_level_id
 * @property string $description
 * @property string $colour
 * @property string $update_at
 */
class WarningLevel extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'warning_level';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description', 'colour'], 'required'],
            [['update_at'], 'safe'],
            [['description', 'colour'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'warning_level_id' => 'Warning Level ID',
            'description' => 'Description',
            'colour' => 'Colour',
            'update_at' => 'Update At',
        ];
    }
}
