<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "entity_states".
 *
 * @property integer $state_id
 * @property string $state_type
 * @property string $state_description
 * @property string $created_at
 * @property integer $created_by
 *
 * @property Users $createdBy
 */
class EntityState extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'entity_states';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['state_type', 'created_at', 'created_by'], 'required'],
            [['created_at'], 'safe'],
            [['created_by'], 'integer'],
            [['state_type'], 'string', 'max' => 50],
            [['state_description'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'state_id' => 'State ID',
            'state_type' => 'State Type',
            'state_description' => 'State Description',
            'created_at' => 'Created At',
            'created_by' => 'Created By',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }
}
