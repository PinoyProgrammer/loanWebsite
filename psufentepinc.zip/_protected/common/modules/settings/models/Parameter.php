<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "{{%parameter}}".
 *
 * @property integer $id
 * @property string $code
 * @property string $description
 * @property string $value
 * @property string $format
 * @property string $created_at
 * @property integer $created_by
 * @property string $updated_at
 * @property integer $updated_by
 */
class Parameter extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%parameter}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['code', 'description', 'value', 'format'], 'required'],
            [['format'], 'string'],
            [['created_at', 'updated_at', 'created_at', 'created_by'], 'safe'],
            [['created_by', 'updated_by'], 'integer'],
            [['code'], 'string', 'max' => 60],
            [['description', 'value'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'description' => Yii::t('app', 'Description'),
            'value' => Yii::t('app', 'Value'),
            'format' => Yii::t('app', 'Format'),
            'created_at' => Yii::t('app', 'Created At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }

    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = 0;
            $this->created_at = date("Y-m-d H:i:s");
            return true;
        } else {
            return false;
        }
    }

}
