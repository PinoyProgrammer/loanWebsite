<?php

namespace common\modules\settings\models;

use Yii;
use common\modules\user\models\User;

/**
 * This is the model class for table "organization".
 *
 * @property integer $org_id
 * @property string $org_name
 * @property string $org_alias
 * @property string $org_address_line1
 * @property string $org_address_line2
 * @property string $org_phone
 * @property string $org_email
 * @property string $org_website
 * @property resource $org_logo
 * @property string $org_logo_type
 * @property string $org_stu_prefix
 * @property string $org_emp_prefix
 * @property string $created_at
 * @property integer $created_by
 * @property string $updated_at
 * @property integer $updated_by
 * @property string $org_par_prefix
 *
 * @property Users $createdBy
 * @property Users $updatedBy
 */
class Organization extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return static::getDb()->tablePrefix .  'organization';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['org_name', 'org_alias', 'org_address_line1', 'org_stu_prefix', 'org_emp_prefix', 'created_at'], 'required'],
            [['org_logo'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['created_by', 'updated_by'], 'integer'],
            [['org_name', 'org_address_line1', 'org_address_line2'], 'string', 'max' => 255],
            [['org_alias', 'org_phone'], 'string', 'max' => 25],
            [['org_email'], 'string', 'max' => 65],
            [['org_website'], 'string', 'max' => 120],
            [['org_logo_type'], 'string', 'max' => 35],
            [['org_stu_prefix', 'org_emp_prefix', 'org_par_prefix'], 'string', 'max' => 10],
            [['org_name'], 'unique'],
            [['org_alias'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'org_id' => 'Institute ID',
            'org_name' => 'Name',
            'org_alias' => 'Alias',
            'org_address_line1' => 'Address Line 1',
            'org_address_line2' => 'Address Line 2',
            'org_phone' => 'Phone',
            'org_email' => 'Email',
            'org_website' => 'Website',
            'org_logo' => 'Logo',
            'org_logo_type' => 'Logo Type',
            'created_at' => 'Created Time',
            'created_by' => 'Created User',
            'updated_at' => 'Updated Time',
            'updated_by' => 'Updated User',
            'org_stu_prefix'=>'Student Login Prefix',
	    'org_emp_prefix'=>'Employee Login Prefix',
            'org_par_prefix' => 'Parent Login Prefix',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['user_id' => 'updated_by']);
    }
}
