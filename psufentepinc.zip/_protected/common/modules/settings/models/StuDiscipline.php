<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "stu_discipline".
 *
 * @property integer $stu_discipline_id
 * @property integer $stu_master_id
 * @property integer $warning_level_id
 * @property string $comment
 * @property integer $is_informed_to_parent
 * @property string $date
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_at
 * @property string $update_at
 *
 * @property Users $createdBy
 * @property Users $updatedBy
 * @property WarningLevel $warningLevel
 * @property StudentSuspendDetails[] $studentSuspendDetails
 */
class StuDiscipline extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'stu_discipline';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['stu_master_id', 'warning_level_id', 'date', 'created_by'], 'required'],
            [['stu_master_id', 'warning_level_id', 'is_informed_to_parent', 'created_by', 'updated_by'], 'integer'],
            [['date', 'created_at', 'update_at'], 'safe'],
            [['comment'], 'string', 'max' => 45],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['updated_by' => 'user_id']],
            [['warning_level_id'], 'exist', 'skipOnError' => true, 'targetClass' => WarningLevel::className(), 'targetAttribute' => ['warning_level_id' => 'warning_level_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'stu_discipline_id' => 'Stu Discipline ID',
            'stu_master_id' => 'Stu Master ID',
            'warning_level_id' => 'Warning Level ID',
            'comment' => 'Comment',
            'is_informed_to_parent' => 'Is Informed To Parent',
            'date' => 'Date',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWarningLevel()
    {
        return $this->hasOne(WarningLevel::className(), ['warning_level_id' => 'warning_level_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStudentSuspendDetails()
    {
        return $this->hasMany(StudentSuspendDetails::className(), ['stu_discipline_id' => 'stu_discipline_id']);
    }
}
