<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "relationships".
 *
 * @property integer $id
 * @property string $name
 *
 * @property StuParent[] $stuParents
 */
class Relationships extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'relationships';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['name'], 'string', 'max' => 20]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuParents()
    {
        return $this->hasMany(StuParent::className(), ['relation_id' => 'id']);
    }
}
