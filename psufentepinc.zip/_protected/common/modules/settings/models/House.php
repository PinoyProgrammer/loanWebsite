<?php

namespace common\modules\settings\models;

use Yii;
use common\modules\employee\models\EmpMaster;
use common\modules\student\models\StuMaster;

/**
 * This is the model class for table "house".
 *
 * @property integer $house_id
 * @property string $name
 * @property string $colour
 * @property string $description
 * @property integer $captain
 * @property integer $capacity
 * @property integer $vice_captain
 * @property integer $emp_master_id
 * @property string $update_at
 *
 * @property StuMaster $captain0
 * @property StuMaster $viceCaptain
 * @property EmpMaster $empMaster
 */
class House extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'house';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['captain', 'capacity', 'vice_captain', 'emp_master_id'], 'integer'],
            [['update_at'], 'safe'],
            [['name', 'colour', 'description'], 'string', 'max' => 45],
            [['name'], 'unique'],
            [['captain'], 'exist', 'skipOnError' => true, 'targetClass' => StuMaster::className(), 'targetAttribute' => ['captain' => 'stu_master_id']],
            [['vice_captain'], 'exist', 'skipOnError' => true, 'targetClass' => StuMaster::className(), 'targetAttribute' => ['vice_captain' => 'stu_master_id']],
            [['emp_master_id'], 'exist', 'skipOnError' => true, 'targetClass' => EmpMaster::className(), 'targetAttribute' => ['emp_master_id' => 'emp_master_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'house_id' => 'House ID',
            'name' => 'Name',
            'colour' => 'Colour',
            'description' => 'Description',
            'captain' => 'Captain',
            'capacity' => 'Capacity',
            'vice_captain' => 'Vice Captain',
            'emp_master_id' => 'Master',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCaptain0()
    {
        return $this->hasOne(StuMaster::className(), ['stu_master_id' => 'captain']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getViceCaptain()
    {
        return $this->hasOne(StuMaster::className(), ['stu_master_id' => 'vice_captain']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEmpMaster()
    {
        return $this->hasOne(EmpMaster::className(), ['emp_master_id' => 'emp_master_id']);
    }
}
