<?php

namespace common\modules\settings\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\modules\settings\models\ZipCode;

/**
 * ZipCodeSearch represents the model behind the search form about `common\modules\settings\models\ZipCode`.
 */
class ZipCodeSearch extends ZipCode
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['zip', 'city', 'state', 'country'], 'safe'],
            [['latitude', 'longitude'], 'number'],
            [['timezone', 'dst', 'id'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = ZipCode::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'timezone' => $this->timezone,
            'dst' => $this->dst,
            'id' => $this->id,
        ]);

        $query->andFilterWhere(['like', 'zip', $this->zip])
            ->andFilterWhere(['like', 'city', $this->city])
            ->andFilterWhere(['like', 'state', $this->state])
            ->andFilterWhere(['like', 'country', $this->country]);

        return $dataProvider;
    }
}
