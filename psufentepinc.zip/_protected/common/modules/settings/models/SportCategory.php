<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "sport_category".
 *
 * @property integer $sport_category_id
 * @property integer $sport_id
 * @property integer $sport_sub_id
 * @property string $update_at
 *
 * @property StaffSport[] $staffSports
 */
class SportCategory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sport_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sport_id', 'sport_sub_id'], 'required'],
            [['sport_id', 'sport_sub_id'], 'integer'],
            [['update_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'sport_category_id' => 'Sport Category ID',
            'sport_id' => 'Sport ID',
            'sport_sub_id' => 'Sport Sub ID',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStaffSports()
    {
        return $this->hasMany(StaffSport::className(), ['sport_category_id' => 'sport_category_id']);
    }
}
