<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "audit".
 *
 * @property integer $history_id
 * @property string $history_name
 * @property string $history_description
 * @property string $created_at
 * @property integer $created_by
 * @property string $updated_at
 * @property integer $par_master_user_id
 * @property integer $stu_master_user_id
 * @property integer $emp_master_user_id
 * @property integer $updated_by
 * @property integer $status
 *
 * @property ParMaster $parMasterUser
 * @property StuMaster $stuMasterUser
 * @property EmpMaster $empMasterUser
 * @property Users $createdBy
 * @property Users $updatedBy
 */
class Audit extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'audit';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['history_name', 'created_at', 'created_by'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['created_by', 'par_master_user_id', 'stu_master_user_id', 'emp_master_user_id', 'updated_by', 'status'], 'integer'],
            [['history_name'], 'string', 'max' => 50],
            [['history_description'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'history_id' => 'History ID',
            'history_name' => 'History Name',
            'history_description' => 'History Description',
            'created_at' => 'Created At',
            'created_by' => 'Created By',
            'updated_at' => 'Updated At',
            'par_master_user_id' => 'Par Master User ID',
            'stu_master_user_id' => 'Stu Master User ID',
            'emp_master_user_id' => 'Emp Master User ID',
            'updated_by' => 'Updated By',
            'status' => 'Status',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParMasterUser()
    {
        return $this->hasOne(ParMaster::className(), ['par_master_user_id' => 'par_master_user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuMasterUser()
    {
        return $this->hasOne(StuMaster::className(), ['stu_master_user_id' => 'stu_master_user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEmpMasterUser()
    {
        return $this->hasOne(EmpMaster::className(), ['emp_master_user_id' => 'emp_master_user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'updated_by']);
    }
}
