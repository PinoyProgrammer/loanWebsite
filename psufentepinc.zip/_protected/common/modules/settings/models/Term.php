<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "term".
 *
 * @property integer $term_id
 * @property string $description
 * @property string $from_month
 * @property string $to_month
 * @property string $update_at
 *
 * @property SubTerm[] $subTerms
 */
class Term extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'term';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description', 'from_month', 'to_month'], 'required'],
            [['from_month', 'to_month', 'update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
            [['description'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'term_id' => 'Term ID',
            'description' => 'Description',
            'from_month' => 'From Month',
            'to_month' => 'To Month',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubTerms()
    {
        return $this->hasMany(SubTerm::className(), ['term_id' => 'term_id']);
    }
}
