<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "religion".
 *
 * @property integer $religion_id
 * @property string $description
 * @property string $update_at
 */
class Religion extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'religion';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description'], 'required'],
            [['update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
            [['description'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'religion_id' => 'Religion ID',
            'description' => 'Description',
            'update_at' => 'Update At',
        ];
    }
}
