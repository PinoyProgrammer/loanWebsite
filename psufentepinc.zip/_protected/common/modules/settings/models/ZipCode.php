<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "{{%zip_codes}}".
 *
 * @property string $zip
 * @property string $city
 * @property string $state
 * @property string $latitude
 * @property string $longitude
 * @property integer $timezone
 * @property integer $dst
 * @property string $country
 * @property integer $id
 */
class ZipCode extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%zip_codes}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['latitude', 'longitude'], 'number'],
            [['timezone', 'dst'], 'integer'],
            [['zip'], 'string', 'max' => 16],
            [['city', 'state'], 'string', 'max' => 30],
            [['country'], 'string', 'max' => 2],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'zip' => Yii::t('app', 'Postal / ZIP code.'),
            'city' => Yii::t('app', 'City.'),
            'state' => Yii::t('app', 'Province / State.'),
            'latitude' => Yii::t('app', 'Location latitude (decimal degrees).'),
            'longitude' => Yii::t('app', 'Location longitude (decimal degrees).'),
            'timezone' => Yii::t('app', 'Timezone (unused).'),
            'dst' => Yii::t('app', 'Daylight Savings Time (unused).'),
            'country' => Yii::t('app', 'Two letter ISO country code.'),
            'id' => Yii::t('app', 'ID'),
        ];
    }
}
