<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "Race".
 *
 * @property integer $race_id
 * @property string $description
 * @property string $update_at
 */
class Race extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'Race';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description'], 'required'],
            [['update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
            [['description'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'race_id' => 'Race ID',
            'description' => 'Description',
            'update_at' => 'Update At',
        ];
    }
}
