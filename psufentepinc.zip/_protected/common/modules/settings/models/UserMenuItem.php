<?php

namespace common\modules\settings\models;

use Yii;
use common\modules\user\models\User;

/**
 * This is the model class for table "{{%user_menu_item}}".
 *
 * @property integer $menu_item_id
 * @property integer $menu_id
 * @property string $menu_item_url
 * @property string $description
 * @property integer $dept_type
 * @property integer $company_type
 * @property integer $active
 * @property integer $ord
 */
class UserMenuItem extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%user_menu_item}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['menu_item_id', 'menu_id'], 'required'],
            [['menu_item_id', 'menu_id', 'dept_type', 'company_type', 'active', 'ord'], 'integer'],
            [['menu_item_url', 'description'], 'string', 'max' => 128],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'menu_item_id' => Yii::t('app', 'Menu Item ID'),
            'menu_id' => Yii::t('app', 'Menu ID'),
            'menu_item_url' => Yii::t('app', 'Menu Item Url'),
            'description' => Yii::t('app', 'Description'),
            'dept_type' => Yii::t('app', 'Dept Type'),
            'company_type' => Yii::t('app', 'Company Type'),
            'active' => Yii::t('app', 'Active'),
            'ord' => Yii::t('app', 'Ord'),
        ];
    }

    public static function menuItems($menu_id, $type) {
        $user = User::findOne(\Yii::$app->user->id);
        $sql = "select a.* from ".UserMenuItem::tableName()." a join ". \common\modules\user\models\UserPermission::tableName()." b on a.menu_item_id=b.menu_item_id
where b.user_id=" . $user->user_id . " and a.menu_id=$menu_id and type='$type'
union
select a.* from ".UserMenuItem::tableName()." a join ". \common\modules\user\models\UserGroupPermission::tableName()." b on a.menu_item_id=b.menu_item_id
where b.group_id=" . $user->role_id . "  and a.menu_id=$menu_id and type='$type'
order by ord";
        $connection = Yii::$app->getDb();
        $menus = $connection->createCommand($sql)->queryAll();
        $paths = [];
        foreach ($menus as $menu) {
            $paths[$menu['menu_item_url']] = ['div_class' => $menu['fa'], 'description' => $menu['description']];
        }
        return $paths;
    }

}
