<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "subject_teacher".
 *
 * @property integer $subject_teacher_id
 * @property integer $emp_master_id
 * @property integer $grade_subject_id
 * @property integer $class_id
 * @property string $update_at
 * @property integer $deleted
 */
class SubjectTeacher extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'subject_teacher';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['emp_master_id', 'grade_subject_id', 'class_id'], 'required'],
            [['emp_master_id', 'grade_subject_id', 'class_id', 'deleted'], 'integer'],
            [['update_at'], 'safe'],
            [['emp_master_id', 'grade_subject_id', 'class_id'], 'unique', 'targetAttribute' => ['emp_master_id', 'grade_subject_id', 'class_id'], 'message' => 'The combination of Emp Master ID, Grade Subject ID and Class ID has already been taken.'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'subject_teacher_id' => 'Subject Teacher ID',
            'emp_master_id' => 'Emp Master ID',
            'grade_subject_id' => 'Grade Subject ID',
            'class_id' => 'Class ID',
            'update_at' => 'Update At',
            'deleted' => 'Deleted',
        ];
    }
}
