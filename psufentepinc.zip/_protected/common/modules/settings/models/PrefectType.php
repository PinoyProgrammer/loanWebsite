<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "prefect_type".
 *
 * @property integer $prefect_type_id
 * @property string $description
 * @property string $update_at
 *
 * @property StuPrefect[] $stuPrefects
 */
class PrefectType extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'prefect_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description'], 'required'],
            [['update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
            [['description'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'prefect_type_id' => 'Prefect Type ID',
            'description' => 'Description',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuPrefects()
    {
        return $this->hasMany(StuPrefect::className(), ['prefect_type_id' => 'prefect_type_id']);
    }
}
