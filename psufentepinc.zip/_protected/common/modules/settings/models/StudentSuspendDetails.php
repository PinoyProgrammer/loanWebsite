<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "student_suspend_details".
 *
 * @property integer $suspend_stu_master_id
 * @property integer $stu_master_id
 * @property string $from_date
 * @property string $to_date
 * @property integer $stu_discipline_id
 * @property string $description
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_at
 * @property string $update_at
 * @property integer $no_of_days
 * @property string $activated_date
 * @property string $curtailed_or_extended_reason
 *
 * @property Users $createdBy
 * @property Users $updatedBy
 * @property StuMaster $stuMaster
 * @property StuDiscipline $stuDiscipline
 */
class StudentSuspendDetails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student_suspend_details';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['stu_master_id', 'from_date', 'to_date', 'stu_discipline_id', 'created_by', 'no_of_days'], 'required'],
            [['stu_master_id', 'stu_discipline_id', 'created_by', 'updated_by', 'no_of_days'], 'integer'],
            [['from_date', 'to_date', 'created_at', 'update_at', 'activated_date'], 'safe'],
            [['description', 'curtailed_or_extended_reason'], 'string', 'max' => 150],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['updated_by' => 'user_id']],
            [['stu_master_id'], 'exist', 'skipOnError' => true, 'targetClass' => StuMaster::className(), 'targetAttribute' => ['stu_master_id' => 'stu_master_id']],
            [['stu_discipline_id'], 'exist', 'skipOnError' => true, 'targetClass' => StuDiscipline::className(), 'targetAttribute' => ['stu_discipline_id' => 'stu_discipline_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'suspend_stu_master_id' => 'Suspend Stu Master ID',
            'stu_master_id' => 'Stu Master ID',
            'from_date' => 'From Date',
            'to_date' => 'To Date',
            'stu_discipline_id' => 'Stu Discipline ID',
            'description' => 'Description',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
            'no_of_days' => 'No Of Days',
            'activated_date' => 'Activated Date',
            'curtailed_or_extended_reason' => 'Curtailed Or Extended Reason',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuMaster()
    {
        return $this->hasOne(StuMaster::className(), ['stu_master_id' => 'stu_master_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuDiscipline()
    {
        return $this->hasOne(StuDiscipline::className(), ['stu_discipline_id' => 'stu_discipline_id']);
    }
}
