<?php

namespace common\modules\settings\models;

use Yii;
use common\modules\user\models\User;

/**
 * This is the model class for table "student_sub_term_mark".
 *
 * @property integer $student_sub_term_mark_id
 * @property integer $student_term_marks_id
 * @property integer $sub_term_id
 * @property integer $grading_id
 * @property integer $is_absent
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_at
 * @property string $update_at
 * @property double $marks
 * @property integer $edit_mark_state
 *
 * @property User $createdBy
 * @property User $updatedBy
 * @property StudentTermMark $studentTermMarks
 * @property Grading $grading
 * @property SubTerm $subTerm
 */
class StudentSubTermMark extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student_sub_term_mark';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['student_term_marks_id', 'sub_term_id', 'created_by'], 'required'],
            [['student_term_marks_id', 'sub_term_id', 'grading_id', 'is_absent', 'created_by', 'updated_by', 'edit_mark_state'], 'integer'],
            [['created_at', 'update_at'], 'safe'],
            [['marks'], 'number'],
            [['student_term_marks_id', 'sub_term_id', 'grading_id'], 'unique', 'targetAttribute' => ['student_term_marks_id', 'sub_term_id', 'grading_id'], 'message' => 'The combination of Student Term Marks ID, Sub Term ID and Grading ID has already been taken.'],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'user_id']],
            [['student_term_marks_id'], 'exist', 'skipOnError' => true, 'targetClass' => StudentTermMark::className(), 'targetAttribute' => ['student_term_marks_id' => 'student_term_marks_id']],
            [['grading_id'], 'exist', 'skipOnError' => true, 'targetClass' => Grading::className(), 'targetAttribute' => ['grading_id' => 'grading_id']],
            [['sub_term_id'], 'exist', 'skipOnError' => true, 'targetClass' => SubTerm::className(), 'targetAttribute' => ['sub_term_id' => 'sub_term_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'student_sub_term_mark_id' => 'Student Sub Term Mark ID',
            'student_term_marks_id' => 'Student Term Marks ID',
            'sub_term_id' => 'Sub Term ID',
            'grading_id' => 'Grading ID',
            'is_absent' => 'Is Absent',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
            'marks' => 'Marks',
            'edit_mark_state' => 'Edit Mark State',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['user_id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStudentTermMarks()
    {
        return $this->hasOne(StudentTermMark::className(), ['student_term_marks_id' => 'student_term_marks_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGrading()
    {
        return $this->hasOne(Grading::className(), ['grading_id' => 'grading_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubTerm()
    {
        return $this->hasOne(SubTerm::className(), ['sub_term_id' => 'sub_term_id']);
    }
}
