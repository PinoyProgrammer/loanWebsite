<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "{{%country}}".
 *
 * @property string $countrycode
 * @property string $country_name
 * @property string $nationality
 * @property int $company_id
 * @property int $country_id
 * @property int $created_by
 * @property int $updated_by
 * @property int $is_status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property State[] $states
 */
class Country extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%country}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['countrycode'], 'required'],
            [['company_id', 'created_by', 'updated_by', 'is_status'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['countrycode'], 'string', 'max' => 11],
            [['country_name', 'nationality'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'countrycode' => Yii::t('app', 'Countrycode'),
            'country_name' => Yii::t('app', 'Country Name'),
            'nationality' => Yii::t('app', 'Nationality'),
            'company_id' => Yii::t('app', 'Company ID'),
            'country_id' => Yii::t('app', 'Country ID'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
            'is_status' => Yii::t('app', 'Is Status'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStates()
    {
        return $this->hasMany(State::className(), ['country_id' => 'country_id']);
    }
}
