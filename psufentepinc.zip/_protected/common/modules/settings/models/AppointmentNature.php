<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "appointment_nature".
 *
 * @property integer $appointment_nature_id
 * @property string $description
 * @property string $update_at
 */
class AppointmentNature extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'appointment_nature';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description'], 'required'],
            [['update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'appointment_nature_id' => 'Appointment Nature ID',
            'description' => 'Description',
            'update_at' => 'Update At',
        ];
    }
}
