<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "working_segment".
 *
 * @property integer $working_segment_id
 * @property string $description
 * @property string $update_at
 */
class WokingSegment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'working_segment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description'], 'required'],
            [['update_at'], 'safe'],
            [['description'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'working_segment_id' => 'Working Segment ID',
            'description' => 'Description',
            'update_at' => 'Update At',
        ];
    }
}
