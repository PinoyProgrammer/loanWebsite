<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "approved_reasons".
 *
 * @property integer $id
 * @property string $reasons
 */
class ApprovedReason extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'approved_reasons';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['reasons'], 'required'],
            [['reasons'], 'string', 'max' => 45],
            [['reasons'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'reasons' => 'Reasons',
        ];
    }
}
