<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "achievement".
 *
 * @property integer $achievement_id
 * @property string $description
 * @property integer $stu_master_id
 * @property string $activity
 * @property string $year
 * @property integer $club_society_id
 * @property integer $is_academic
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_at
 * @property string $update_at
 *
 * @property Users $createdBy
 * @property Users $updatedBy
 * @property StuMaster $stuMaster
 */
class Achievement extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'achievement';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['description', 'stu_master_id', 'is_academic', 'created_by'], 'required'],
            [['stu_master_id', 'club_society_id', 'is_academic', 'created_by', 'updated_by'], 'integer'],
            [['year', 'created_at', 'update_at'], 'safe'],
            [['description'], 'string', 'max' => 400],
            [['activity'], 'string', 'max' => 45],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['updated_by' => 'user_id']],
            [['stu_master_id'], 'exist', 'skipOnError' => true, 'targetClass' => StuMaster::className(), 'targetAttribute' => ['stu_master_id' => 'stu_master_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'achievement_id' => 'Achievement ID',
            'description' => 'Description',
            'stu_master_id' => 'Stu Master ID',
            'activity' => 'Activity',
            'year' => 'Year',
            'club_society_id' => 'Club Society ID',
            'is_academic' => 'Is Academic',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStuMaster()
    {
        return $this->hasOne(StuMaster::className(), ['stu_master_id' => 'stu_master_id']);
    }
}
