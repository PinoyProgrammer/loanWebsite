<?php

namespace common\modules\settings\models;

use Yii;

/**
 * This is the model class for table "{{%zip_code_distance}}".
 *
 * @property integer $id
 * @property string $from_code
 * @property string $to_code
 * @property double $distance
 */
class ZipCodeDistance extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%zip_code_distance}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['from_code', 'to_code', 'distance'], 'required'],
            [['distance'], 'number'],
            [['from_code', 'to_code'], 'string', 'max' => 10],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'from_code' => Yii::t('app', 'From Code'),
            'to_code' => Yii::t('app', 'To Code'),
            'distance' => Yii::t('app', 'Distance'),
        ];
    }

    public static function distance($zip_a, $zip_b, $unit = 'K') {
        $zip_code_distance = ZipCodeDistance::find()
                ->where(['from_code' => $zip_a, 'to_code' => $zip_b])
                ->orWhere(['from_code' => $zip_b, 'to_code' => $zip_a])
                ->one();
        if (is_object($zip_code_distance)) {
            return $zip_code_distance->distance;
        }
        $zip_code_a = ZipCode::findOne(['zip' => $zip_a]);
        $zip_code_b = ZipCode::findOne(['zip' => $zip_b]);
        if (!is_object($zip_code_a) || !is_object($zip_code_b)) {
            return 0;
        }
        $lat1 = $zip_code_a->latitude;
        $lon1 = $zip_code_a->longitude;
        $lat2 = $zip_code_b->latitude;
        $lon2 = $zip_code_b->longitude;
        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        $unit = strtoupper($unit);

        if ($unit == "K") {
            return number_format(($miles * 1.609344), 1);
        } else if ($unit == "N") {
            return ($miles * 0.8684);
        } else {
            return $miles;
        }
    }

}
