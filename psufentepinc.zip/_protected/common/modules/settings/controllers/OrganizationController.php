<?php

/**
 * OrganizationController implements the CRUD actions for Organization model.
 */

namespace common\modules\settings\controllers;

use Yii;
use common\modules\settings\models\Organization;
use common\modules\settings\models\OrganizationSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

class OrganizationController extends Controller {

    public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                    [
                        'allow' => false,
                        'roles' => ['?'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Organization models.
     * @return mixed
     */
    public function actionIndexAll() {
        $searchModel = new OrganizationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $model = new Organization();
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model,
        ]);
    }

    public function actionIndex() {
        $searchModel = new OrganizationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $model = Organization::find()->andWhere(['created_by' => Yii::$app->user->id])->all();
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model,
        ]);
    }

    /**
     * Displays a single Organization model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Organization model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $chkOrg = Organization::find()->all();
        if (!empty($chkOrg)) {
            throw new NotFoundHttpException('The requested page does not exist.');
        }

        $model = new Organization();
        if (isset($_POST['Organization']) && $model->load(Yii::$app->request->post())) {
            $model->attributes = $_POST['Organization'];
            $model->org_email = strtolower($_POST['Organization']['org_email']);
            $model->created_by = 1;
            $model->created_at = new \yii\db\Expression('NOW()');

            ob_start();

            if (!empty($_FILES['Organization']['tmp_name']['org_logo'])) {
                $file = UploadedFile::getInstance($model, 'org_logo');
                $dir1 = Yii::getAlias('@webroot') . '/site/data/org_images/';
                $ext = substr(strrchr($model->org_logo, '.'), 1);
                $photo = $old_photo;
                if (file_exists($dir1 . $photo) && $photo != NULL) {
                    unlink($dir1 . $photo);
                }
                if ($ext != null) {
                    $newfname = $model->org_id . '.' . $ext;
                    $model->org_logo->saveAs(Yii::getAlias('@webroot') . '/site/data/org_images/' . $model->org_logo = $newfname);
                }
                $model->org_logo_type = $file->type;
            }
            if ($model->save()) {
                return $this->redirect(['view', 'id' => $model->org_id]);
            }
        }

        return $this->render('create', [
                    'model' => $model,
        ]);
    }

    /**
     * Updates an existing Organization model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        if (isset($_POST['Organization']) && $model->load(Yii::$app->request->post())) {
            $model->attributes = $_POST['Organization'];

            $model->org_email = strtolower($_POST['Organization']['org_email']);
            $model->updated_by = Yii::$app->user->id;
            $model->updated_at = new \yii\db\Expression('NOW()');

            if (!empty($_FILES['Organization']['tmp_name']['org_logo'])) {
                $model->org_logo = UploadedFile::getInstance($model, 'org_logo');
                $dir1 = Yii::getAlias('@webroot') . '/site/data/org_images/';
                $ext = substr(strrchr($model->org_logo, '.'), 1);
                if ($ext != null) {
                    $newfname = $model->org_id . '.' . $ext;
                    $model->org_logo->saveAs(Yii::getAlias('@webroot') . '/site/data/org_images/' . $model->org_logo = $newfname);
                }
                $model->org_logo_type = $ext;
            }

            if ($model->save()) {
                return $this->redirect(['view', 'id' => $model->org_id]);
            }
        } else {
            return $this->render('update', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Organization model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Organization model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Organization the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Organization::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
