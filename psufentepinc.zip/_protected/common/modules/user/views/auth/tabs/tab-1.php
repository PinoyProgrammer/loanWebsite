
<?php

use kartik\builder\FormGrid;
use kartik\builder\Form;
use yii\helpers\ArrayHelper;
echo Form::widget([
    'model' => $user,
    'form' => $form,
    'columns' => 1,
    'attributes' => [
        'username' => ['type' => Form::INPUT_TEXT, "readonly" => "readonly"],
        'email' => ['type' => Form::INPUT_TEXT, "readonly" => "readonly"],
    ]
]);
echo Form::widget([
    'model' => $profile,
    'form' => $form,
    'columns' => 1,
    'attributes' => [
        'first_name' => ['type' => Form::INPUT_TEXT,],
        'last_name' => ['type' => Form::INPUT_TEXT,],
        'mobile' => ['type' => Form::INPUT_TEXT,],
    ],
]);
echo Form::widget([
    'model' => $user,
    'form' => $form,
    'columns' => 1,
    'attributes' => [
        'role_id' => [
            'type' => Form::INPUT_DROPDOWN_LIST,
            "placeholder" => "--Select--",
            'items' => [ArrayHelper::map(common\modules\user\models\Role::find()->all(), 'id', 'name')]],
        'status' => [
            'type' => Form::INPUT_DROPDOWN_LIST,
            'items' => ["--Select--",0 => "Active", 1 => "In Active"]
        ],
    ],
]);
?>


