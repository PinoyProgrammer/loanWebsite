<?php

use kartik\detail\DetailView;
use yii\helpers\Html;

/**
 * @var yii\web\View $this
 * @var common\modules\user\models\User $user
 */
$this->title = $user->profile->fullName;
$this->params['breadcrumbs'][] = ['label' => Yii::t('user', 'Users'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<h1><?= Html::encode($this->title) ?></h1>
<p>
    <?= Html::a(Yii::t('user', 'Update'), ['update', 'id' => $user->id], ['class' => 'btn btn-primary']) ?>
    <?=
    Html::a(Yii::t('user', 'Delete'), ['delete', 'id' => $user->id], [
        'class' => 'btn btn-danger',
        'data' => [
            'confirm' => Yii::t('user', 'Are you sure you want to delete this item?'),
            'method' => 'post',
        ],
    ])
    ?>
</p>
<?php
$profile = $user->profile;
$org = $user->org;
$addressReference = $user->addressReference;
$address = new \common\modules\address\models\Address;
?>

<div class="row">
    <?php
    echo DetailView::widget([
        'model' => $user,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 1: Basic Info', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['username', 'email',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 2: User Details', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['first_name', 'last_name', 'phone',],],
        ],
        'mode' => 'view',
    ]);

    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 3: Preference', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['user_language', 'default_theme', 'block_notif_count', 'use_personal_db_cb',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 4: Associations', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['hr_employee_id', 'supplier_id', 'ar_customer_id',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 5: Profile Picture', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['avatar',],],
        ],
        'mode' => 'view',
    ]);

    if (count($addressReference) > 0) {
        foreach ($addressReference as $ar) {

            if (is_object($ar)) {
                $addrs = $ar->address;
                echo DetailView::widget([
                    'model' => $addrs,
                    'attributes' => [
                        'address_name',
                        'type',
                        'description',
                        'phone',
                        'email:email',
                        'website:url',
                        'address',
                        'country',
                        'postal_code',
                        'default_cb',
                        'status:boolean',
                        'optionLine.description',
                        'rev_number'
                    ]
                ]);
            }
        }
    }

    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 7: Prefernce', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['user_language', 'default_theme', 'block_notif_count', 'use_personal_db_cb',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 8: Prefernce', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['user_language', 'default_theme', 'block_notif_count', 'use_personal_db_cb',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 9: Prefernce', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['user_language', 'default_theme', 'block_notif_count', 'use_personal_db_cb',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 10: Prefernce', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['user_language', 'default_theme', 'block_notif_count', 'use_personal_db_cb',],],
        ],
        'mode' => 'view',
    ]);
    echo DetailView::widget([
        'model' => $profile,
        'attributes' => [
            ['group' => true, 'label' => 'SECTION 11: Prefernce', 'rowOptions' => ['class' => 'info']],
            ['columns' => ['user_language', 'default_theme', 'block_notif_count', 'use_personal_db_cb',],],
        ],
        'mode' => 'view',
    ]);
    ?>
</div>
<hr/>


<div class="col-md-9">


</div>


<hr/>



