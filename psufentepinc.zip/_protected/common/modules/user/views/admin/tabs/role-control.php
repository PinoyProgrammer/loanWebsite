<div id ="form_line" class="form_line">
    <form action=""  method="post" id="user_role"  name="user_role">
        <table id="form_line_data_table" class="table table-bordered">
            <thead>
                <tr>
                    <th><?php echo Yii::t('user', 'Action') ?></th>
                    <th><?php echo Yii::t('user', 'User Role Access Id') ?>#</th>
                    <th><?php echo Yii::t('user', 'Role Name') ?></th>
                </tr>
            </thead>
            <tbody class="form_data_line_tbody user_role_assignment_values">
            </tbody>
        </table>


    </form> 
</div>