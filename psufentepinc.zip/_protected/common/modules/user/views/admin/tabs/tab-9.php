<?php


use common\modules\user\models\User;
$user1 = User::find(Yii::$app->user->id)->one();
$org1 = $user1->org;
?>
<div class="col-md-5">
    <?php
    echo yii\widgets\DetailView::widget([
                    'model' => $org1,
                    'attributes' => [
                        'org',
                        'code',
                        'description',
                    ]
                ]);?>
</div>
