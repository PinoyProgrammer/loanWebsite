<div id ="form_line2" class="form_line2">
    <form action=""  method="post" id="user_group_line"  name="user_group_line">
        <table class="table table-bordered">
            <thead> 
                <tr>
                    <th><?php echo Yii::t('user', 'Action') ?></th>
                    <th><?php echo Yii::t('user', 'Group Access Id') ?>#</th>
                    <th><?php echo Yii::t('user', 'Group Name') ?></th>
                </tr>
            </thead>
            <tbody class="form_data_line_tbody2 user_group_values" >
            </tbody>
        </table>
    </form>
</div>