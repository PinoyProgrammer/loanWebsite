
<?php


use kartik\builder\Form;

echo Form::widget([
    'model' => $user,
    'form' => $form,
    'columns' => 1,
    'attributes' => [
        'username' => ['type' => Form::INPUT_TEXT,"readonly"=>"readonly"],
        'email' => ['type' => Form::INPUT_TEXT,"readonly"=>"readonly"],
    ]
]);
echo Form::widget([
    'model' => $profile,
    'form' => $form,
    'columns' => 1,
    'attributes' => [
        'first_name' => ['type' => Form::INPUT_TEXT,],
        'last_name' => ['type' => Form::INPUT_TEXT,],
        'mobile' => ['type' => Form::INPUT_TEXT,],
    ],
]);
?>


