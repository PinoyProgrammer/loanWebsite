<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%favorite}}".
 *
 * @property integer $id
 * @property string $favorite_at
 * @property integer $favorite_by
 * @property integer $favorited
 */
class Favorite extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%favorite}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'favorite_at', 'favorite_by', 'favorited'], 'required'],
            [['id', 'favorite_by', 'favorited'], 'integer'],
            [['favorite_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'favorite_at' => Yii::t('app', 'Favorite At'),
            'favorite_by' => Yii::t('app', 'Favorite By'),
            'favorited' => Yii::t('app', 'Favorited'),
        ];
    }
}
