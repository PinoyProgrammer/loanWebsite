<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "bamboo_users_office".
 *
 * @property integer $id
 * @property integer $user_id
 * @property integer $office_id
 * @property integer $type
 */
class UsersOffice extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return static::getDb()->tablePrefix . 'bamboo_users_office';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id', 'office_id'], 'required'],
            [['user_id', 'office_id'], 'integer']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('stock', 'ID'),
            'user_id' => Yii::t('stock', 'User'),
            'office_id' => Yii::t('stock', 'Station'),
            'type' => Yii::t('stock', 'Type'),
        ];
    }

    public function getOffice() {
        return $this->hasOne(\common\modules\portal\models\Office::className(), ['id' => 'office_id']);
    }

    public function getUsers() {
        return $this->hasMany(Profile::className(), ['user_id' => 'user_id']);
    }

    public static function get_office_user_stations() {
        $stations = array();
        $userOffices = UsersOffice::find()
                ->where(["user_id" => Yii::$app->user->id, "type" => 1])
                ->orderBy("office_id")
                ->all();
        foreach ($userOffices as $office) {
            $off = $office->office;
            if (is_object($off)&&$off->is_office == 1) {
                $stations[$off->office_id] = $off->office_name;
            }
        }
        return $stations;
    }

    public function get_office_user_stations_type_2() {
        $stations = array();
        $userOffices = UsersOffice::find()->where(["user_id" => Yii::$app->user->id, "type" => 2])->orderBy("office_id")->all();
        foreach ($userOffices as $office) {
            $off = $office->office;
            if ($off->is_fuel == 1) {
                $stations[$off->office_code] = $off->office_name;
            }
        }
        return $stations;
    }
    public function get_office_user_stations_is_loads() {
        $stations = array();
        $userOffices = UsersOffice::find()
                ->where(["user_id" => Yii::$app->user->id, "type" => 3])
                ->orderBy("office_id")
                ->all();
        foreach ($userOffices as $office) {
            $off = $office->office;
            if (is_object($off)&&$off->is_loads == 1) {
                $stations[$off->office_id] = $off->office_name;
            }
        }
        return $stations;
    }

    public static $types = [
        1 => "Sales and Reconciliations",
        2 => "Fuel and Daily Log",
        3 => "Stationery",
        4 => "Loads",
        5 => "Catering"
    ];

}
