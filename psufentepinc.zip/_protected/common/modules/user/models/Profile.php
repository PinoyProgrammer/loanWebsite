<?php

namespace common\modules\user\models;

use Yii;
use yii\db\ActiveRecord;


/**
 * This is the model class for table "{{%_profile}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $first_name
 * @property string $last_name
 * @property string $mobile
 * @property string $language
 * @property string $avatar
 * @property string $created_at
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $updated_at
 * @property Users $user
 * @property Users $user0
 */
class Profile extends \yii\db\ActiveRecord {
   
    /**
     * @inheritdoc
     */
    public static function tableName() {
        return static::getDb()->tablePrefix . '_profile';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id', 'created_by', 'updated_by',], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['first_name', 'last_name'], 'string', 'max' => 255],
            [['mobile','language'], 'string', 'max' => 12],
            [['avatar'], 'file', 'extensions' => 'jpg, jpeg, gif, png', 'skipOnEmpty' => true,
                'checkExtensionByMimeType' => true, 'on' => 'photo-upload'],
            [['avatar'], 'string', 'max' => 100],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('user', 'ID'),
            'user_id' => Yii::t('user', 'User ID'),
            'first_name' => Yii::t('user', 'First Name'),
            'last_name' => Yii::t('user', 'Last Name'),
            'mobile' => Yii::t('user', 'Mobile'),
            'avatar' => Yii::t('user', 'Avatar'),
            'address' => Yii::t('user', 'Address'),
            'language'=>Yii::t('user', 'Language'),
            'created_at' => Yii::t('user', 'Created At'),
            'updated_at' => Yii::t('user', 'Updated At'),
            'created_by' => Yii::t('user', 'Created By'),
            'updated_by' => Yii::t('user', 'Updated By'),
        ];
    }

public function behaviors() {
        return [
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'value' => function () {
                    return date("Y-m-d H:i:s");
                },
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => 'created_at',
                    ActiveRecord::EVENT_BEFORE_UPDATE => 'updated_at',
                ],
            ],
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser() {
        return $this->hasOne(User::className(), ['user_id' => 'user_id']);
    }

    public function setUser($userId) {
        $this->user_id = $userId;
        return $this;
    }

    public static function getGenderOption() {
        return [
            "M" => 'Male',
            "F" => 'Female',
            "0" => 'Not userlicable',
        ];
}

    public static function getPageSize() {
        return [
            10 => '10 per page',
            15 => '15 per page',
            25 => '20 per page',
            30 => '30 per page',
            35 => '35 per page',
        ];
    }

    public static function getNotification() {
        return [
            1 => 'Yes',
            0 => 'No',
        ];
    }

    public static function getAvatar($imgName) {
        $dispImg = is_file(Yii::getAlias('@uploads') . '/user_images/' . $imgName) ? true : false;
        return Yii::getAlias('@uploads') . "/" . (($dispImg) ? $imgName : "no-photo.png");
    }

    public function getUserDetails() {
        return $this->hasOne(\common\modules\project\models\UserDetails::className(), ['user_id' => 'user_id']);
    }

    public function getFullName() {
        if($this->first_name==$this->last_name){
           return  $this->first_name;
        }
        return $this->first_name.' '. $this->last_name;
    }

   

    public static function get_transation_id($sex) {
        $txid = Profile::find()->select("revision_number")->orderBy("revision_number desc")->one();
        if ($txid) {
            $txid = $txid->revision_number++;         
            
        } else {
            $c="1000001";
            $txid = $sex=="M"?"G" . $c:"B" . $c;
        }

        return strtoupper($txid);
    }
    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = Yii::$app->user->id;
            $this->created_at = date("Y-m-d H:i");
            $this->updated_by = Yii::$app->user->id;
            $this->updated_at = date("Y-m-d H:i");
            return true;
        } else {
            $this->updated_by = Yii::$app->user->id;
            $this->updated_at = date("Y-m-d H:i");
            return true;
        }
    }

}
