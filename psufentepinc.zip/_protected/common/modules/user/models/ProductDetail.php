<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%bamboo_product_details}}".
 *
 * @property integer $id
 * @property string $product_id
 * @property integer $branch_id
 * @property double $unitcost
 * @property integer $uom_id
 * @property double $opening_stock
 * @property double $qty_supplied
 * @property double $qty_issued
 * @property double $qty_sold
 * @property double $qty_return
 * @property double $qty_adjustment
 * @property double $qty_on_order
 * @property double $qty_available
 * @property double $in_stock
 * @property double $back_order
 * @property double $order_balance
 * @property double $stock_count
 * @property integer $tax_id
 * @property double $stock_diff
 * @property integer $cfactor
 * @property double $qty_return_in
 * @property double $qty_transfer_out
 * @property double $qty_transfer_in
 * @property double $qty_return_out
 * @property integer $supplier_id
 */
class ProductDetail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%bamboo_product_details}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['branch_id'], 'required'],
            [['branch_id', 'uom_id', 'tax_id', 'cfactor', 'supplier_id'], 'integer'],
            [['unitcost', 'opening_stock', 'qty_supplied', 'qty_issued', 'qty_sold', 'qty_return', 'qty_adjustment', 'qty_on_order', 'qty_available', 'in_stock', 'back_order', 'order_balance', 'stock_count', 'stock_diff', 'qty_return_in', 'qty_transfer_out', 'qty_transfer_in', 'qty_return_out'], 'number'],
            [['product_id'], 'string', 'max' => 128],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'product_id' => Yii::t('app', 'Product ID'),
            'branch_id' => Yii::t('app', 'Branch ID'),
            'unitcost' => Yii::t('app', 'Unitcost'),
            'uom_id' => Yii::t('app', 'Uom ID'),
            'opening_stock' => Yii::t('app', 'Opening Stock'),
            'qty_supplied' => Yii::t('app', 'Qty Supplied'),
            'qty_issued' => Yii::t('app', 'Qty Issued'),
            'qty_sold' => Yii::t('app', 'Qty Sold'),
            'qty_return' => Yii::t('app', 'Qty Return'),
            'qty_adjustment' => Yii::t('app', 'Qty Adjustment'),
            'qty_on_order' => Yii::t('app', 'Qty On Order'),
            'qty_available' => Yii::t('app', 'Qty Available'),
            'in_stock' => Yii::t('app', 'In Stock'),
            'back_order' => Yii::t('app', 'Back Order'),
            'order_balance' => Yii::t('app', 'Order Balance'),
            'stock_count' => Yii::t('app', 'Stock Count'),
            'tax_id' => Yii::t('app', 'Tax ID'),
            'stock_diff' => Yii::t('app', 'Stock Diff'),
            'cfactor' => Yii::t('app', 'Cfactor'),
            'qty_return_in' => Yii::t('app', 'Qty Return In'),
            'qty_transfer_out' => Yii::t('app', 'Qty Transfer Out'),
            'qty_transfer_in' => Yii::t('app', 'Qty Transfer In'),
            'qty_return_out' => Yii::t('app', 'Qty Return Out'),
            'supplier_id' => Yii::t('app', 'Supplier ID'),
        ];
    }
}
