<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%user_permissions}}".
 *
 * @property integer $id
 * @property integer $menu_id
 * @property integer $menu_item_id
 * @property integer $user_id
 * @property integer $can_create
 * @property integer $can_update
 * @property integer $can_view
 * @property integer $can_delete
 * @property integer $can_chmod
 * @property integer $created_by
 * @property string $created_at
 */
class UserPermission extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%user_permissions}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['menu_id', 'menu_item_id', 'user_id', 'can_create', 'can_update', 'can_view', 'can_delete', 'can_chmod', 'created_by'], 'integer'],
            [['created_at'], 'required'],
            [['created_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'menu_id' => Yii::t('app', 'Menu ID'),
            'menu_item_id' => Yii::t('app', 'Menu Item ID'),
            'user_id' => Yii::t('app', 'Group ID'),
            'can_create' => Yii::t('app', 'Can Create'),
            'can_update' => Yii::t('app', 'Can Update'),
            'can_view' => Yii::t('app', 'Can View'),
            'can_delete' => Yii::t('app', 'Can Delete'),
            'can_chmod' => Yii::t('app', 'Can Chmod'),
            'created_by' => Yii::t('app', 'Created By'),
            'created_at' => Yii::t('app', 'Created At'),
        ];
    }

    public static function isRoleAllowed($menuitemid, $userid) {
        $sql = "select menu_id,menu_item_id,group_id from user_group_permission
WHERE menu_item_id=$menuitemid and group_id in (select role_id from users where user_id=$userid)
union 
select menu_id,menu_item_id,user_id  from user_permissions WHERE menu_item_id=$menuitemid and user_id=$userid; ";
        $connection = Yii::$app->getDb();
        $result = $connection->createCommand($sql)->queryAll();
        if (count($result) > 0) {
            return true;
        }
        return false;
    }

    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = Yii::$app->user->id;
            $this->created_at = date("Y-m-d H:i");
            return true;
        } else {
            $this->created_by = Yii::$app->user->id;
            $this->created_at = date("Y-m-d H:i");
            return true;
        }
    }

}
