<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%chat_details}}".
 *
 * @property integer $id
 * @property integer $chat_id
 * @property string $message
 * @property integer $sender
 * @property integer $status_read
 * @property integer $status_notified
 * @property string $status_read_at
 * @property string $status_notified_at
 * @property string $status_sent_at
 * @property string $createt_at
 *
 * @property Chats $chat
 */
class ChatDetails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%chat_details}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['chat_id', 'message', 'sender', 'status_read'], 'required'],
            [['chat_id', 'sender', 'status_read', 'status_notified'], 'integer'],
            [['message'], 'string'],
            [['status_read_at', 'status_notified_at', 'status_sent_at', 'createt_at'], 'safe'],
            [['chat_id'], 'exist', 'skipOnError' => true, 'targetClass' => Chats::className(), 'targetAttribute' => ['chat_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'chat_id' => Yii::t('app', 'Chat ID'),
            'message' => Yii::t('app', 'Message'),
            'sender' => Yii::t('app', 'Sender'),
            'status_read' => Yii::t('app', 'Status Read'),
            'status_notified' => Yii::t('app', 'Status Notified'),
            'status_read_at' => Yii::t('app', 'Status Read At'),
            'status_notified_at' => Yii::t('app', 'Status Notified At'),
            'status_sent_at' => Yii::t('app', 'Status Sent At'),
            'createt_at' => Yii::t('app', 'Createt At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getChat()
    {
        return $this->hasOne(Chats::className(), ['id' => 'chat_id']);
    }
}
