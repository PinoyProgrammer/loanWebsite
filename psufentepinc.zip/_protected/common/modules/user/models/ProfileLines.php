<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%profile_lines}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $type
 * @property string $name
 * @property integer $status
 * @property string $created_at
 * @property string $updated_at
 * @property integer $created_by
 * @property integer $updated_by
 *
 * @property Users $user
 */
class ProfileLines extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static  $user_lines=['city','dob_day','dob_month','dob_year','player_position','player_year_group','skill_level','youth_senior','zip'];
    public static  $user_lines_desc=[   
        'city'=>'City',
        'dob_day'=>'Day Of Birth',
        'dob_month'=>'Month of Birth',
        'dob_year'=>'Year of Birth',
        'player_position'=>'Player Position',
        'player_year_group'=>'Year Group',
        'skill_level'=>'Skill Level',
        'youth_senior'=>'Youth/Senior',
        'zip'=>'Zip'];
        
    public static function tableName()
    {
        return '{{%profile_lines}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'type', 'name', 'status', 'created_at', 'updated_at'], 'required'],
            [['user_id', 'status', 'created_by', 'updated_by'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['type'], 'string', 'max' => 64],
            [['name'], 'string', 'max' => 255],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'user_id' => Yii::t('app', 'User ID'),
            'type' => Yii::t('app', 'Type'),
            'name' => Yii::t('app', 'Name'),
            'status' => Yii::t('app', 'Status'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }
    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = Yii::$app->user->id;
            $this->created_at = date("Y-m-d H:i:s");
            $this->updated_by = Yii::$app->user->id;
            $this->updated_at = date("Y-m-d H:i:s");
            return true;
        } else {
            $this->updated_by = Yii::$app->user->id;
            $this->updated_at = date("Y-m-d H:i:s");
            return true;
        }
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['user_id' => 'user_id']);
    }
    public function getOptionLine()
    {
        return $this->hasOne(\common\modules\option\models\OptionLine::className(), ['option_line_id' => 'name']);
    }
}
