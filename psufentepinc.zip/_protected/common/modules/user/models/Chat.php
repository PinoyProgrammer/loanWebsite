<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%chats}}".
 *
 * @property integer $id
 * @property integer $user_id_a
 * @property integer $user_id_b
 * @property integer $last_message_read
 * @property integer $status
 * @property string $last_message_at
 * @property integer $reference_id
 *
 * @property ChatDetails[] $chatDetails
 */
class Chat extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%chats}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id_a', 'user_id_b', 'last_message_read'], 'required'],
            [['user_id_a', 'user_id_b', 'last_message_read', 'status', 'reference_id'], 'integer'],
            [['last_message_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'user_id_a' => Yii::t('app', 'User Id A'),
            'user_id_b' => Yii::t('app', 'User Id B'),
            'last_message_read' => Yii::t('app', 'Last Message Read'),
            'status' => Yii::t('app', 'Status'),
            'last_message_at' => Yii::t('app', 'Last Message At'),
            'reference_id' => Yii::t('app', 'Reference ID'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getChatDetails()
    {
        return $this->hasMany(ChatDetail::className(), ['chat_id' => 'id']);
    }
    public function getUser()
    {
        return $this->hasOne(User::className(), ['user_id' => 'user_id_a']);
}
}
