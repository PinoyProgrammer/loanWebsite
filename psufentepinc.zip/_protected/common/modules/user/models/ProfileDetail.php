<?php

namespace common\modules\user\models;

use Yii;
use yii\db\ActiveRecord;


/**
 * This is the model class for table "_profile".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $create_time
 * @property string $update_time
 * @property string $first_name
 * @property string $last_name
 * @property string $gender
 * @property string $level
 * @property string $phone
 * @property string $mobile
 * @property integer $bill_code
 * @property string $note
 * @property string $avatar
 * @property integer $page_size
 * @property string $notifications
 * @property integer $company_id
 * @property integer $dept_id
 * @property integer $active
 * @property double $load_cost
 * @property double $seat_charge
 * @property double $daily_hours
 * @property string $registration_number
 * @property string $time_of_birth
 * @property integer $age
 * @property string $birth_place
 * @property string $marital_status
 * @property string $children
 * @property string $children_living_with_you
 * @property integer $height_feet
 * @property integer $height_inches
 * @property string $body_type
 * @property integer $weight
 * @property string $health_information
 * @property string $skin_tone
 * @property string $disability
 * @property string $blood_group
 * @property string $specs_lens
 * @property string $mother_tongue
 * @property string $sub_community
 * @property integer $father_status
 * @property string $father_working_as
 * @property integer $mother_status
 * @property string $mother_working_as
 * @property string $currently_living_country
 * @property string $current_living_state
 * @property string $current_living_city
 * @property integer $residency_status
 * @property string $current_address_district
 * @property string $current_address_tehsil
 * @property string $currently_living_in_area_village
 * @property string $current_pincode
 * @property string $permanent_address_country
 * @property string $permanent_address_state
 * @property string $permanent_address_city
 * @property string $permanent_address_district
 * @property string $permanent_address_tehsil
 * @property string $permanent_area_village
 * @property string $permanent_address_pincode
 * @property string $google_gps_cordinates
 * @property string $parents_residing_at
 * @property integer $no_of_sisters_married
 * @property integer $no_of_brothers
 * @property integer $no_of_brothers_married
 * @property string $family_type
 * @property string $family_affluence_level
 * @property string $family_values
 * @property string $relative_details
 * @property string $family_wealth_details
 * @property string $manglik
 * @property string $raashi_moon_sign
 * @property string $nakshtra
 * @property string $charan
 * @property string $nadi
 * @property string $gan
 * @property string $gothra
 * @property string $devak
 * @property string $education_level
 * @property string $education_field
 * @property string $college_name
 * @property string $working_with
 * @property string $working_as
 * @property string $employer_name
 * @property string $annual_income
 * @property string $income_currency
 * @property integer $keep_annual_income_private
 * @property string $diet
 * @property string $drink
 * @property string $smoke
 * @property string $hobbies
 * @property string $interest
 * @property string $favourite_music
 * @property string $favourite_reads
 * @property string $preferred_movies
 * @property string $sport_fitness_activities
 * @property string $favourite_cousines
 * @property string $preferred_dress_style
 * @property string $cultural_background
 * @property string $spoken_languages
 * @property string $about_yourself
 * @property string $tags
 * @property string $contact_person
 * @property string $relationship_with_member
 * @property string $convenient_time_to_call
 * @property string $profile_photo
 * @property integer $mobile_verified
 * @property integer $email_verified
 * @property integer $membership_type_id
 *
 * @property Users $user
 */
class ProfileDetail extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return static::getDb()->tablePrefix . '_profile';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id', 'bill_code', 'page_size', 'company_id', 'dept_id', 'active', 'age', 'height_feet', 'height_inches', 'weight', 'father_status', 'mother_status', 'residency_status', 'no_of_sisters_married', 'no_of_brothers', 'no_of_brothers_married', 'keep_annual_income_private', 'mobile_verified', 'email_verified', 'membership_type_id'], 'integer'],
            [['create_time', 'update_time'], 'safe'],
            [['note'], 'string'],
            [['load_cost', 'seat_charge', 'daily_hours'], 'number'],
            [['first_name', 'last_name', 'gender'], 'string', 'max' => 255],
            [['level'], 'string', 'max' => 2],
            [['avatar'], 'file', 'extensions' => 'jpg, jpeg, gif, png', 'skipOnEmpty' => true,
                'checkExtensionByMimeType' => true, 'on' => 'photo-upload'],
            [['phone', 'mobile', 'notifications'], 'string', 'max' => 12],
            [['avatar', 'registration_number', 'time_of_birth', 'birth_place', 'marital_status', 'children', 'children_living_with_you', 'body_type', 'health_information', 'skin_tone', 'disability', 'blood_group', 'specs_lens', 'mother_tongue', 'sub_community', 'father_working_as', 'mother_working_as', 'currently_living_country', 'current_living_state', 'current_living_city', 'current_address_district', 'current_address_tehsil', 'currently_living_in_area_village', 'current_pincode', 'permanent_address_country', 'permanent_address_state', 'permanent_address_city', 'permanent_address_district', 'permanent_address_tehsil', 'permanent_area_village', 'permanent_address_pincode', 'google_gps_cordinates', 'parents_residing_at', 'family_type', 'family_affluence_level', 'family_values', 'relative_details', 'family_wealth_details', 'manglik', 'raashi_moon_sign', 'nakshtra', 'charan', 'nadi', 'gan', 'gothra', 'devak', 'education_level', 'education_field', 'college_name', 'working_with', 'working_as', 'employer_name', 'annual_income', 'income_currency', 'diet', 'drink', 'smoke', 'hobbies', 'interest', 'favourite_music', 'favourite_reads', 'preferred_movies', 'sport_fitness_activities', 'favourite_cousines', 'preferred_dress_style', 'cultural_background', 'spoken_languages', 'about_yourself', 'tags', 'contact_person', 'relationship_with_member', 'convenient_time_to_call', 'profile_photo'], 'string', 'max' => 100],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'user_id' => Yii::t('app', 'User ID'),
            'create_time' => Yii::t('app', 'Create Time'),
            'update_time' => Yii::t('app', 'Update Time'),
            'first_name' => Yii::t('app', 'First Name'),
            'last_name' => Yii::t('app', 'Last Name'),
            'gender' => Yii::t('app', 'Gender'),
            'level' => Yii::t('app', 'Level'),
            'phone' => Yii::t('app', 'Phone'),
            'mobile' => Yii::t('app', 'Mobile'),
            'bill_code' => Yii::t('app', 'Bill Code'),
            'note' => Yii::t('app', 'Note'),
            'avatar' => Yii::t('app', 'Avatar'),
            'page_size' => Yii::t('app', 'Page Size'),
            'notifications' => Yii::t('app', 'Notifications'),
            'company_id' => Yii::t('app', 'Company ID'),
            'dept_id' => Yii::t('app', 'Dept ID'),
            'active' => Yii::t('app', 'Active'),
            'load_cost' => Yii::t('app', 'Load Cost'),
            'seat_charge' => Yii::t('app', 'Seat Charge'),
            'daily_hours' => Yii::t('app', 'Daily Hours'),
            'registration_number' => Yii::t('app', 'Registration Number'),
            'time_of_birth' => Yii::t('app', 'Time Of Birth'),
            'age' => Yii::t('app', 'Age'),
            'birth_place' => Yii::t('app', 'Birth Place'),
            'marital_status' => Yii::t('app', 'Marital Status'),
            'children' => Yii::t('app', 'Children'),
            'children_living_with_you' => Yii::t('app', 'Children Living With You'),
            'height_feet' => Yii::t('app', 'Height Feet'),
            'height_inches' => Yii::t('app', 'Height Inches'),
            'body_type' => Yii::t('app', 'Body Type'),
            'weight' => Yii::t('app', 'Weight'),
            'health_information' => Yii::t('app', 'Health Information'),
            'skin_tone' => Yii::t('app', 'Skin Tone'),
            'disability' => Yii::t('app', 'Disability'),
            'blood_group' => Yii::t('app', 'Blood Group'),
            'specs_lens' => Yii::t('app', 'Specs Lens'),
            'mother_tongue' => Yii::t('app', 'Mother Tongue'),
            'sub_community' => Yii::t('app', 'Sub Community'),
            'father_status' => Yii::t('app', 'Father Status'),
            'father_working_as' => Yii::t('app', 'Father Working As'),
            'mother_status' => Yii::t('app', 'Mother Status'),
            'mother_working_as' => Yii::t('app', 'Mother Working As'),
            'currently_living_country' => Yii::t('app', 'Currently Living Country'),
            'current_living_state' => Yii::t('app', 'Current Living State'),
            'current_living_city' => Yii::t('app', 'Current Living City'),
            'residency_status' => Yii::t('app', 'Residency Status'),
            'current_address_district' => Yii::t('app', 'Current Address District'),
            'current_address_tehsil' => Yii::t('app', 'Current Address Tehsil'),
            'currently_living_in_area_village' => Yii::t('app', 'Currently Living In Area Village'),
            'current_pincode' => Yii::t('app', 'Current Pincode'),
            'permanent_address_country' => Yii::t('app', 'Permanent Address Country'),
            'permanent_address_state' => Yii::t('app', 'Permanent Address State'),
            'permanent_address_city' => Yii::t('app', 'Permanent Address City'),
            'permanent_address_district' => Yii::t('app', 'Permanent Address District'),
            'permanent_address_tehsil' => Yii::t('app', 'Permanent Address Tehsil'),
            'permanent_area_village' => Yii::t('app', 'Permanent Area Village'),
            'permanent_address_pincode' => Yii::t('app', 'Permanent Address Pincode'),
            'google_gps_cordinates' => Yii::t('app', 'Google Gps Cordinates'),
            'parents_residing_at' => Yii::t('app', 'Parents Residing At'),
            'no_of_sisters_married' => Yii::t('app', 'No Of Sisters Married'),
            'no_of_brothers' => Yii::t('app', 'No Of Brothers'),
            'no_of_brothers_married' => Yii::t('app', 'No Of Brothers Married'),
            'family_type' => Yii::t('app', 'Family Type'),
            'family_affluence_level' => Yii::t('app', 'Family Affluence Level'),
            'family_values' => Yii::t('app', 'Family Values'),
            'relative_details' => Yii::t('app', 'Relative Details'),
            'family_wealth_details' => Yii::t('app', 'Family Wealth Details'),
            'manglik' => Yii::t('app', 'Manglik'),
            'raashi_moon_sign' => Yii::t('app', 'Raashi Moon Sign'),
            'nakshtra' => Yii::t('app', 'Nakshtra'),
            'charan' => Yii::t('app', 'Charan'),
            'nadi' => Yii::t('app', 'Nadi'),
            'gan' => Yii::t('app', 'Gan'),
            'gothra' => Yii::t('app', 'Gothra'),
            'devak' => Yii::t('app', 'Devak'),
            'education_level' => Yii::t('app', 'Education Level'),
            'education_field' => Yii::t('app', 'Education Field'),
            'college_name' => Yii::t('app', 'College Name'),
            'working_with' => Yii::t('app', 'Working With'),
            'working_as' => Yii::t('app', 'Working As'),
            'employer_name' => Yii::t('app', 'Employer Name'),
            'annual_income' => Yii::t('app', 'Annual Income'),
            'income_currency' => Yii::t('app', 'Income Currency'),
            'keep_annual_income_private' => Yii::t('app', 'Keep Annual Income Private'),
            'diet' => Yii::t('app', 'Diet'),
            'drink' => Yii::t('app', 'Drink'),
            'smoke' => Yii::t('app', 'Smoke'),
            'hobbies' => Yii::t('app', 'Hobbies'),
            'interest' => Yii::t('app', 'Interest'),
            'favourite_music' => Yii::t('app', 'Favourite Music'),
            'favourite_reads' => Yii::t('app', 'Favourite Reads'),
            'preferred_movies' => Yii::t('app', 'Preferred Movies'),
            'sport_fitness_activities' => Yii::t('app', 'Sport Fitness Activities'),
            'favourite_cousines' => Yii::t('app', 'Favourite Cousines'),
            'preferred_dress_style' => Yii::t('app', 'Preferred Dress Style'),
            'cultural_background' => Yii::t('app', 'Cultural Background'),
            'spoken_languages' => Yii::t('app', 'Spoken Languages'),
            'about_yourself' => Yii::t('app', 'About Yourself'),
            'tags' => Yii::t('app', 'Tags'),
            'contact_person' => Yii::t('app', 'Contact Person'),
            'relationship_with_member' => Yii::t('app', 'Relationship With Member'),
            'convenient_time_to_call' => Yii::t('app', 'Convenient Time To  Call'),
            'profile_photo' => Yii::t('app', 'Profile Photo'),
            'mobile_verified' => Yii::t('app', 'Mobile Verified'),
            'email_verified' => Yii::t('app', 'Email Verified'),
            'membership_type_id' => Yii::t('app', 'Membership Type ID'),
        ];
    }

public function behaviors() {
        return [
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'value' => function () {
                    return date("Y-m-d H:i:s");
                },
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => 'create_time',
                    ActiveRecord::EVENT_BEFORE_UPDATE => 'update_time',
                ],
            ],
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser() {
        return $this->hasOne(User::className(), ['user_id' => 'user_id']);
    }

    public function setUser($userId) {
        $this->user_id = $userId;
        return $this;
    }

    public static function getGenderOption() {
        return [
            "M" => 'Male',
            "F" => 'Female',
            "0" => 'Not userlicable',
        ];
}

    public static function getPageSize() {
        return [
            10 => '10 per page',
            15 => '15 per page',
            25 => '20 per page',
            30 => '30 per page',
            35 => '35 per page',
        ];
    }

    public static function getNotification() {
        return [
            1 => 'Yes',
            0 => 'No',
        ];
    }

    public static function getAvatar($imgName) {
        $dispImg = is_file(Yii::getAlias('@uploads') . '/user_images/' . $imgName) ? true : false;
        return Yii::getAlias('@uploads') . "/" . (($dispImg) ? $imgName : "no-photo.png");
    }

    public function getUserDetails() {
        return $this->hasOne(\common\modules\project\models\UserDetails::className(), ['user_id' => 'user_id']);
    }

    public function getFullName() {
        return $this->first_name . ' ' . $this->last_name;
    }

   

    public static function get_transation_id($sex) {
        $txid = Profile::find()->select("revision_number")->orderBy("revision_number desc")->one();
        if ($txid) {
            $txid = $txid->revision_number++;         
            
        } else {
            $c="1000001";
            $txid = $sex=="M"?"G" . $c:"B" . $c;
        }

        return strtoupper($txid);
    }
    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = Yii::$app->user->id;
            $this->create_time = date("Y-m-d H:i");
            $this->updated_by = Yii::$app->user->id;
            $this->update_time = date("Y-m-d H:i");
            return true;
        } else {
            $this->updated_by = Yii::$app->user->id;
            $this->update_time = date("Y-m-d H:i");
            return true;
        }
    }

}
