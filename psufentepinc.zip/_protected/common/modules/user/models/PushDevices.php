<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%push_devices}}".
 *
 * @property integer $device_id
 * @property string $device_token
 * @property string $user_token
 * @property string $id_token
 * @property string $created_at
 * @property integer $user_id
 * @property string $language
 */
class PushDevices extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%push_devices}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['device_token', 'id_token', 'user_token', 'created_at', 'user_id', 'language'], 'required'],
            [['created_at'], 'safe'],
            [['user_id'], 'integer'],
            [['device_token', 'id_token'], 'string', 'max' => 200],
            [['language'], 'string', 'max' => 4],
            [['device_token', 'user_token'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'device_id' => Yii::t('user', 'Device ID'),
            'device_token' => Yii::t('user', 'Device Token'),
            'id_token' => Yii::t('user', 'Id Token'),
            'created_at' => Yii::t('user', 'Created At'),
            'user_id' => Yii::t('user', 'User ID'),
            'language' => Yii::t('user', 'Language'),
            'user_token' => "User Token"
        ];
    }

    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_at = date("Y-m-d H:i");
            return true;
        } else {
            return true;
        }
    }

    public static function sendMessage($include_player_ids,$message) {
        $params = Yii::$app->params;
        $content = array(
            "en" => $message
        );

        $fields = array(
            'app_id' => $params['ONESIGNAL_APP_ID'],
            'include_player_ids' => $include_player_ids,
            'data' => array("foo" => "bar"),
            'contents' => $content
        );

        $fields = json_encode($fields);
        print("\nJSON sent:\n");
        print($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
            'Authorization: Basic ' . $params['REST_API_KEY']));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        curl_close($ch);

        return $response;
    }

}
