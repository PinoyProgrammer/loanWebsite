<?php

namespace common\modules\user\models;

use Yii;

/**
 * This is the model class for table "{{%bamboo_products}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $part_number
 * @property double $unitcost
 * @property integer $uom_id
 * @property integer $category_id
 * @property integer $status
 * @property integer $part_of
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%bamboo_products}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['unitcost'], 'number'],
            [['uom_id', 'category_id', 'status', 'part_of'], 'integer'],
            [['name'], 'string', 'max' => 145],
            [['part_number'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'part_number' => Yii::t('app', 'Part Number'),
            'unitcost' => Yii::t('app', 'Unitcost'),
            'uom_id' => Yii::t('app', 'Uom ID'),
            'category_id' => Yii::t('app', 'Category ID'),
            'status' => Yii::t('app', 'Status'),
            'part_of' => Yii::t('app', 'Part Of'),
        ];
    }
}
