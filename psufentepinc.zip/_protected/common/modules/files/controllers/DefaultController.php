<?php

namespace common\modules\files\controllers;

use yii\web\Controller;

/**
 * Default controller for the `file` module
 */
class DefaultController extends Controller {

    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex() {
        return $this->render('index');
    }

    public function actionUpload() {
        $files = $_FILES;
        $files2 = $_FILES;
        $branchid = \Yii::$app->request->post('branchid');
        $type = \Yii::$app->request->post("type");
        $recon_date = \Yii::$app->request->post("recon_date");
        foreach ($files as $value) {
            $files = \yii\web\UploadedFile::getInstanceByName($value);
        }

        return \yii\helpers\Json::encode(array("error" => "success", $branchid, $type, $recon_date, $files, $files2));
    }

}
