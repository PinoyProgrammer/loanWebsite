<?php

namespace common\modules\files\models;

use Yii;

/**
 * This is the model class for table "{{%files}}".
 *
 * @property string $file_id
 * @property string $file_path
 * @property string $file_name
 * @property string $file_size
 * @property string $file_type
 * @property string $display_type
 * @property string $description
 * @property integer $created_by
 * @property string $creation_date
 * @property integer $last_update_by
 * @property string $last_update_date
 * @property string $module_name
 * @property string $document_type
 * @property integer $company_id
 * @property integer $referenceid
 */
class Files extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%files}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['file_id', 'created_by', 'last_update_by', 'company_id'], 'integer'],
            [['file_path', 'file_name', 'file_size', 'file_type', 'created_by', 'last_update_by'], 'required'],
            [['creation_date', 'last_update_date'], 'safe'],
            [['file_path'], 'string', 'max' => 256],
            [['file_name', 'file_size', 'file_type', 'document_type'], 'string', 'max' => 50],
            [['display_type'], 'string', 'max' => 25],
            [['description'], 'string', 'max' => 200],
            [['module_name'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'file_id' => Yii::t('app', 'File ID'),
            'file_path' => Yii::t('app', 'File Path'),
            'file_name' => Yii::t('app', 'File Name'),
            'file_size' => Yii::t('app', 'File Size'),
            'file_type' => Yii::t('app', 'File Type'),
            'display_type' => Yii::t('app', 'Display Type'),
            'description' => Yii::t('app', 'Description'),
            'created_by' => Yii::t('app', 'Created By'),
            'creation_date' => Yii::t('app', 'Creation Date'),
            'last_update_by' => Yii::t('app', 'Last Update By'),
            'last_update_date' => Yii::t('app', 'Last Update Date'),
            'module_name' => Yii::t('app', 'Module Name'),
            'document_type' => Yii::t('app', 'Document Type'),
            'company_id' => Yii::t('app', 'Company ID'),
            'referenceid' => Yii::t('app', 'Company ID'),
        ];
    }
    public function beforeSave($insert) {
        if (parent::beforeSave($insert)) {
            $this->created_by = 1;
            $this->creation_date = date("Y-m-d H:i");
            $this->last_update_by = 1;
            $this->last_update_date = date("Y-m-d H:i");
            return true;
        } else {
            $this->last_update_by = Yii::$app->user->id;
            $this->last_update_date = date("Y-m-d H:i");
            return true;
        }
    }
}
