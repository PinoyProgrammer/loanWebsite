<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\helpers;

/**
 * Description of NumRead
 *
 * @author Hosea.Kandie
 */
class NumRead {

    private static $greeting = 'Hello';
    private static $initialized = false;
    private static $ones = ["", " one", " two", " three", " four", " five", " six", " seven", " eight", " nine", " ten", " eleven", " twelve", " thirteen", " fourteen", " fifteen", " sixteen", " seventeen", " eighteen", " nineteen"];
    private static $tens = ["", "", " twenty", " thirty", " forty", " fifty", " sixty", " seventy", " eighty", " ninety"];
    private static $triplets = ["", " thousand", " million", " billion", " trillion", " quadrillion", " quintillion", " sextillion", " septillion", " octillion", " nonillion"];

    private static function initialize() {
        if (self::$initialized) {
            return;
        }

        self::$greeting .= ' There!';
        self::$initialized = true;
    }

    function convertTri($num, $tri) {
        $r = (int) ($num / 1000);
        $x = ($num / 100) % 10;
        $y = $num % 100;

        $str = "";

        // do hundreds
        if ($x > 0) {
            $str = self::$ones[$x] . " hundred";
        }

        // do ones and tens
        if ($y < 20) {
            $str .= self::$ones[$y];
        } else {
            $str .= self::$tens[(int) ($y / 10)] . self::$ones[$y % 10];
        }

        // add triplet modifier only if there
        // is some output to be modified...
        if ($str != "") {
            $str .= self::$triplets[$tri];
        }

        // continue recursing?
        if ($r > 0) {
            return convertTri($r, $tri + 1) . $str;
        } else {
            return $str;
        }
    }

    public static function convertNum($num) {
        self::initialize();
        $num = (int) $num;    // make sure it's an integer

        if ($num < 0) {
            return "negative" . convertTri(-$num, 0);
        }

        if ($num == 0) {
            return "zero";
        }

        return ucwords(self::convertTri($num, 0));
    }

}
