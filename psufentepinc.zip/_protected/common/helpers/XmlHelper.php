<?php

namespace common\helpers;

/**
 * Description of XmlHelper
 *
 * @author Hosea.Kandie
 */
class XmlHelper {

    public static function xml_from_result($query, $params = array()) {
        if (!is_object($query) OR ! method_exists($query, 'list_fields')) {
            
        }

        // Set our default values
        foreach (array('root' => 'root', 'element' => 'element', 'newline' => "\n", 'tab' => "\t") as $key => $val) {
            if (!isset($params[$key])) {
                $params[$key] = $val;
            }
        }

        // Create variables for convenience
        extract($params);

        // Generate the result
        $xml = "<{$root}>" . $newline;
        foreach ($query as $row) {
            $xml .= $tab . "<{$element}>" . $newline;

            foreach ($row as $key => $val) {
                $xml .= $tab . $tab . "<{$key}>" . XmlHelper::xml_convert($val) . "</{$key}>" . $newline;
            }
            $xml .= $tab . "</{$element}>" . $newline;
        }
        $xml .= "</$root>" . $newline;

        return $xml;
    }

    public static function xml_convert($str, $protect_all = FALSE) {
        $temp = '__TEMP_AMPERSANDS__';

        // Replace entities to temporary markers so that
        // ampersands won't get messed up
        $str = preg_replace("/&#(\d+);/", "$temp\\1;", $str);

        if ($protect_all === TRUE) {
            $str = preg_replace("/&(\w+);/", "$temp\\1;", $str);
        }

        $str = str_replace(array("&", "<", ">", "\"", "'", "-"), array("&amp;", "&lt;", "&gt;", "&quot;", "&apos;", "&#45;"), $str);

        // Decode the temp markers back to entities
        $str = preg_replace("/$temp(\d+);/", "&#\\1;", $str);

        if ($protect_all === TRUE) {
            $str = preg_replace("/$temp(\w+);/", "&\\1;", $str);
        }

        return $str;
    }

    function write_file($path, $data, $mode = "wb") {
        if (!$fp = @fopen($path, $mode)) {
            return FALSE;
        }

        flock($fp, 2);
        fwrite($fp, $data);
        flock($fp, 3);
        fclose($fp);

        return TRUE;
    }

}
