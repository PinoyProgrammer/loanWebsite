<?php

namespace common\helpers;

class ExcelHepler {

    public $top_border = array(
        'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
        'color' => array('rgb' => '000000')
    );
    public $bottom_border = array(
        'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_DOUBLE,
        'color' => array('rgb' => '000000')
    );
    public $default_border = array(
        'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
        'color' => array('rgb' => '000000')
    );
    public static $sumstyle = array(
        'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_DOUBLE,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 11,
        )
    );
    public $align = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        )
    );
    public static $align_center = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_TOP
        )
    );
    public static $align_center_border_all = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_TOP
        ),
        'font' => array(
            'bold' => true,
            'size' => 15,
        ),
        'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $align_right_border_all = array(
        'font' => array(
            'bold' => true,
        ),
        'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $align_center_border_all_not_bold = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_TOP
        ),
        'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $align_right_border_all_not_bold = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_TOP
        ),
        'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $align_right_border_all_thick = array(
        'alignment' => array(
            'wrap' => true,
        ),
        'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $bold_style_header = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 11,
        )
    );
    public static $blue_style_header = array(
        'alignment' => array(
            'wrap' => true,
        ),
        'font' => array(
            'color' => array('rgb' => '0000EE'),
        //'color' => '#4174E4',
        )
    );
    public static $bold_style_header_center = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 11,
        ),
    );
    public static $bold_style_header_center_bordered = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 11,
        ), 'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $bold_style_header_left_bordered = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 11,
        ), 'borders' => array(
            'bottom' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'top' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'left' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
            'right' => array(
                'style' =>  \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                'color' => array('rgb' => '000000')
            ),
        ),
    );
    public static $bold_style_header_left = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 11,
        )
    );
    public static $right_bold_style_header = array(
        'font' => array(
            'bold' => true,
            'size' => 11,
        )
    );
    public $style_header = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
        'font' => array(
            'bold' => true,
            'size' => 14,
        )
    );
    public $text_align_center = array(
        'alignment' => array(
            'wrap' => true,
            'horizontal' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
            'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
        ),
    );

    public static function set_cell_value_no_style($sheet, $row, $value, $sum = false, $bold = false, $border = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("[black]#,##0.00;[red](#,##0.00)");
        if ($sum) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$sumstyle);
        }
        if ($bold) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$right_bold_style_header);
        }
        if ($border) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$align_right_border_all);
        }
    }

    public static function set_cell_value_rounded_off($sheet, $row, $value, $sum = false, $bold = false, $border = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("[black]#,##0;[red](#,##0)");
        if ($sum) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$sumstyle);
        }
        if ($bold) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$right_bold_style_header);
        }
        if ($border) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$align_right_border_all);
        }
    }

    public static function set_cell_value_no_style_percent($sheet, $row, $value, $sum = false, $bold = false, $border = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("0.0%;[Red]-0.0%");
        if ($sum) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$sumstyle);
        }
        if ($bold) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$right_bold_style_header);
        }
        if ($border) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$align_right_border_all);
        }
    }

    public static function set_cell_value_mmm_yy_style($sheet, $row, $value, $bold = false) {
        $datetime = \DateTime::createFromFormat("Y-m-d", $value);
        $timestamp = $datetime->getTimestamp();
        $sheet->setCellValue($row, \PHPExcel_Shared_Date::PHPToExcel($timestamp));
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("mmm-yy");
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header);
    }

    public static function set_cell_value_dd_mmm_yy_style($sheet, $row, $value, $bold = false) {
        $datetime = \DateTime::createFromFormat("Y-m-d", $value);
        $timestamp = $datetime->getTimestamp();
        $sheet->setCellValue($row, \PHPExcel_Shared_Date::PHPToExcel($timestamp));
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("dd-mmm-yy");
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header);
    }

    public static function set_cell_value_mmmm_yyyy_style($sheet, $row, $value, $bold = false) {
        $datetime = \DateTime::createFromFormat("Y-m-d", $value);
        $timestamp = $datetime->getTimestamp();
        $sheet->setCellValue($row, \PHPExcel_Shared_Date::PHPToExcel($timestamp));
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("mmmm-yyyy");
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header);
    }

    public static function set_cell_value_style_bold_and_center($sheet, $row, $value, $sum = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header_center);
    }

    public static function set_cell_value_style_bold_and_centered($sheet, $row, $value, $bordered = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("[black]#,##0.00;[red](#,##0.00)");
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header_center_bordered);
    }

    public static function set_cell_value_style_bold_and_centered_no_numeric($sheet, $row, $value, $bordered = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header_center_bordered);
    }

    public static function set_cell_value_style_bold_and_left_no_numeric($sheet, $row, $value, $bordered = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header_left_bordered);
    }

    public static function set_cell_value_style_bold_and_left_no_numeric_perc($sheet, $row, $value, $bordered = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("0.0%;[Red]-0.0%");
    }

    public static function set_cell_value_style_bold_and_left($sheet, $row, $value) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->applyFromArray(ExcelHepler::$bold_style_header_left);
    }

    public static function set_cell_value_no_style_with_red($sheet, $row, $value, $sum = false) {
        $sheet->setCellValue($row, $value);
        $sheet->getStyle($row)->getNumberFormat()->setFormatCode("[black]#,##0.00;[red](#,##0.00)");
        if ($sum) {
            $sheet->getStyle($row)->applyFromArray(ExcelHepler::$sumstyle);
        }
    }

}
