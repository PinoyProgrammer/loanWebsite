<?php

namespace common\helpers;

use Yii;

/**
 * Css helper class.
 */
class TimeHelper {

    public static function minutes_to_hh_mm($time) {
        $hh = TimeHelper::to_significant_fig($time / 60);
        $mm = ($time % 60);
        return str_pad($hh, 2, "0", STR_PAD_LEFT) . ":" . str_pad($mm, 2, "0", STR_PAD_LEFT);
    }

    public static function time_diff_in_mm($time1, $time2) {
        $blocktimeoff = strtotime($time1);
        $blocktimeon = strtotime($time2);
        return round(abs($blocktimeon - $blocktimeoff) / 60, 2);
    }
    public static function time_diff_in_mm_with_delay($time1, $time2) {
        $blocktimeoff = strtotime($time1);
        $blocktimeon = strtotime($time2);
        return round(($blocktimeon - $blocktimeoff) / 60, 2);
    }


    public static function days_diff_in_hours($time1, $time2) {
        $blocktimeoff = strtotime($time1);
        $blocktimeon = strtotime($time2);
        return round(abs($blocktimeon - $blocktimeoff) / (60 * 60), 2);
    }

    public static function time_diff_in_hours($time1, $time2) {
        $blocktimeoff = strtotime($time1);
        $blocktimeon = strtotime($time2);
        return round(abs($blocktimeon - $blocktimeoff) / 3600, 2);
    }

    public static function time_diff_in_days($time1, $time2) {
        $blocktimeoff = strtotime($time1);
        $blocktimeon = strtotime($time2);
        return round(abs($blocktimeon - $blocktimeoff) / (3600 * 24));
    }

    public static function time_diff_in_hhmm($time1, $time2) {
        $time = TimeHelper::time_diff_in_mm($time1, $time2);
        return TimeHelper::minutes_to_hh_mm($time);
    }

    public static function to_significant_fig($num) {
        $a = explode(".", $num);
        return $a[0];
    }

    public static function tohours($time) {
        $hrs = floor($time / 60);
        $min = floor($time % 60);
        return str_pad($hrs, 2, "0", STR_PAD_LEFT) . ":" . str_pad($min, 2, "0", STR_PAD_LEFT);
    }

    function time_to_hours($time) {
        $hrs = floor($time / 3600);
        $min = floor($time % 3600);
        $min = $min / 60;
        return str_pad($hrs, 2, "0", STR_PAD_LEFT) . ":" . str_pad($min, 2, "0", STR_PAD_LEFT);
    }

    public static function checkcumulative($time) {
        $style = "";
        $hrs = floor($time / 60);
        if ($time < 140) {
            $style = '';
        } else if ($time >= 140 && $time < 160) {
            $style = 'style="background:orange"';
        } else if ($time >= 160) {
            $style = 'style="background:red"';
        }

        return $style;
    }

    public static function date_dd_mmm_yyyy($date) {
        $dateTime = \DateTime::createFromFormat('d F, Y', $date);
        return $dateTime->format('Y-m-d');
    }

    public static function toketime($date) {
        return date('Y-m-d H:m:s', strtotime('+' . \Yii::$app->params['timediff'] . ' hours', strtotime($date)));
    }

    public static function add_months($months, $date) {
        $ymd = explode("-", $date);
        $m = $ymd[1];
        if (isset($ymd[1])) {
            return date("Y-m-t", strtotime($ymd[0] . '-' . ($ymd[1] + $months) . '-' . $ymd[2]));
        }
        return date("Y-m-t", strtotime("first day of +$months month", strtotime($date)));
    }

    public static function subtract_months($months, $date) {
        $ymd = explode("-", $date);
        $m = $ymd[1];
        if (isset($ymd[1])) {
            return date("Y-m-t", strtotime($ymd[0] . '-' . ($ymd[1] - $months) . '-' . $ymd[2]));
        }
        return date("Y-m-t", strtotime("first day of -$months month", strtotime($date)));
    }

    public static function minus_months($months, $date) {
        $object = new \DateTime($date);
        $next = new \DateTime($object->format('d-m-Y H:i:s'));
        $next->modify('last day of -' . $months . ' month');
        $last_month = null;
        if ($object->format('d') > $next->format('d')) {
            $last_month = $object->diff($next);
        } else {
            $last_month = new \DateInterval('P' . $months . 'M');
        }
        return $last_month->format('Y-m-d');
    }

    public static function plus_months($months, $date) {
        $last_month = new \DateTime($date);
        $last_month->add(new DateInterval('P' . $months . 'M'));
        return $last_month->format('Y-m-d');
    }

    public static function hourMinuteToDecimal($hour_minute) {
        if ((!$hour_minute) || strlen($hour_minute) < 5) {
            return 0;
        } else {
            $t = explode(':', $hour_minute);
            return count($t)==2?($t[0] * 60 + $t[1]):0;
        }
    }

}
