<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2015 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace common\helpers;

/**
 * Utility class for date issues
 *
 * @see \yii\validators\DateValidator
 * @author buddha
 */
class DateHelper {

    /**
     * Parses a date and optionally a time if timeAttribute is specified.
     * 
     * @param string $value
     * @param string $timeValue optional time value
     * @return int timestamp in utc
     */
    public static function parseDateTimeToTimestamp($value, $timeValue = null) {
        return DbDateValidator::parseDateTime($value, $timeValue);
    }

    /**
     * Parses a date and optionally a time if timeAttribute is specified to
     * an given pattern or the default pattern 'Y-m-d' if no pattern is provided.
     * 
     * @param string $value date value
     * @param string $pattern  pattern
     * @param string $timeValue optional time value
     * @return int timestamp in utc
     */
    public static function parseDateTime($value, $pattern = 'Y-m-d', $timeValue = null) {
        $ts = self::parseDateTimeToTimestamp($value, $timeValue);
        $dt = new \DateTime();
        $dt->setTimestamp($ts);
        return $dt->format($pattern);
    }

    public static function find_months_between($dateIni, $dateFin) {

// Get year and month of initial date (From)
        $yearIni = date("Y", strtotime($dateIni));
        $monthIni = date("m", strtotime($dateIni));

// Get year an month of finish date (To)
        $yearFin = date("Y", strtotime($dateFin));
        $monthFin = date("m", strtotime($dateFin));

// Checking if both dates are some year

        if ($yearIni == $yearFin) {
            $numberOfMonths = ($monthFin - $monthIni) + 1;
        } else {
            $numberOfMonths = ((($yearFin - $yearIni) * 12) - $monthIni) + 1 + $monthFin;
        }
        return $numberOfMonths;
    }

}
