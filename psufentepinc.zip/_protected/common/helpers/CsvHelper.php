<?php

namespace common\helpers;

class CsvHelper {

    public static function export($parameter) {
        if (is_string($parameter)) {
            $parameter = ['table' => $parameter];
        }
        if (is_array($parameter)) {
            if (!empty($parameter['table'])) {
                
            } elseif (!empty($parameter['sql'])) {
                $db = \Yii::$app->getDb();
                $command = $db->createCommand($parameter['sql']);
                if (!empty($parameter['bind'])) {
                    $command->bindValues($parameter['bind']);
                }
                $reader = $command->query();
            } elseif (!empty($parameter['query']) && empty($query)) {
                $query = $parameter['query'];
            } elseif (!empty($parameter['reader']) && empty($reader)) {
                $reader = $parameter['reader'];
            } elseif (empty($parameter['data'])) {
                throw new \yii\web\HttpException(500, "Not a valid parameter!");
            }
            if (empty($parameter['name'])) {
                $parameter['name'] = date('Y-m-d_H-i-s') . '.csv';
            }

            if (!empty($parameter['fp']) && is_resource($parameter['fp'])) {
                $fp = & $parameter['fp'];
            } else {
                if (!empty($parameter['target'])) {
                    $fp = fopen($parameter['target'] . $parameter['name'], 'w');
                } else {
                    header('Content-Type: text/csv');
                    header("Content-Disposition: attachment;filename={$parameter['name']}");
                    $fp = fopen('php://output', 'w');
                }
            }

            fwrite($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));
            if (!empty($parameter['header']) && is_array($parameter['header'])) {
                fputcsv($fp, $parameter['header']);
            }
            if (isset($query)) {
                foreach ($query->each() as $row) {
                    fputcsv($fp, $row);
                }
            } elseif (isset($reader)) {
                foreach ($reader as $row) {
                    fputcsv($fp, $row);
                }
            } else if (isset($parameter['data'])) {
                foreach ($parameter['data'] as $row) {
                    fputcsv($fp, $row);
                }
            }
            return true;
        }
        throw new \yii\web\HttpException(500, "Not a valid parameter!");
    }

    function csv_from_result($rs, $delim = ",", $newline = "\r\n", $enclosure = '') {
        $out = '';
        if (isset($rs[0])) {
            foreach (array_keys($rs[0]) as $name) {
                $out .= $enclosure . str_replace($enclosure, $enclosure . $enclosure, $name) . $enclosure . $delim;
            }

            $out = rtrim($out);
            $out .= $newline;

            // Next blast through the result array and build out the rows
            foreach ($rs as $row) {
                foreach ($row as $item) {
                    $out .= $enclosure . str_replace($enclosure, $enclosure . $enclosure, $item) . $enclosure . $delim;
                }
                $out = rtrim($out);
                $out .= $newline;
            }
        }
        return $out;
    }

    function write_file($path, $data, $mode = FOPEN_WRITE_CREATE_DESTRUCTIVE) {
        if (!$fp = @fopen($path, $mode)) {
            return FALSE;
        }

        flock($fp, LOCK_EX);
        fwrite($fp, $data);
        flock($fp, LOCK_UN);
        fclose($fp);

        return TRUE;
    }

    public static function  implode_with_quotes(array $data) {
        return sprintf("'%s'", implode("', '", $data));
    }

}
