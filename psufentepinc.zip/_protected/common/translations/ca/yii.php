<?php

return [
    '{attribute} cannot be blank.' => '{attribute} no pot ésser buit.',
    'The verification code is incorrect.' => 'El codi de verificació és incorrecte.',
    'Home' => 'Inici',
    'You are not allowed to perform this action.' => 'No estás autoritzat a fer aquesta acció.'
];
