<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\Profile as BaseProfile;

/**
 * This is the model class for table "_profile".
 */
class Profile extends BaseProfile
{
}
