<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\AdmTaskStatus as BaseAdmTaskStatus;

/**
 * This is the model class for table "adm_task_status".
 */
class AdmTaskStatus extends BaseAdmTaskStatus
{
}
