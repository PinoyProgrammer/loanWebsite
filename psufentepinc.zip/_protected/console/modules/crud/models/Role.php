<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\Role as BaseRole;

/**
 * This is the model class for table "_role".
 */
class Role extends BaseRole
{
}
