<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\Session as BaseSession;

/**
 * This is the model class for table "_session".
 */
class Session extends BaseSession
{
}
