<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\Date as BaseDate;

/**
 * This is the model class for table "_dates".
 */
class Date extends BaseDate
{
}
