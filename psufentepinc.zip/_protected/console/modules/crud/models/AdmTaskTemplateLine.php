<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\AdmTaskTemplateLine as BaseAdmTaskTemplateLine;

/**
 * This is the model class for table "adm_task_template_line".
 */
class AdmTaskTemplateLine extends BaseAdmTaskTemplateLine
{
}
