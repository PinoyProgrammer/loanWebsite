<?php

namespace app\modules\crud\models;

use Yii;
use \app\modules\crud\models\base\AddressReference as BaseAddressReference;

/**
 * This is the model class for table "address_reference".
 */
class AddressReference extends BaseAddressReference
{
}
