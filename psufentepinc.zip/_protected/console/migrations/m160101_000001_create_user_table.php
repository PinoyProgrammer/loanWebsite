<?php

use yii\db\Migration;
use yii\db\Schema;

class m160101_000001_create_user_table extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";

        /* MYSQL */
        if (!in_array('{{%_profile}}', $tables)) {
            //if ($dbType == "mysql") {
            $this->createTable('{{%_profile}}', [
                'id' => $this->primaryKey(),
                'user_id' => $this->integer()->notNull(),
                'first_name' => $this->string(255)->null(),
                'last_name' => $this->string(255)->null(),
                'mobile' => $this->string(12)->null(),
                'gender' => $this->string(12)->null(),
                'title' => $this->string(12)->null(),
                'toc' => $this->integer()->notNull()->defaultValue(1),
                'language'=> $this->string(4)->notNull()->defaultValue('en'),
                'created_at' => $this->timestamp()->null(),
                'updated_at' => $this->timestamp()->null(),
                'created_by' => $this->integer()->null(),
                'updated_by' => $this->integer()->null(),
                'avatar' => $this->string(100)->null(),
                    ], $tableOptions_mysql);
            //}
        }

        /* MYSQL */
        if (!in_array('{{%_role}}', $tables)) {
            //if ($dbType == "mysql") {
            $this->createTable('{{%_role}}', [
                'id' => $this->primaryKey(),
                'name' => $this->string(100)->notNull(),
                'create_time' => $this->timestamp()->notNull(),
                'update_time' => $this->timestamp()->notNull(),
                'can_admin' => $this->integer()->notNull()->defaultValue(1),
                    ], $tableOptions_mysql);
            // }
        }



        /* MYSQL */
        if (!in_array('{{%_user_auth}}', $tables)) {
            //if ($dbType == "mysql") {
            $this->createTable('{{%_user_auth}}', [
                'id' => $this->primaryKey(),
                'user_id' => $this->integer()->notNull(),
                'provider' => $this->string(255)->notNull(),
                'provider_id' => $this->string(255)->notNull(),
                'provider_attributes' => $this->text(),
                'create_time' => $this->timestamp()->null(),
                'update_time' => $this->timestamp()->null(),
                    ], $tableOptions_mysql);
            //}
        }

        /* MYSQL */
        if (!in_array('{{%_user_key}}', $tables)) {
            // if ($dbType == "mysql") {
            $this->createTable('{{%_user_key}}', [
                'id' => $this->primaryKey(),
                'user_id' => $this->integer()->notNull(),
                'type' => $this->smallInteger(6)->notNull(),
                'key_value' => $this->string(255)->notNull(),
                'create_time' => $this->timestamp()->null(),
                'consume_time' => $this->timestamp()->null(),
                'expire_time' => $this->timestamp()->null(),
                    ], $tableOptions_mysql);
            // }
        }

        /* MYSQL */


        /* MYSQL */
        if (!in_array('{{%address}}', $tables)) {
            //if ($dbType == "mysql") {
            $this->createTable('{{%address}}', [
                'address_id' => $this->primaryKey(),
                'type' => $this->string(50)->null()->defaultValue('both'),
                'address_name' => $this->string(50)->null(),
                'mdm_tax_region_id' => $this->integer()->null(),
                'description' => $this->string(200)->null(),
                'phone' => $this->string(50)->null(),
                'email' => $this->string(100)->null(),
                'website' => $this->string(200)->null(),
                'address' => $this->text(),
                'country' => $this->string(40)->null(),
                'postal_code' => $this->string(20)->null(),
                'default_cb' => $this->smallInteger(1)->notNull(),
                'status' => $this->integer()->notNull()->defaultValue(0),
                'usage_type' => $this->string(25)->null(),
                'rev_number' => $this->integer()->null(),
                'created_by' => $this->integer()->notNull(),
                'creation_date' => $this->datetime()->null(),
                'last_update_by' => $this->integer()->notNull(),
                'last_update_date' => $this->datetime()->null(),
                'company_id' => $this->integer()->notNull()->defaultValue(0),
                    ], $tableOptions_mysql);
            //}
        }

        if (!in_array('{{%users}}', $tables)) {
            // if ($dbType == "mysql") {
            $this->createTable('{{%users}}', [
                'user_id' => $this->primaryKey(),
                'role_id' => $this->integer()->notNull(),
                'status' => $this->smallInteger(1)->null(),
                'email' => $this->string(127)->null(),
                'new_email' => $this->string(255)->null(),
                'username' => $this->string(255)->null(),
                'password' => $this->string(255)->null(),
                'auth_key' => $this->string(255)->null(),
                'api_key' => $this->string(255)->null(),
                'login_ip' => $this->string(255)->null(),
                'login_time' => $this->timestamp()->null(),
                'create_ip' => $this->string(255)->null(),
                'created_at' => $this->timestamp()->null(),
                'updated_at' => $this->timestamp()->null(),
                'ban_time' => $this->timestamp()->null(),
                'ban_reason' => $this->string(255)->null(),
                'created_by' => $this->integer()->notNull()->defaultValue(1),
                'updated_by' => $this->integer()->notNull()->defaultValue(1),
                'user_type' => $this->string(2)->null(),
                'company_id' => $this->integer()->notNull()->defaultValue(0),
                    ], $tableOptions_mysql);
            // }
        }




        $this->createIndex('idx_user_id_3271_00', '{{%_profile}}', 'user_id', 0);
        $this->createIndex('idx_provider_id_3459_01', '{{%_user_auth}}', 'provider_id', 0);
        $this->createIndex('idx_user_id_3459_02', '{{%_user_auth}}', 'user_id', 0);
        $this->createIndex('idx_provider_id_3459_03', '{{%_user_auth}}', 'provider_id', 0);
        $this->createIndex('idx_user_id_3459_04', '{{%_user_auth}}', 'user_id', 0);
        $this->createIndex('idx_UNIQUE_key_value_3509_05', '{{%_user_key}}', 'key_value', 1);
        $this->createIndex('idx_user_id_3509_06', '{{%_user_key}}', 'user_id', 0);
        $this->createIndex('idx_UNIQUE_address_name_3655_07', '{{%address}}', 'address_name', 1);
        $this->createIndex('idx_UNIQUE_email_8664_56', '{{%users}}', 'email', 1);
        $this->createIndex('idx_UNIQUE_username_8664_57', '{{%users}}', 'username', 1);
        $this->createIndex('idx_role_id_8664_58', '{{%users}}', 'role_id', 0);

        $this->execute('SET foreign_key_checks = 0');
        $this->addForeignKey('fk_users_3263_00', '{{%_profile}}', 'user_id', '{{%users}}', 'user_id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_users_3453_01', '{{%_user_auth}}', 'user_id', '{{%users}}', 'user_id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_users_3453_02', '{{%_user_auth}}', 'user_id', '{{%users}}', 'user_id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_users_3503_03', '{{%_user_key}}', 'user_id', '{{%users}}', 'user_id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk__role_8656_038', '{{%users}}', 'role_id', '{{%_role}}', 'id', 'CASCADE', 'CASCADE');
        $this->insert('{{%_role}}', ['id' => '1', 'name' => 'Admin', 'create_time' => date("Y-m-d H:i:s"), 'update_time' => '', 'can_admin' => '1']);
        $this->insert('{{%_role}}', ['id' => '2', 'name' => 'User', 'create_time' => date("Y-m-d H:i:s"), 'update_time' => '', 'can_admin' => '0']);
        $this->insert('{{%users}}', ['user_id' => '1', 'role_id' => '1', 'status' => '1', 'email' => 'zeddarn@gmail.com', 'new_email' => '', 'username' => 'zeddarn@gmail.com', 'password' => '$2y$13$f2IGYslVbLKwxLdv7/7jZOFmlaGFad2g2EcCUu2Fl4Pt.GG1S5prG', 'auth_key' => '', 'api_key' => '', 'login_ip' => '::1', 'login_time' => date("Y-m-d H:i:s"), 'create_ip' => '', 'created_at' => '', 'updated_at' => date("Y-m-d H:i:s"), 'ban_time' => '', 'ban_reason' => '', 'created_by' => '1', 'updated_by' => '1', 'user_type' => 'A', 'company_id' => '3']);
        $this->insert('{{%_profile}}', ['id' => '1', 'user_id' => '1', 'created_at' => date("Y-m-d H:i:s"), 'updated_at' => date("Y-m-d H:i:s"), 'first_name' => 'Travel', 'last_name' => 'Chat', 'gender' => 'Male', 'mobile' => '', 'avatar' => '',]);
        $this->execute('SET foreign_key_checks = 1;');
    }

    public function down() {
        
    }

}
