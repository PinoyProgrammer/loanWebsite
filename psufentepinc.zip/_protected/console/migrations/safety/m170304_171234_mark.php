<?php

use yii\db\Migration;

class m170304_171234_mark extends Migration {

    public function up() {
//        $tables = Yii::$app->db->schema->getTableNames();
//        $dbType = $this->db->driverName;
//        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
//        $tableOptions_mssql = "";
//        $tableOptions_pgsql = "";
//        $tableOptions_sqlite = "";
//        /* MYSQL */
//        if (!in_array('likes', $tables)) {
//            if ($dbType == "mysql") {
//                $this->createTable('{{%likes}}', [
//                    'id' => $this->primaryKey(),
//                    'post_id' => $this->integer()->defaultValue(0),
//                    'mark_user_id' => $this->integer()->defaultValue(0),
//                    'user_id' => $this->integer()->defaultValue(0),
//                    'created_at' => $this->datetime(),
//                    'updated_at' => $this->datetime(),
//                    'created_by' => $this->integer()->defaultValue(0),
//                    'updated_by' => $this->integer()->defaultValue(0),
//                        ], $tableOptions_mysql);
//                $this->addPrimaryKey('id_pk', '{{%likes}}', [id]);
//            }
//        }
//
//        /* MYSQL */
//        if (!in_array('marks', $tables)) {
//            if ($dbType == "mysql") {
//                $this->createTable('{{%marks}}', [
//                    'id' => $this->primaryKey(),
//                    'post_id' => $this->integer()->defaultValue(0),
//                    'mark_user_id' => $this->integer()->defaultValue(0),
//                    'user_id' => $this->integer()->defaultValue(0),
//                    'created_at' => $this->datetime(),
//                    'updated_at' => $this->datetime(),
//                    'created_by' => $this->integer()->defaultValue(0),
//                    'updated_by' => $this->integer()->defaultValue(0),
//                        ], $tableOptions_mysql);
//                $this->addPrimaryKey('id_pk', '{{%marks}}', [id]);
//            }
//        }
//
//        /* MYSQL */
//        if (!in_array('post_views', $tables)) {
//            if ($dbType == "mysql") {
//                $this->createTable('{{%post_views}}', [
//                    'id' => $this->primaryKey(),
//                    'post_id' => $this->integer()->defaultValue(0),
//                    'mark_user_id' => $this->integer()->defaultValue(0),
//                    'user_id' => $this->integer()->defaultValue(0),
//                    'created_at' => $this->datetime(),
//                    'updated_at' => $this->datetime(),
//                    'created_by' => $this->integer()->defaultValue(0),
//                    'updated_by' => $this->integer()->defaultValue(0),
//                        ], $tableOptions_mysql);
//                $this->addPrimaryKey('id_pk', '{{%post_views}}', [id]);
//            }
//        }
//
//        /* MYSQL */
//        if (!in_array('posts', $tables)) {
//            if ($dbType == "mysql") {
//                $this->createTable('{{%posts}}', [
//                    'id' => $this->primaryKey(),
//                    'post_title' => $this->string(100),
//                    'post_amount' => $this->string(255),
//                    'post_message' => $this->string(255),
//                    'created_at' => $this->datetime(),
//                    'updated_at' => $this->datetime(),
//                    'created_by' => $this->integer()->defaultValue(0),
//                    'updated_by' => $this->integer()->defaultValue(0),
//                    'mark_type' => $this->integer()->defaultValue(0),
//                    'mark_as_group' => $this->integer()->defaultValue(0),
//                    'mark_notify' => $this->integer()->defaultValue(0),
//                    'mark_surprise' => $this->integer()->defaultValue(0),
//                    'mark_address' => $this->string(255),
//                    'mark_lat' => $this->string(255),
//                    'mark_long' => $this->string(255),
//                    'marks' => $this->integer()->defaultValue(0),
//                    'views' => $this->integer()->defaultValue(0),
//                    'likes' => $this->integer()->defaultValue(0),
//                    'distance' => $this->integer()->defaultValue(0),
//                    'user_id' => $this->integer()->defaultValue(0),
//                        ], $tableOptions_mysql);
//                $this->addPrimaryKey('id_pk', '{{%posts}}', [id]);
//            }
//        }
    }

    public function down() {
        echo "m170304_171234_mark cannot be reverted.\n";

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
