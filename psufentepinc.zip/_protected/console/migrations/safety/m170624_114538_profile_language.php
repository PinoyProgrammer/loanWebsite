<?php

use yii\db\Migration;

class m170624_114538_profile_language extends Migration {

    public function safeUp() {
        $this->alterColumn("{{%_profile}}", "avatar", $this->string(255)->notNull()->defaultValue(""));
        $this->addColumn("{{%_profile}}", "language", $this->string(20)->notNull()->defaultValue("en"));
    }

    public function safeDown() {
        echo "m170624_114538_profile_language cannot be reverted.\n";

        return false;
    }

    // Use up()/down() to run migration code without a transaction.
    public function up() {
        $this->alterColumn("{{%_profile}}", "avatar", $this->string(255)->notNull()->defaultValue(""));
        $this->addColumn("{{%_profile}}", "language", $this->string(20)->notNull()->defaultValue("en"));
    }

    /*
      public function down()
      {
      echo "m170624_114538_profile_language cannot be reverted.\n";

      return false;
      }
     */
}
