<?php

use yii\db\Migration;

class m170906_170951_profiles_lines extends Migration {

    public function safeUp() {


        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        /* MYSQL */
        if (!in_array('{{%profile_lines}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%profile_lines}}', [
                    'id' => $this->primaryKey(),
                    'user_id' => $this->integer()->notNull(),
                    'type' => $this->string(64)->notNull(),
                    'reference' => $this->string(20),                
                    'status' => $this->integer()->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                    'city' => $this->string(45),
                    'address' => $this->string(45),
                    'zipcode' => $this->string(45),
                    'county_code' => $this->string(45),
                    'date_of_birth' => $this->date(),                    
                    'kra_pin' => $this->string(45),
                    'mobile_1' => $this->string(45),
                    'mobile_2' => $this->string(45),                    
                    'id_type' => $this->integer(),
                    'id_number' => $this->string(45),
                    
                        ], $tableOptions_mysql);
            }
        }   

        $this->createIndex('idx_user_id_7048_00', '{{%profile_lines}}', 'user_id', 0);
    }

    public function safeDown() {
        echo "m170906_170951_profiles_lines cannot be reverted.\n";

        return false;
    }

}
