<?php

use yii\db\Migration;

class m170907_145358_loans extends Migration {

    public function safeUp() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        /* MYSQL */
        if (!in_array('{{%loan_types}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%loan_types}}', [
                    'loan_type_id' => $this->primaryKey(),
                    'code' => $this->string(10)->notNull(),
                    'name' => $this->string(64)->notNull(),
                    'status' => $this->integer()->notNull(),
                    'is_approval_required' => $this->integer()->notNull(),
                    'loan_treshhold_approval_amount' => $this->decimal(12, 2),
                    'loan_treshhold_approval_rate' => $this->decimal(12, 2),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                    'loan_limit_ratio' => $this->decimal(12, 2),
                    'processing_fee_rate' => $this->decimal(12, 2),
                    'processing_fee_amount' => $this->decimal(12, 2),
                    'minimum_share_contribution_percent' => $this->decimal(12, 2),
                    'minimum_share_contribution_amount' => $this->decimal(12, 2),
                    'minimum_contribution_periods_months' => $this->decimal(12, 2),
                    'loan_interest_rate' => $this->decimal(12, 2),
                    'tax_rate_percent' => $this->date(),
                    'min_period' => $this->decimal(12, 2),
                    'max_period' => $this->decimal(12, 2),
                    'penalty_rate_percent' => $this->decimal(12, 2),
                    'penalty_days' => $this->decimal(12, 2),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%loans}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%loans}}', [
                    'loan_id' => $this->primaryKey(),
                    'loan_type_id' => $this->integer()->notNull(),
                    'user_id' => $this->integer()->notNull(),
                    'loan_number' => $this->string(64)->notNull(),
                    'loan_status' => $this->string()->notNull(),
                    'date_applied' => $this->date()->notNull(),
                    'date_issued' => $this->date(),
                    'loan_principal_amount' => $this->decimal(12, 2),
                    'loan_interest_rate' => $this->decimal(12, 2),
                    'loan_repayment_period' => $this->decimal(12, 2),
                    'loan_instalment_amount' => $this->decimal(12, 2),
                    'loan_interest_amount' => $this->decimal(12, 2),
                    'last_repayment_date' => $this->date(),
                    'loan_balance' => $this->decimal(12, 2),
                    'tax_rate_percent' => $this->decimal(12, 2),
                    'loan_due_date' => $this->date(),
                    'loan_date_completed' => $this->date(),
                    'penalty_rate' => $this->decimal(12, 2),
                    'loan_approved_at' => $this->datetime(),
                    'loan_approved_by' => $this->integer(),
                    'loan_approve_reject' => $this->integer(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%loan_reasons}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%loan_reasons}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(64)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%payment_providers}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%payment_providers}}', [
                    'id' => $this->primaryKey(),
                    'provider_id' => $this->string(64)->notNull(),
                    'provider_name' => $this->string(64)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%payment_transactions}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%payment_transactions}}', [
                    'loan_id' => $this->primaryKey(),
                    'loan_type_id' => $this->integer()->notNull(),
                    'user_id' => $this->integer()->notNull(),
                    'payment_status' => $this->integer()->notNull(),
                    'provider_id' => $this->string(50)->notNull(),
                    'provider_name' => $this->string(50)->notNull(),
                    'payment_currency' => $this->string(50)->notNull(),
                    'payment_repayment_period' => $this->integer(),
                    'payment_instalment_amount' => $this->decimal(12, 2)->notNull(),
                    'payment_ref' => $this->string(50)->notNull(),
                    'payment_type' =>$this->string(50)->notNull(),
                    'description' => $this->string(100)->notNull(),
                    'payment_approved_at' => $this->datetime(),
                    'payment_approved_by' => $this->integer(),
                    'payment_approve_reject' => $this->integer(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
    }

    public function safeDown() {
        echo "m170907_145358_loans cannot be reverted.\n";
    }

    /*
      // Use up()/down() to run migration code without a transaction.
      public function up()
      {

      }

      public function down()
      {
      echo "m170907_145358_loans cannot be reverted.\n";

      return false;
      }
     */
}
