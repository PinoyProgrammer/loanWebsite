<?php

use yii\db\Migration;

class m170624_172141_payment_tx extends Migration {

    public function safeUp() {
        
    }

    public function safeDown() {
        echo "m170624_172141_payment_tx cannot be reverted.\n";

        return false;
    }

    // Use up()/down() to run migration code without a transaction.
    public function up() {

        //if ($dbType == "mysql") {
        $this->createTable('{{%payment_transactions}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'order_id' => $this->integer()->notNull(),
            'provider_id' => $this->string(20)->notNull(),
            'provider_name' => $this->string(255)->notNull(),
            'payment_currency' => $this->string(255)->notNull(),
            'payment_amount' => $this->decimal(12,2)->notNull(),
            'created_at' => $this->dateTime()->null(),
            'updated_at' => $this->dateTime()->null(),
                ]);
        //}
    }

    /*
      public function down()
      {
      echo "m170624_172141_payment_tx cannot be reverted.\n";

      return false;
      }
     */
}
