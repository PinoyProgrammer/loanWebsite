<?php

use yii\db\Migration;

class m160101_000008_create_rm_tables extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */


        /* MYSQL */
        if (!in_array('building', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%building}}', [
                    'buildingid' => $this->primaryKey(),
                    'buildingname' => $this->string(45)->null(),
                    'landlordid' => $this->integer()->null()->defaultValue(0),
                    'noofunits' => $this->integer()->null()->defaultValue(0),
                    'unittypeid' => $this->string(45)->null(),
                    'dueday' => $this->integer()->null()->defaultValue(0),
                    'location' => $this->string(45)->null(),
                    'lrno' => $this->string(45)->null(),
                    'deposits' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'rents' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'servicecharge' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'caretaker' => $this->string(45)->null(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }




        /* MYSQL */
        if (!in_array('floors', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%floors}}', [
                    'floorno' => $this->primaryKey(),
                    'floorname' => $this->string(45)->null(),
                    'accessibility' => $this->string(45)->null(),
                    'noofrooms' => $this->integer()->null(),
                    'roomtypes' => $this->string(45)->null(),
                    'location' => $this->string(45)->null(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }




        /* MYSQL */
        if (!in_array('landlord_tx', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%landlord_tx}}', [
                    'id' => $this->primaryKey(),
                    'landlordid' => $this->integer()->notNull(),
                    'buildingid' => $this->integer()->notNull(),
                    'date' => $this->date()->null(),
                    'docno' => $this->string(45)->null(),
                    'doctype' => $this->string(45)->null(),
                    'usercode' => $this->string(45)->null(),
                    'narration' => $this->string(100)->null(),
                    'amount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'balance' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'userid' => $this->integer()->notNull()->defaultValue(0),
                    'timestamp' => $this->timestamp()->null(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('tenanttransactions', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%tenanttransactions}}', [
                    'transactionid' => $this->primaryKey(),
                    'date' => $this->date(),
                    'doctype' => $this->string(45)->null(),
                    'docno' => $this->string(45)->null(),
                    'tenantid' => $this->string(45)->null(),
                    'tenantname' => $this->string(45)->null(),
                    'buildingid' => $this->string(45)->null(),
                    'suiteid' => $this->integer()->notNull()->defaultValue(0),
                    'amount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'balance' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'netamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'taxamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'particulars' => $this->string(45)->null(),
                    'timestamp' => $this->datetime(),
                    'ref2' => $this->string(45)->null(),
                    'callocs' => $this->text(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'itemid' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('landlords', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%landlords}}', [
                    'landlordid' => $this->primaryKey(),
                    'commissionrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'bfwd' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'deposits' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'rent' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'servicecharges' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'monthlyrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'utilitypaid' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'commissionamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'netamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'remmitances' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'balance' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'glincome' => $this->string(10)->null(),
                    'glcommission' => $this->string(10)->null(),
                    'advancethreshold' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'interestonadvance' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'interestrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'fname' => $this->string(50)->null(),
                    'lname' => $this->string(50)->null(),
                    'status' => $this->integer(1)->notNull()->defaultValue(0),
                    'bank_name' => $this->string(100)->null(),
                    'bank_account_name' => $this->string(100)->null(),
                    'bank_account_no' => $this->string(100)->null(),
                        ], $tableOptions_mysql);
            }
        }


        /* MYSQL */
        if (!in_array('pmanager', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%pmanager}}', [
                    'cid' => $this->primaryKey(),
                    'telephone' => $this->string(45)->null(),
                    'status' => $this->string(45)->null(),
                    'salary' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'commission' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'fname' => $this->string(50)->null(),
                    'lname' => $this->string(50)->null(),
                        ], $tableOptions_mysql);
            }
        }


        /* MYSQL */
        if (!in_array('rentreturns', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%rentreturns}}', [
                    'returnid' => $this->primaryKey(),
                    'buildingid' => $this->string(45)->null(),
                    'suitenumber' => $this->string(45)->null(),
                    'landlordid' => $this->string(45)->null(),
                    'tenantid' => $this->string(45)->null(),
                    'currenttenant' => $this->string(45)->null(),
                    'deposit' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'rent' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'servicecharges' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'montlyrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'bfwd' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'invoiceytd' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'creditnotesytd' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'jan' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'feb' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'mar' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'apr' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'may' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'jun' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'jul' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'aug' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'sep' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'oct' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'nov' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'dece' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'receiptsytd' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'balance' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'penaltyamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'currentreceipts' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'depositrefund' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'commissionrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'currentcommissionamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'utilitypaid' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'duetolandlord' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'paidtolandlord' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'balanceduetolandlord' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('suites', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%suites}}', [
                    'buildingid' => $this->integer()->notNull(),
                    'suitenumber' => $this->string(45)->null(),
                    'suitename' => $this->string(45)->null(),
                    'taxrate' => $this->string(45)->null(),
                    'deposit' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'rent' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'servicecharges' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'montlyrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'currenttenant' => $this->string(45)->null(),
                    'dateoccupied' => $this->date()->null(),
                    'datevacated' => $this->date()->null(),
                    'dueday' => $this->integer()->null()->defaultValue(0),
                    'tenantid' => $this->string(45)->null(),
                    'contractstartdate' => $this->date()->null(),
                    'contractenddate' => $this->date()->null(),
                    'contractduration' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'commissionrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'commissionamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'penaltyrate' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'penaltyamount' => $this->decimal(12, 2)->null()->defaultValue(0),
                    'incharge' => $this->integer()->null(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'gl_account_receivable' => $this->integer()->null(),
                    'gl_customers_deposits' => $this->integer()->null(),
                    'gl_income' => $this->integer()->null(),
                    'gl_penalty' => $this->integer()->null(),
                    'suiteid' => $this->primaryKey(),
                    'gl_commission' => $this->integer()->notNull()->defaultValue(0),
                    'occupancystatus' => $this->integer()->null()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }


        /* MYSQL */
        if (!in_array('tax_rates', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%tax_rates}}', [
                    'id' => $this->primaryKey(),
                    'code' => $this->string(10)->notNull(),
                    'name' => $this->string(100)->notNull(),
                    'status' => $this->integer()->notNull()->defaultValue(0),
                    'tax_rate' => $this->decimal(12, 4)->notNull(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'created_date' => $this->datetime(),
                    'updated_date' => $this->datetime(),
                    'created_by' => $this->integer()->notNull()->defaultValue(0),
                    'updated_by' => $this->integer()->notNull()->defaultValue(0),
                    'glaccountno' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        /* MYSQL */
        if (!in_array('unittypes', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%unittypes}}', [
                    'unittypeid' => $this->primaryKey(),
                    'unittypename' => $this->string(45)->null(),
                        ], $tableOptions_mysql);
            }
        }
        $this->createIndex('idx_UNIQUE_suitenumber_7974_47', 'rentreturns', 'suitenumber', 1);
        $this->createIndex('idx_suitenumber_8045_48', 'suites', 'suitenumber', 0);

        $this->execute('SET foreign_key_checks = 0');
        $this->insert('{{%accessibilitymethods}}', ['id' => '1', 'method' => 'Lift/Stairs', 'company_id' => '0']);
        $this->execute('SET foreign_key_checks = 1;');
    }

    public function down() {
        echo "m160611_095237_first_600 cannot be reverted.\n";
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `sys_program`');
        $this->execute('SET foreign_key_checks = 1;');
        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
