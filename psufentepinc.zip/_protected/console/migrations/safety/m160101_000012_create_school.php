<?php

use yii\db\Migration;

class m160101_000012_create_school extends Migration {

    public function up() {

        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        if (!in_array('grades', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%grades}}', [
                    'id' => $this->primaryKey(),
                    'code' => $this->string(50)->notNull(),
                    'name' => $this->string(150)->notNull(),
                    'order' => $this->integer(3)->notNull(),
                    'visible' => $this->integer(1)->notNull()->defaultValue(1),
                    'program_id' => $this->integer(5)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('relationships', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%relationships}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(50)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('batches', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%batches}}', [
                    'batch_id' => $this->primaryKey(),
                    'batch_name' => $this->string(120)->notNull(),
                    'batch_course_id' => $this->integer(11)->notNull(),
                    'batch_desc' => $this->text(),
                    'start_date' => $this->date()->notNull(),
                    'end_date' => $this->date()->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_leave', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_leave}}', [
                    'staff_leave_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'from_date' => $this->date()->notNull(),
                    'to_date' => $this->date()->notNull(),
                    'reason' => $this->text(),
                    'no_of_days' => $this->decimal(12, 2)->notNull(),
                    'update_at' => $this->datetime()->notNull(),
                    'deleted' => $this->integer(1)->notNull()->defaultValue(0),
                    'staff_leave_type_id' => $this->integer(11)->notNull(),
                    'staff_leave_status_id' => $this->integer(11)->notNull(),
                    'applied_date' => $this->date()->notNull(),
                    'user_login_id' => $this->integer(11)->notNull(),
                    'approved_rejected_date' => $this->date()->notNull(),
                    'date_type' => $this->string(50)->notNull(),
                    'comment' => $this->string(150)->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('civil_status', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%civil_status}}', [
                    'civil_status_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('national_holidays', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%national_holidays}}', [
                    'national_holiday_id' => $this->primaryKey(),
                    'national_holiday_name' => $this->string(50)->notNull(),
                    'national_holiday_date' => $this->date()->notNull(),
                    'national_holiday_remarks' => $this->string(100)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('exam_admissions', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%exam_admissions}}', [
                    'exam_admission_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'admission_no' => $this->string(50)->notNull(),
                    'exam_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_docs', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_docs}}', [
                    'stu_docs_id' => $this->primaryKey(),
                    'stu_docs_details' => $this->string(100)->notNull(),
                    'stu_docs_category_id' => $this->integer(11)->notNull(),
                    'stu_docs_path' => $this->string(150)->notNull(),
                    'stu_docs_submited_at' => $this->datetime()->notNull(),
                    'stu_docs_status' => $this->integer(1)->notNull()->defaultValue(0),
                    'stu_docs_stu_master_id' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('fees_schedule_detail', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%fees_schedule_detail}}', [
                    'fees_schedule_detail_id' => $this->primaryKey(),
                    'fees_schedule_id' => $this->integer(11)->notNull(),
                    'fees_schedule_itemid' => $this->integer(11)->notNull(),
                    'fees_schedule_amount' => $this->double(18, 2)->notNull()->defaultValue(0),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('subject_teacher', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%subject_teacher}}', [
                    'subject_teacher_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'grade_subject_id' => $this->integer(11)->notNull(),
                    'class_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'deleted' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_seminar', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_seminar}}', [
                    'stu_seminar_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'seminar_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(200)->null(),
                    'year' => $this->date()->notNull(),
                    'status' => $this->integer(4)->null(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_external_activity', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_external_activity}}', [
                    'staff_external_activity_id' => $this->integer(11)->notNull(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'external_activity' => $this->string(250)->null(),
                    'achievement' => $this->string(250)->null(),
                    'year' => $this->date()->notNull(),
                    'status' => $this->integer(4)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_info', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_info}}', [
                    'stu_info_id' => $this->primaryKey(),
                    'stu_unique_id' => $this->string(50)->notNull(),
                    'stu_title' => $this->string(5)->null(),
                    'stu_first_name' => $this->string(50)->notNull(),
                    'stu_middle_name' => $this->string(50)->null(),
                    'stu_last_name' => $this->string(50)->notNull(),
                    'stu_gender' => $this->string(10)->null(),
                    'stu_birth_cert_no_scan' => $this->string(255)->null(),
                    'stu_birth_cert_no' => 'VARCHAR(80) NULL',
                    'stu_id_number' => $this->string(50)->notNull(),
                    'stu_dob' => $this->date()->notNull(),
                    'stu_email_id' => $this->string(65)->null(),
                    'stu_bloodgroup' => 'VARCHAR(10) NULL DEFAULT \'Unknown\'',
                    'stu_birthplace' => $this->string(50)->notNull(),
                    'stu_religion' => $this->string(50)->null(),
                    'stu_admission_date' => $this->date()->notNull(),
                    'stu_photo' => $this->string(150)->null(),
                    'stu_languages' => $this->string(255)->null(),
                    'stu_mobile_no' => $this->string(12)->null(),
                    'stu_info_stu_master_id' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_discipline', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_discipline}}', [
                    'student_discipline_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'warning_level_id' => $this->integer(11)->notNull(),
                    'user_login_id' => $this->integer(11)->notNull(),
                    'comment' => $this->string(50)->notNull(),
                    'is_informed_to_parent' => $this->integer(1)->notNull()->defaultValue(0),
                    'date' => $this->date()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('warning_level', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%warning_level}}', [
                    'warning_level_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'colour' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_leave_type', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_leave_type}}', [
                    'staff_leave_type_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'max_no_of_leaves' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'gender' => 'CHAR(1) NULL DEFAULT \'a\'',
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('section_head', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%section_head}}', [
                    'section_head_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'start_date' => $this->date()->notNull(),
                    'grade_id' => $this->integer(11)->notNull(),
                    'end_date' => $this->date()->notNull(),
                    'notes' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'section_id' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('parameter', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%parameter}}', [
                    'id' => $this->integer(11)->notNull(),
                    'name' => $this->string(50)->null(),
                    'value' => 'TEXT NULL',
                    'value2' => 'DOUBLE(25,2) NULL',
                    'narration' => 'TEXT NULL',
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_sub_term_mark', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_sub_term_mark}}', [
                    'student_sub_term_mark_id' => $this->primaryKey(),
                    'student_term_marks_id' => $this->integer(11)->notNull(),
                    'sub_term_id' => $this->integer(11)->notNull(),
                    'grading_id' => $this->integer(11)->notNull(),
                    'is_absent' => $this->integer(4)->null(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'marks' => $this->float(5, 2)->notNull()->defaultValue(0),
                    'edit_mark_state' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_sport', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_sport}}', [
                    'staff_sport_id' => $this->integer(11)->notNull(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'sport_category_id' => $this->integer(11)->notNull(),
                    'position_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(200)->null(),
                    'year' => $this->date()->notNull(),
                    'status' => $this->integer(4)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('race', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%race}}', [
                    'race_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('faith_life_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%faith_life_category}}', [
                    'faith_life_category_id' => $this->integer(11)->notNull(),
                    'description' => $this->text(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_club_society', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_club_society}}', [
                    'staff_club_society_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'club_society_id' => $this->integer(11)->notNull(),
                    'position_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'status' => $this->integer(4)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */



        /* MYSQL */
        if (!in_array('emp_info', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_info}}', [
                    'emp_info_id' => $this->primaryKey(),
                    'emp_unique_id' => $this->integer(11)->notNull(),
                    'emp_attendance_card_id' => $this->string(50)->null(),
                    'emp_title' => $this->string(5)->null(),
                    'emp_first_name' => $this->string(50)->notNull(),
                    'emp_middle_name' => $this->string(50)->null(),
                    'emp_last_name' => $this->string(50)->notNull(),
                    'emp_name_alias' => $this->string(10)->null(),
                    'emp_mother_name' => $this->string(50)->null(),
                    'emp_gender' => $this->string(10)->null(),
                    'emp_dob' => $this->date()->notNull(),
                    'emp_religion' => $this->string(50)->null(),
                    'emp_bloodgroup' => $this->string(50)->notNull()->defaultValue('Unknown'),
                    'emp_joining_date' => $this->date()->notNull(),
                    'emp_birthplace' => $this->string(50)->null(),
                    'emp_email_id' => $this->string(65)->null(),
                    'emp_maritalstatus' => $this->string(50)->null(),
                    'emp_mobile_no' => $this->string(12)->null(),
                    'emp_photo' => $this->string(150)->null(),
                    'emp_languages' => $this->string(255)->null(),
                    'emp_bankaccount_no' => $this->string(25)->null(),
                    'emp_qualification' => $this->string(50)->null(),
                    'emp_specialization' => $this->string(255)->null(),
                    'emp_experience_year' => $this->integer(2)->null(),
                    'emp_experience_month' => $this->integer(2)->null(),
                    'emp_hobbies' => $this->string(100)->notNull(),
                    'emp_reference' => $this->string(50)->null(),
                    'emp_guardian_name' => $this->string(65)->null(),
                    'emp_guardian_relation' => $this->string(30)->null(),
                    'emp_guardian_qualification' => $this->string(50)->null(),
                    'emp_guardian_occupation' => $this->string(50)->null(),
                    'emp_guardian_income' => $this->string(50)->null(),
                    'emp_guardian_homeadd' => $this->string(255)->null(),
                    'emp_guardian_officeadd' => $this->string(255)->null(),
                    'emp_guardian_mobile_no' => $this->string(12)->null(),
                    'emp_guardian_phone_no' => $this->string(25)->null(),
                    'emp_guardian_email_id' => $this->string(65)->null(),
                    'emp_info_emp_master_id' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('publication_type', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%publication_type}}', [
                    'publication_type_id' => $this->primaryKey(),
                    'type' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('subject', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%subject}}', [
                    'subject_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'subject_code' => $this->string(5)->null(),
                    'gov_subject_code' => $this->string(10)->null(),
                    'program_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('professional_qualification', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%professional_qualification}}', [
                    'professional_qual_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('faith_life_rating', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%faith_life_rating}}', [
                    'faith_life_rating_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'faith_life_description' => $this->string(100)->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'year' => $this->date()->notNull(),
                    'faith_life_comment_id' => $this->integer(11)->notNull(),
                    'grading_id' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('emp_designation', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_designation}}', [
                    'emp_designation_id' => $this->primaryKey(),
                    'emp_designation_name' => $this->string(50)->notNull(),
                    'emp_designation_alias' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('grading', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%grading}}', [
                    'grading_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'grade_acronym' => $this->char(1)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_category}}', [
                    'par_category_id' => $this->primaryKey(),
                    'par_category_name' => $this->string(50)->notNull(),
                    'par_category_alias' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('section_assignment', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%section_assignment}}', [
                    'assignment_id' => $this->primaryKey(),
                    'sclass_id' => $this->integer(11)->notNull(),
                    'stream_id' => $this->integer(11)->notNull(),
                    'section_id' => $this->integer(11)->notNull(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                    'intakeno' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('section', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%section}}', [
                    'section_id' => $this->primaryKey(),
                    'section_name' => $this->string(50)->notNull(),
                    'section_stream_id' => $this->integer(11)->notNull(),
                    'intake' => $this->integer(5)->null(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                    'section_desc' => $this->text(),
                    'section_batch_id' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('participant_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%participant_category}}', [
                    'participant_category_id' => $this->primaryKey(),
                    'description' => $this->string(100)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('religion', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%religion}}', [
                    'religion_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_category}}', [
                    'staff_category_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'is_academic' => $this->integer(1)->notNull()->defaultValue(1),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('class_grade', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%class_grade}}', [
                    'class_grade_id' => $this->primaryKey(),
                    'sclass_id' => $this->integer(11)->notNull(),
                    'grade_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(50)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_sport', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_sport}}', [
                    'student_sport_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'sport_category_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'position_id' => $this->integer(11)->notNull(),
                    'status' => $this->integer(4)->null(),
                    'is_school_colour' => $this->smallInteger(1)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_docs', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_docs}}', [
                    'par_docs_id' => $this->primaryKey(),
                    'par_docs_details' => $this->string(100)->notNull(),
                    'par_docs_category_id' => $this->integer(11)->notNull(),
                    'par_docs_path' => $this->string(150)->notNull(),
                    'par_docs_submited_at' => $this->datetime()->notNull(),
                    'par_docs_status' => $this->integer(1)->notNull()->defaultValue(0),
                    'par_docs_par_master_id' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('notice', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%notice}}', [
                    'notice_id' => $this->primaryKey(),
                    'notice_title' => $this->string(25)->notNull(),
                    'notice_description' => $this->string(255)->null(),
                    'notice_user_type' => $this->char(3)->notNull(),
                    'notice_date' => $this->date()->notNull(),
                    'notice_file_path' => $this->string(100)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('fees_collect_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%fees_collect_category}}', [
                    'fees_collect_category_id' => $this->primaryKey(),
                    'fees_collect_name' => $this->string(70)->notNull(),
                    'fees_collect_stream_id' => $this->integer(11)->notNull(),
                    'fees_collect_details' => $this->string(255)->null(),
                    'fees_collect_start_date' => $this->date()->notNull(),
                    'fees_collect_end_date' => $this->date()->notNull(),
                    'fees_collect_due_date' => $this->date()->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_leave', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_leave}}', [
                    'student_leave_id' => $this->integer(11)->notNull(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'from_date' => $this->date()->notNull(),
                    'to_date' => $this->date()->notNull(),
                    'reason' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->notNull(),
                    'certificate_given' => $this->smallInteger(4)->notNull(),
                    'no_of_days' => $this->integer(11)->notNull(),
                    'check_autogenerated' => $this->smallInteger(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('term', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%term}}', [
                    'term_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'from_month' => $this->date()->notNull(),
                    'to_month' => $this->date()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('emp_docs', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_docs}}', [
                    'emp_docs_id' => $this->primaryKey(),
                    'emp_docs_details' => $this->string(100)->notNull(),
                    'emp_docs_category_id' => $this->integer(11)->notNull(),
                    'emp_docs_path' => $this->string(150)->notNull(),
                    'emp_docs_submited_at' => $this->datetime()->notNull(),
                    'emp_docs_status' => $this->integer(1)->notNull()->defaultValue(0),
                    'emp_docs_emp_master_id' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_seminar', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_seminar}}', [
                    'staff_seminar_id' => $this->integer(11)->notNull(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'seminar_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(200)->null(),
                    'year' => $this->date()->notNull(),
                    'status' => $this->integer(4)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_master', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_master}}', [
                    'par_master_id' => $this->primaryKey(),
                    'par_master_par_info_id' => $this->integer(11)->notNull(),
                    'par_master_user_id' => $this->integer(11)->notNull(),
                    'par_master_department_id' => $this->integer(11)->notNull(),
                    'par_master_designation_id' => $this->integer(11)->notNull(),
                    'par_master_category_id' => $this->integer(11)->notNull(),
                    'par_master_nationality_id' => $this->integer(11)->notNull(),
                    'par_master_par_address_id' => $this->integer(11)->notNull(),
                    'par_master_status_id' => $this->integer()->notNull()->defaultValue(0),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_master', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_master}}', [
                    'stu_master_id' => $this->primaryKey(),
                    'stu_master_stu_info_id' => $this->integer(11)->notNull(),
                    'stu_master_user_id' => $this->integer(11)->notNull(),
                    'stu_master_nationality_id' => $this->integer(11)->notNull(),
                    'stu_master_category_id' => $this->integer(11)->notNull(),
                    'stu_master_course_id' => $this->integer(11)->notNull(),
                    'stu_master_batch_id' => $this->integer(11)->notNull(),
                    'stu_master_section_id' => $this->integer(11)->notNull(),
                    'stu_master_stu_status_id' => $this->integer()->notNull()->defaultValue(0),
                    'stu_master_stu_address_id' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('school_calendar', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%school_calendar}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(64)->null(),
                    'year' => $this->string(20)->null(),
                    'start_date' => $this->date()->notNull(),
                    'end_date' => $this->date()->notNull(),
                    'threshold' => $this->double(18, 2)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('streams', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%streams}}', [
                    'stream_id' => $this->primaryKey(),
                    'stream_name' => $this->string(120)->notNull(),
                    'stream_sclass_id' => $this->integer(11)->notNull(),
                    'stream_desc' => $this->text(),
                    'start_date' => $this->date()->notNull(),
                    'end_date' => $this->date()->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('emp_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_category}}', [
                    'emp_category_id' => $this->primaryKey(),
                    'emp_category_name' => $this->string(50)->notNull(),
                    'emp_category_alias' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_class_info', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_class_info}}', [
                    'student_class_info_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'class_grade_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'is_monitor' => $this->integer(1)->notNull()->defaultValue(0),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_suspend_details', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_suspend_details}}', [
                    'suspend_stu_master_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'from_date' => $this->date()->notNull(),
                    'to_date' => $this->date()->notNull(),
                    'stu_discipline_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(150)->null(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'no_of_days' => $this->integer(11)->notNull(),
                    'activated_date' => $this->date()->notNull(),
                    'curtailed_or_extended_reason' => $this->string(150)->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('club_society', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%club_society}}', [
                    'club_society_id' => $this->primaryKey(),
                    'name' => $this->string(50)->notNull(),
                    'description' => $this->string(250)->null(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('exam_subject', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%exam_subject}}', [
                    'exam_subject_id' => $this->primaryKey(),
                    'exam_id' => $this->integer(11)->notNull(),
                    'subject_id' => $this->integer(11)->notNull(),
                    'is_optional_subject' => $this->smallInteger(4)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('publication', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%publication}}', [
                    'publication_id' => $this->integer(11)->notNull(),
                    'header' => $this->string(50)->notNull(),
                    'message' => $this->text(),
                    'expiry_date' => $this->date()->notNull(),
                    'image' => $this->text(),
                    'publication_type_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('special_event_attendance', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%special_event_attendance}}', [
                    'special_event_attendance_id' => $this->integer(11)->notNull(),
                    'special_event_participation_id' => $this->integer(11)->notNull(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_educational', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_educational}}', [
                    'staff_educational_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'educational_qual_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(250)->null(),
                    'year' => $this->date()->notNull(),
                    'status' => $this->integer(4)->null(),
                    'experience' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_prefect', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_prefect}}', [
                    'stu_prefect_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'prefect_type_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_status', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_status}}', [
                    'stu_status_id' => $this->primaryKey(),
                    'stu_status_name' => $this->string(50)->notNull(),
                    'stu_status_description' => $this->string(100)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('house', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%house}}', [
                    'house_id' => $this->primaryKey(),
                    'name' => $this->string(50)->notNull(),
                    'colour' => $this->string(50)->notNull(),
                    'description' => $this->string(50)->notNull(),
                    'captain' => $this->integer(11)->notNull(),
                    'capacity' => $this->integer(11)->notNull(),
                    'vice_captain' => $this->integer(11)->notNull(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('msg_of_day', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%msg_of_day}}', [
                    'msg_of_day_id' => $this->primaryKey(),
                    'msg_details' => $this->string(100)->notNull(),
                    'msg_user_type' => $this->char(3)->notNull()->defaultValue(0),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('appointment_nature', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%appointment_nature}}', [
                    'appointment_nature_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_parent', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_parent}}', [
                    'stu_guardian_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'stu_par_relation_id' => $this->integer(11)->notNull(),
                    'par_master_id' => $this->integer(11)->notNull(),
                    'created_at' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('entity_states', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%entity_states}}', [
                    'state_id' => $this->primaryKey(),
                    'state_type' => $this->string(50)->notNull(),
                    'state_description' => $this->string(100)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_info', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_info}}', [
                    'par_info_id' => $this->primaryKey(),
                    'par_unique_id' => $this->integer(11)->notNull(),
                    'par_attendance_card_id' => $this->string(50)->null(),
                    'par_title' => $this->string(5)->null(),
                    'par_first_name' => $this->string(50)->notNull(),
                    'par_middle_name' => $this->string(50)->null(),
                    'par_last_name' => $this->string(50)->notNull(),
                    'par_name_alias' => $this->string(10)->null(),
                    'par_mother_name' => $this->string(50)->null(),
                    'par_gender' => $this->string(10)->null(),
                    'par_id_number' => $this->string(50)->notNull(),
                    'par_dob' => $this->date()->notNull(),
                    'par_religion' => $this->string(50)->null(),
                    'par_bloodgroup' => $this->string(50)->notNull()->defaultValue('Unknown'),
                    'par_joining_date' => $this->date()->notNull(),
                    'par_birthplace' => $this->string(50)->null(),
                    'par_email_id' => $this->string(65)->null(),
                    'par_maritalstatus' => $this->string(50)->null(),
                    'par_mobile_no' => $this->string(12)->null(),
                    'par_mobile_no2' => $this->string(50)->notNull(),
                    'par_mobile_no1' => $this->string(50)->notNull(),
                    'par_photo' => $this->string(150)->null(),
                    'par_languages' => $this->string(255)->null(),
                    'par_bankaccount_no' => $this->string(25)->null(),
                    'par_qualification' => $this->string(50)->null(),
                    'par_specialization' => $this->string(255)->null(),
                    'par_experience_year' => $this->integer(2)->null(),
                    'par_experience_month' => $this->integer(2)->null(),
                    'par_hobbies' => $this->string(100)->notNull(),
                    'par_reference' => $this->string(50)->null(),
                    'par_guardian_name' => $this->string(65)->null(),
                    'par_guardian_relation' => $this->string(30)->null(),
                    'par_guardian_qualification' => $this->string(50)->null(),
                    'par_guardian_occupation' => $this->string(50)->null(),
                    'par_guardian_income' => $this->string(50)->null(),
                    'par_guardian_homeadd' => $this->string(255)->null(),
                    'par_guardian_officeadd' => $this->string(255)->null(),
                    'par_guardian_mobile_no' => $this->string(12)->null(),
                    'par_guardian_phone_no' => $this->string(25)->null(),
                    'par_guardian_email_id' => $this->string(65)->null(),
                    'par_info_par_master_id' => $this->integer(11)->notNull(),
                    'par_occupation' => $this->string(255)->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('faith_life_comment', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%faith_life_comment}}', [
                    'faith_life_comment_id' => $this->integer(11)->notNull(),
                    'description' => $this->text(),
                    'faith_life_category_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('class_subjects', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%class_subjects}}', [
                    'id' => $this->primaryKey(),
                    'class_id' => $this->integer(11)->notNull(),
                    'subject_id' => $this->integer(5)->notNull(),
                    'visible' => $this->smallInteger(4)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('special_events', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%special_events}}', [
                    'special_events_id' => $this->primaryKey(),
                    'name' => $this->string(250)->null(),
                    'description' => $this->text(),
                    'date' => $this->date()->notNull(),
                    'participant_category_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('sub_term', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%sub_term}}', [
                    'sub_term_id' => $this->primaryKey(),
                    'term_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(50)->notNull(),
                    'from_month' => $this->date()->notNull(),
                    'to_month' => $this->date()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('past_student', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%past_student}}', [
                    'past_stu_master_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'departure_date' => $this->date()->notNull(),
                    'reason' => $this->string(250)->null(),
                    'complete_clearance' => $this->integer(1)->notNull()->defaultValue(0),
                    'admission_date' => $this->date()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('school_years', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%school_years}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(50)->notNull(),
                    'start_date' => $this->date()->notNull(),
                    'start_year' => $this->integer(4)->null(),
                    'end_date' => $this->date()->notNull(),
                    'end_year' => $this->integer(4)->null(),
                    'school_days' => $this->integer(4)->notNull()->defaultValue(0),
                    'order' => $this->integer(4)->notNull()->defaultValue(0),
                    'visible' => $this->integer(1)->notNull()->defaultValue(1),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->null(),
                    'updated_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('master_in_charge', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%master_in_charge}}', [
                    'master_in_charge_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'club_society_id' => $this->integer(11)->notNull(),
                    'sport_category_id' => $this->integer(11)->notNull(),
                    'house_id' => $this->integer(11)->notNull(),
                    'mic_from_date' => $this->date()->notNull(),
                    'mic_to_date' => $this->date()->notNull(),
                    'note' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('donation_type', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%donation_type}}', [
                    'donation_type_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('assessment_items', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%assessment_items}}', [
                    'id' => $this->primaryKey(),
                    'min' => $this->integer(4)->notNull()->defaultValue(50),
                    'max' => $this->integer(4)->notNull()->defaultValue(100),
                    'weighting' => $this->float(2)->notNull()->defaultValue(0),
                    'visible' => $this->smallInteger(4)->notNull(),
                    'grade_id' => $this->integer(11)->notNull(),
                    'subject_id' => $this->integer(5)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'created_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stream', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stream}}', [
                    'stream_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'class_id' => $this->integer()->notNull()->defaultValue(0),
                    'no_of_students' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('marking_flag', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%marking_flag}}', [
                    'marking_flag_id' => $this->primaryKey(),
                    'class_grade_id' => $this->integer(11)->notNull(),
                    'term_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'marking_completed' => $this->smallInteger(4)->notNull(),
                    'grade_id' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_scholarship', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_scholarship}}', [
                    'student_scholarship_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'scholarship_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'comments' => $this->string(150)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('merit_award', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%merit_award}}', [
                    'merit_award_id' => $this->primaryKey(),
                    'award_description' => $this->string(100)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_status', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_status}}', [
                    'par_status_id' => $this->primaryKey(),
                    'par_status_name' => $this->string(50)->notNull(),
                    'par_status_description' => $this->string(100)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_club_society', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_club_society}}', [
                    'student_club_society_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'club_society_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'position_id' => $this->integer(11)->notNull(),
                    'membership_no' => $this->string(50)->notNull(),
                    'status' => $this->integer(4)->null(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('fees_category_details', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%fees_category_details}}', [
                    'fees_category_details_id' => $this->primaryKey(),
                    'fees_details_name' => $this->string(70)->notNull(),
                    'fees_details_category_id' => $this->integer(11)->notNull(),
                    'fees_details_description' => $this->string(255)->null(),
                    'fees_details_amount' => $this->decimal(12, 2)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('prefect_type', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%prefect_type}}', [
                    'prefect_type_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('security_questions', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%security_questions}}', [
                    'security_questions_id' => $this->primaryKey(),
                    'security_question' => $this->string(100)->notNull(),
                    'modified_date' => $this->datetime()->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_leave_status', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_leave_status}}', [
                    'staff_leave_status_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('fees_payment_transaction', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%fees_payment_transaction}}', [
                    'fees_pay_tran_id' => $this->primaryKey(),
                    'fees_pay_tran_collect_id' => $this->integer(11)->notNull(),
                    'fees_pay_tran_stu_id' => $this->integer(11)->notNull(),
                    'fees_pay_tran_stream_id' => $this->integer(11)->notNull(),
                    'fees_pay_tran_sclass_id' => $this->integer(11)->notNull(),
                    'fees_pay_tran_section_id' => $this->integer(11)->notNull(),
                    'fees_pay_tran_mode' => $this->smallInteger(4)->notNull(),
                    'fees_pay_tran_cheque_no' => $this->integer(11)->notNull(),
                    'fees_pay_tran_cheque_date' => $this->date()->notNull(),
                    'fees_pay_tran_bank_id' => $this->integer(11)->notNull(),
                    'fees_pay_tran_bank_branch' => $this->string(50)->null(),
                    'fees_pay_tran_amount' => $this->decimal(12, 2)->notNull(),
                    'fees_pay_tran_date' => $this->date()->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('emp_address', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_address}}', [
                    'emp_address_id' => $this->primaryKey(),
                    'emp_cadd' => $this->string(255)->null(),
                    'emp_cadd_city' => $this->integer(11)->notNull(),
                    'emp_cadd_state' => $this->integer(11)->notNull(),
                    'emp_cadd_country' => $this->integer(11)->notNull(),
                    'emp_cadd_pincode' => $this->integer(11)->notNull(),
                    'emp_cadd_house_no' => $this->string(25)->null(),
                    'emp_cadd_phone_no' => $this->string(25)->null(),
                    'emp_padd' => $this->string(255)->null(),
                    'emp_padd_city' => $this->integer(11)->notNull(),
                    'emp_padd_state' => $this->integer(11)->notNull(),
                    'emp_padd_country' => $this->integer(11)->notNull(),
                    'emp_padd_pincode' => $this->integer(11)->notNull(),
                    'emp_padd_house_no' => $this->string(25)->null(),
                    'emp_padd_phone_no' => $this->string(25)->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_assignment_mark', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_assignment_mark}}', [
                    'stu_assignment_marks_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'grade_subject_id' => $this->integer(11)->notNull(),
                    'assignment_id' => $this->integer(11)->notNull(),
                    'year' => $this->date()->notNull(),
                    'grading_id' => $this->integer(11)->notNull(),
                    'marks' => $this->float(2)->notNull()->defaultValue(0),
                    'is_absent' => $this->integer(1)->notNull()->defaultValue(0),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_designation', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_designation}}', [
                    'par_designation_id' => $this->primaryKey(),
                    'par_designation_name' => $this->string(50)->notNull(),
                    'par_designation_alias' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_address', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_address}}', [
                    'par_address_id' => $this->primaryKey(),
                    'par_cadd' => $this->string(255)->null(),
                    'par_cadd_city' => $this->integer(11)->notNull(),
                    'par_cadd_state' => $this->integer(11)->notNull(),
                    'par_cadd_country' => $this->integer(11)->notNull(),
                    'par_cadd_pincode' => $this->integer(11)->notNull(),
                    'par_cadd_house_no' => $this->string(25)->null(),
                    'par_cadd_phone_no' => $this->string(25)->null(),
                    'par_padd' => $this->string(255)->null(),
                    'par_padd_city' => $this->integer(11)->notNull(),
                    'par_padd_state' => $this->integer(11)->notNull(),
                    'par_padd_country' => $this->integer(11)->notNull(),
                    'par_padd_pincode' => $this->integer(11)->notNull(),
                    'par_padd_house_no' => $this->string(25)->null(),
                    'par_padd_phone_no' => $this->string(25)->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('education_programmes', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%education_programmes}}', [
                    'id' => $this->primaryKey(),
                    'code' => $this->string(50)->notNull(),
                    'name' => $this->string(150)->notNull(),
                    'duration' => $this->integer(4)->null(),
                    'order' => $this->integer(3)->notNull(),
                    'visible' => $this->integer(1)->notNull()->defaultValue(1),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'modified' => $this->datetime()->null(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('assignment', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%assignment}}', [
                    'assignment_id' => $this->primaryKey(),
                    'grade_subject_id' => $this->integer(11)->notNull(),
                    'name' => $this->string(50)->notNull(),
                    'date' => $this->date()->notNull(),
                    'description' => $this->string(250)->null(),
                    'is_marks' => $this->smallInteger(1)->notNull()->defaultValue(0),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('emp_status', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_status}}', [
                    'emp_status_id' => $this->primaryKey(),
                    'emp_status_name' => $this->string(50)->notNull(),
                    'emp_status_description' => $this->string(100)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_past_service', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_past_service}}', [
                    'past_service_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'joined_date' => $this->date()->notNull(),
                    'depature_date' => $this->date()->notNull(),
                    'reason' => $this->string(250)->null(),
                    'complete_clearance' => $this->smallInteger(4)->notNull(),
                    'update_at' => $this->datetime()->null(),
                    'registration_no' => $this->string(50)->notNull(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('par_department', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%par_department}}', [
                    'par_department_id' => $this->primaryKey(),
                    'par_department_name' => $this->string(70)->notNull(),
                    'par_department_alias' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_category}}', [
                    'stu_category_id' => $this->primaryKey(),
                    'stu_category_name' => $this->string(50)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('achievement', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%achievement}}', [
                    'achievement_id' => $this->primaryKey(),
                    'description' => $this->text(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'activity' => $this->string(50)->notNull(),
                    'year' => $this->date()->notNull(),
                    'club_society_id' => $this->integer(11)->notNull(),
                    'is_academic' => $this->smallInteger(4)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('special_event_participation', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%special_event_participation}}', [
                    'special_event_participation_id' => $this->integer(11)->notNull(),
                    'special_event_id' => $this->integer(11)->notNull(),
                    'class_grade_id' => $this->integer(11)->notNull(),
                    'sport_category_id' => $this->integer(11)->notNull(),
                    'club_society_id' => $this->integer(11)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('school_calender', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%school_calender}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(50)->notNull(),
                    'start_date' => $this->date()->notNull(),
                    'end_date' => $this->date()->notNull(),
                    'school_days' => $this->integer(4)->notNull()->defaultValue(0),
                    'year_id' => $this->integer(4)->notNull()->defaultValue(0),
                    'event_type' => $this->integer(4)->notNull()->defaultValue(0),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(4)->notNull()->defaultValue(0),
                    'created_at' => $this->datetime()->null(),
                    'updated_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('stu_discipline', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_discipline}}', [
                    'stu_discipline_id' => $this->primaryKey(),
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'warning_level_id' => $this->integer(11)->notNull(),
                    'comment' => $this->string(50)->notNull(),
                    'is_informed_to_parent' => $this->integer(1)->notNull()->defaultValue(0),
                    'date' => $this->date()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('sport_sub', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%sport_sub}}', [
                    'sport_sub_id' => $this->primaryKey(),
                    'description' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('fees_schedule', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%fees_schedule}}', [
                    'fees_schedule_id' => $this->primaryKey(),
                    'fees_schedule_desc' => $this->string(100)->notNull(),
                    'fees_schedule_sclass_id' => $this->integer(11)->notNull(),
                    'fees_schedule_stream_id' => $this->integer(11)->notNull(),
                    'fees_schedule_section_id' => $this->integer(11)->notNull(),
                    'fees_schedule_total_amount' => $this->double(18, 2)->notNull()->defaultValue(0),
                    'fees_schedule_min_inst' => $this->double(18, 2)->notNull()->defaultValue(0),
                    'fees_schedule_start_date' => $this->date()->notNull(),
                    'fees_schedule_end_date' => $this->date()->notNull(),
                    'fees_schedule_due_date' => $this->date()->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('student_disability', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%student_disability}}', [
                    'stu_master_id' => $this->integer(11)->notNull(),
                    'allergies_medical_notes' => $this->text(),
                    'disability_info' => $this->text(),
                    'hearing_impairment' => $this->text(),
                    'visual_impairment' => $this->text(),
                    'speech_difficulties' => $this->text(),
                    'dyslexia' => $this->text(),
                    'physical_disabilities' => $this->text(),
                    'fits' => $this->text(),
                    'behaviour_difficulties' => $this->text(),
                    'other_info' => $this->text(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('staff_professional', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%staff_professional}}', [
                    'staff_professional_id' => $this->primaryKey(),
                    'emp_master_id' => $this->integer(11)->notNull(),
                    'professional_qual_id' => $this->integer(11)->notNull(),
                    'description' => $this->string(250)->null(),
                    'from_year' => $this->date()->notNull(),
                    'to_year' => $this->date()->notNull(),
                    'experience' => $this->string(50)->notNull(),
                    'responsibilities' => $this->string(50)->notNull(),
                    'update_at' => $this->datetime()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('emp_department', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%emp_department}}', [
                    'emp_department_id' => $this->primaryKey(),
                    'emp_department_name' => $this->string(70)->notNull(),
                    'emp_department_alias' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime()->null(),
                    'updated_by' => $this->integer(11)->notNull(),
                    'is_status' => $this->integer(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('stu_guardians', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%stu_guardians}}', [
                    'stu_guardian_id' => $this->primaryKey(),
                    'guardian_name' => $this->string(70)->notNull(),
                    'guardian_relation' => $this->string(70)->notNull(),
                    'guardian_mobile_no' => $this->string(12)->notNull(),
                    'guardian_phone_no' => $this->string(25)->notNull(),
                    'guardian_qualification' => $this->string(50)->null(),
                    'guardian_occupation' => $this->string(50)->null(),
                    'guardian_income' => $this->string(50)->null(),
                    'guardian_email' => $this->string(70)->notNull(),
                    'guardian_home_address' => $this->text(),
                    'guardian_office_address' => $this->text(),
                    'is_emg_contact' => $this->smallInteger(4)->notNull()->defaultValue(0),
                    'guardia_stu_master_id' => $this->integer(11)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(11)->notNull(),
                    'updated_at' => $this->datetime(),
                    'updated_by' => $this->integer(11),
                    'is_status' => $this->smallInteger(4)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }


        $this->createIndex('idx_UNIQUE_batch_name_2014_00', 'batches', 'batch_name', 1);
        $this->createIndex('idx_batch_course_id_2014_01', 'batches', 'batch_course_id', 0);
        $this->createIndex('idx_created_by_2014_02', 'batches', 'created_by', 0);
        $this->createIndex('idx_updated_by_2015_03', 'batches', 'updated_by', 0);
        $this->createIndex('idx_emp_master_id_208_04', 'staff_leave', 'emp_master_id', 0);
        $this->createIndex('idx_staff_leave_type_id_208_05', 'staff_leave', 'staff_leave_type_id', 0);
        $this->createIndex('idx_staff_leave_status_id_208_06', 'staff_leave', 'staff_leave_status_id', 0);
        $this->createIndex('idx_user_login_id_208_07', 'staff_leave', 'user_login_id', 0);
        $this->createIndex('idx_UNIQUE_national_holiday_name_2165_08', 'national_holidays', 'national_holiday_name', 1);
        $this->createIndex('idx_created_by_2165_09', 'national_holidays', 'created_by', 0);
        $this->createIndex('idx_updated_by_2165_10', 'national_holidays', 'updated_by', 0);
        $this->createIndex('idx_stu_master_id_2205_11', 'exam_admissions', 'stu_master_id', 0);
        $this->createIndex('idx_exam_id_2206_12', 'exam_admissions', 'exam_id', 0);
        $this->createIndex('idx_created_by_2206_13', 'exam_admissions', 'created_by', 0);
        $this->createIndex('idx_updated_by_2206_14', 'exam_admissions', 'updated_by', 0);
        $this->createIndex('idx_created_by_2256_15', 'stu_docs', 'created_by', 0);
        $this->createIndex('idx_stu_docs_stu_master_id_2257_16', 'stu_docs', 'stu_docs_stu_master_id', 0);
        $this->createIndex('idx_stu_docs_category_id_2257_17', 'stu_docs', 'stu_docs_category_id', 0);
        $this->createIndex('idx_created_by_2296_18', 'fees_schedule_detail', 'created_by', 0);
        $this->createIndex('idx_updated_by_2296_19', 'fees_schedule_detail', 'updated_by', 0);
        $this->createIndex('idx_fees_schedule_id_2296_20', 'fees_schedule_detail', 'fees_schedule_id', 0);
        $this->createIndex('idx_fees_schedule_itemid_2296_21', 'fees_schedule_detail', 'fees_schedule_itemid', 0);
        $this->createIndex('idx_UNIQUE_emp_master_id_2334_22', 'subject_teacher', 'emp_master_id', 1);
        $this->createIndex('idx_grade_subject_id_2335_23', 'subject_teacher', 'grade_subject_id', 0);
        $this->createIndex('idx_emp_master_id_2335_24', 'subject_teacher', 'emp_master_id', 0);
        $this->createIndex('idx_class_id_2335_25', 'subject_teacher', 'class_id', 0);
        $this->createIndex('idx_stu_master_id_239_26', 'stu_seminar', 'stu_master_id', 0);
        $this->createIndex('idx_seminar_id_239_27', 'stu_seminar', 'seminar_id', 0);
        $this->createIndex('idx_created_by_239_28', 'stu_seminar', 'created_by', 0);
        $this->createIndex('idx_updated_by_239_29', 'stu_seminar', 'updated_by', 0);
        $this->createIndex('idx_emp_master_id_243_30', 'staff_external_activity', 'emp_master_id', 0);
        $this->createIndex('idx_UNIQUE_stu_unique_id_2476_31', 'stu_info', 'stu_unique_id', 1);
        $this->createIndex('idx_UNIQUE_stu_email_id_2476_32', 'stu_info', 'stu_email_id', 1);
        $this->createIndex('idx_stu_info_stu_master_id_2476_33', 'stu_info', 'stu_info_stu_master_id', 0);
        $this->createIndex('idx_stu_master_id_2519_34', 'student_discipline', 'stu_master_id', 0);
        $this->createIndex('idx_warning_level_id_2519_35', 'student_discipline', 'warning_level_id', 0);
        $this->createIndex('idx_user_login_id_2519_36', 'student_discipline', 'user_login_id', 0);
        $this->createIndex('idx_UNIQUE_description_2599_37', 'staff_leave_type', 'description', 1);
        $this->createIndex('idx_UNIQUE_emp_master_id_2638_38', 'section_head', 'emp_master_id', 1);
        $this->createIndex('idx_emp_master_id_2638_39', 'section_head', 'emp_master_id', 0);
        $this->createIndex('idx_section_id_2638_40', 'section_head', 'section_id', 0);
        $this->createIndex('idx_UNIQUE_student_term_marks_id_2715_41', 'student_sub_term_mark', 'student_term_marks_id', 1);
        $this->createIndex('idx_student_term_marks_id_2715_42', 'student_sub_term_mark', 'student_term_marks_id', 0);
        $this->createIndex('idx_sub_term_id_2715_43', 'student_sub_term_mark', 'sub_term_id', 0);
        $this->createIndex('idx_grading_id_2715_44', 'student_sub_term_mark', 'grading_id', 0);
        $this->createIndex('idx_created_by_2715_45', 'student_sub_term_mark', 'created_by', 0);
        $this->createIndex('idx_updated_by_2715_46', 'student_sub_term_mark', 'updated_by', 0);
        $this->createIndex('idx_emp_master_id_2763_47', 'staff_sport', 'emp_master_id', 0);
        $this->createIndex('idx_position_id_2763_48', 'staff_sport', 'position_id', 0);
        $this->createIndex('idx_sport_category_id_2763_49', 'staff_sport', 'sport_category_id', 0);
        $this->createIndex('idx_UNIQUE_description_2799_50', 'race', 'description', 1);
        $this->createIndex('idx_emp_master_id_2873_51', 'staff_club_society', 'emp_master_id', 0);
        $this->createIndex('idx_club_society_id_2873_52', 'staff_club_society', 'club_society_id', 0);
        $this->createIndex('idx_position_id_2873_53', 'staff_club_society', 'position_id', 0);
        $this->createIndex('idx_UNIQUE_guardian_email_2927_54', 'stu_guardians', 'guardian_email', 1);
        $this->createIndex('idx_guardia_stu_master_id_2927_55', 'stu_guardians', 'guardia_stu_master_id', 0);
        $this->createIndex('idx_updated_by_2927_56', 'stu_guardians', 'updated_by', 0);
        $this->createIndex('idx_created_by_2927_57', 'stu_guardians', 'created_by', 0);
        $this->createIndex('idx_UNIQUE_emp_unique_id_298_58', 'emp_info', 'emp_unique_id', 1);
        $this->createIndex('idx_UNIQUE_emp_info_emp_master_id_298_59', 'emp_info', 'emp_info_emp_master_id', 1);
        $this->createIndex('idx_UNIQUE_emp_email_id_298_60', 'emp_info', 'emp_email_id', 1);
        $this->createIndex('idx_UNIQUE_emp_mobile_no_298_61', 'emp_info', 'emp_mobile_no', 1);
        $this->createIndex('idx_UNIQUE_emp_attendance_card_id_298_62', 'emp_info', 'emp_attendance_card_id', 1);
        $this->createIndex('idx_emp_info_emp_master_id_298_63', 'emp_info', 'emp_info_emp_master_id', 0);
        $this->createIndex('idx_UNIQUE_description_306_64', 'subject', 'description', 1);
        $this->createIndex('idx_UNIQUE_subject_code_306_65', 'subject', 'subject_code', 1);
        $this->createIndex('idx_UNIQUE_gov_subject_code_306_66', 'subject', 'gov_subject_code', 1);
        $this->createIndex('idx_UNIQUE_description_3097_67', 'professional_qualification', 'description', 1);
        $this->createIndex('idx_stu_master_id_3134_68', 'faith_life_rating', 'stu_master_id', 0);
        $this->createIndex('idx_faith_life_comment_id_3134_69', 'faith_life_rating', 'faith_life_comment_id', 0);
        $this->createIndex('idx_grading_id_3134_70', 'faith_life_rating', 'grading_id', 0);
        $this->createIndex('idx_UNIQUE_emp_designation_name_3173_71', 'emp_designation', 'emp_designation_name', 1);
        $this->createIndex('idx_UNIQUE_emp_designation_alias_3174_72', 'emp_designation', 'emp_designation_alias', 1);
        $this->createIndex('idx_created_by_3174_73', 'emp_designation', 'created_by', 0);
        $this->createIndex('idx_updated_by_3174_74', 'emp_designation', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_par_category_name_3254_75', 'par_category', 'par_category_name', 1);
        $this->createIndex('idx_UNIQUE_par_category_alias_3254_76', 'par_category', 'par_category_alias', 1);
        $this->createIndex('idx_updated_by_3254_77', 'par_category', 'updated_by', 0);
        $this->createIndex('idx_created_by_3254_78', 'par_category', 'created_by', 0);
        $this->createIndex('idx_UNIQUE_sclass_id_3293_79', 'section_assignment', 'sclass_id', 1);
        $this->createIndex('idx_stream_id_3293_80', 'section_assignment', 'stream_id', 0);
        $this->createIndex('idx_created_by_3294_81', 'section_assignment', 'created_by', 0);
        $this->createIndex('idx_updated_by_3294_82', 'section_assignment', 'updated_by', 0);
        $this->createIndex('idx_section_id_3294_83', 'section_assignment', 'section_id', 0);
        $this->createIndex('idx_stu_master_id_3294_84', 'section_assignment', 'stu_master_id', 0);
        $this->createIndex('idx_UNIQUE_section_name_3333_85', 'section', 'section_name', 1);
        $this->createIndex('idx_section_stream_id_3334_86', 'section', 'section_stream_id', 0);
        $this->createIndex('idx_created_by_3334_87', 'section', 'created_by', 0);
        $this->createIndex('idx_updated_by_3334_88', 'section', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_description_3409_89', 'religion', 'description', 1);
        $this->createIndex('idx_UNIQUE_class_grade_id_3481_90', 'class_grade', 'class_grade_id', 1);
        $this->createIndex('idx_UNIQUE_sclass_id_3481_91', 'class_grade', 'sclass_id', 1);
        $this->createIndex('idx_UNIQUE_description_3481_92', 'class_grade', 'description', 1);
        $this->createIndex('idx_grade_id_3481_93', 'class_grade', 'grade_id', 0);
        $this->createIndex('idx_sclass_id_3481_94', 'class_grade', 'sclass_id', 0);
        $this->createIndex('idx_created_by_3481_95', 'class_grade', 'created_by', 0);
        $this->createIndex('idx_updated_by_3482_96', 'class_grade', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_stu_master_id_3518_97', 'student_sport', 'stu_master_id', 1);
        $this->createIndex('idx_stu_master_id_3518_98', 'student_sport', 'stu_master_id', 0);
        $this->createIndex('idx_position_id_3518_99', 'student_sport', 'position_id', 0);
        $this->createIndex('idx_sport_category_id_3518_00', 'student_sport', 'sport_category_id', 0);
        $this->createIndex('idx_created_by_3562_01', 'par_docs', 'created_by', 0);
        $this->createIndex('idx_par_docs_par_master_id_3562_02', 'par_docs', 'par_docs_par_master_id', 0);
        $this->createIndex('idx_created_by_36_03', 'notice', 'created_by', 0);
        $this->createIndex('idx_updated_by_36_04', 'notice', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_fees_collect_name_3642_05', 'fees_collect_category', 'fees_collect_name', 1);
        $this->createIndex('idx_created_by_3643_06', 'fees_collect_category', 'created_by', 0);
        $this->createIndex('idx_updated_by_3643_07', 'fees_collect_category', 'updated_by', 0);
        $this->createIndex('idx_fees_collect_stream_id_3643_08', 'fees_collect_category', 'fees_collect_stream_id', 0);
        $this->createIndex('idx_stu_master_id_3682_09', 'student_leave', 'stu_master_id', 0);
        $this->createIndex('idx_UNIQUE_description_3722_10', 'term', 'description', 1);
        $this->createIndex('idx_created_by_3758_11', 'emp_docs', 'created_by', 0);
        $this->createIndex('idx_emp_docs_emp_master_id_3758_12', 'emp_docs', 'emp_docs_emp_master_id', 0);
        $this->createIndex('idx_emp_master_id_3794_13', 'staff_seminar', 'emp_master_id', 0);
        $this->createIndex('idx_seminar_id_3794_14', 'staff_seminar', 'seminar_id', 0);
        $this->createIndex('idx_UNIQUE_par_master_user_id_3832_15', 'par_master', 'par_master_user_id', 1);
        $this->createIndex('idx_UNIQUE_par_master_par_info_id_3833_16', 'par_master', 'par_master_par_info_id', 1);
        $this->createIndex('idx_par_master_department_id_3833_17', 'par_master', 'par_master_department_id', 0);
        $this->createIndex('idx_par_master_designation_id_3833_18', 'par_master', 'par_master_designation_id', 0);
        $this->createIndex('idx_par_master_category_id_3833_19', 'par_master', 'par_master_category_id', 0);
        $this->createIndex('idx_par_master_nationality_id_3833_20', 'par_master', 'par_master_nationality_id', 0);
        $this->createIndex('idx_par_master_par_address_id_3833_21', 'par_master', 'par_master_par_address_id', 0);
        $this->createIndex('idx_created_by_3833_22', 'par_master', 'created_by', 0);
        $this->createIndex('idx_updated_by_3833_23', 'par_master', 'updated_by', 0);
        $this->createIndex('idx_par_master_par_info_id_3833_24', 'par_master', 'par_master_par_info_id', 0);
        $this->createIndex('idx_par_master_user_id_3833_25', 'par_master', 'par_master_user_id', 0);
        $this->createIndex('idx_UNIQUE_stu_master_stu_info_id_3879_26', 'stu_master', 'stu_master_stu_info_id', 1);
        $this->createIndex('idx_UNIQUE_stu_master_user_id_388_27', 'stu_master', 'stu_master_user_id', 1);
        $this->createIndex('idx_stu_master_nationality_id_388_28', 'stu_master', 'stu_master_nationality_id', 0);
        $this->createIndex('idx_stu_master_category_id_388_29', 'stu_master', 'stu_master_category_id', 0);
        $this->createIndex('idx_stu_master_course_id_388_30', 'stu_master', 'stu_master_course_id', 0);
        $this->createIndex('idx_stu_master_batch_id_388_31', 'stu_master', 'stu_master_batch_id', 0);
        $this->createIndex('idx_stu_master_section_id_388_32', 'stu_master', 'stu_master_section_id', 0);
        $this->createIndex('idx_stu_master_stu_address_id_388_33', 'stu_master', 'stu_master_stu_address_id', 0);
        $this->createIndex('idx_created_by_388_34', 'stu_master', 'created_by', 0);
        $this->createIndex('idx_updated_by_388_35', 'stu_master', 'updated_by', 0);
        $this->createIndex('idx_stu_master_stu_info_id_388_36', 'stu_master', 'stu_master_stu_info_id', 0);
        $this->createIndex('idx_UNIQUE_stream_name_3957_37', 'streams', 'stream_name', 1);
        $this->createIndex('idx_stream_sclass_id_3957_38', 'streams', 'stream_sclass_id', 0);
        $this->createIndex('idx_created_by_3957_39', 'streams', 'created_by', 0);
        $this->createIndex('idx_updated_by_3957_40', 'streams', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_emp_category_name_3998_41', 'emp_category', 'emp_category_name', 1);
        $this->createIndex('idx_UNIQUE_emp_category_alias_3998_42', 'emp_category', 'emp_category_alias', 1);
        $this->createIndex('idx_updated_by_3998_43', 'emp_category', 'updated_by', 0);
        $this->createIndex('idx_created_by_3999_44', 'emp_category', 'created_by', 0);
        $this->createIndex('idx_UNIQUE_student_class_info_id_4034_45', 'student_class_info', 'student_class_info_id', 1);
        $this->createIndex('idx_UNIQUE_stu_master_id_4035_46', 'student_class_info', 'stu_master_id', 1);
        $this->createIndex('idx_class_grade_id_4035_47', 'student_class_info', 'class_grade_id', 0);
        $this->createIndex('idx_stu_master_id_4035_48', 'student_class_info', 'stu_master_id', 0);
        $this->createIndex('idx_stu_master_id_4079_49', 'student_suspend_details', 'stu_master_id', 0);
        $this->createIndex('idx_stu_discipline_id_4079_50', 'student_suspend_details', 'stu_discipline_id', 0);
        $this->createIndex('idx_created_by_4079_51', 'student_suspend_details', 'created_by', 0);
        $this->createIndex('idx_updated_by_4079_52', 'student_suspend_details', 'updated_by', 0);
        $this->createIndex('idx_created_by_4117_53', 'club_society', 'created_by', 0);
        $this->createIndex('idx_updated_by_4117_54', 'club_society', 'updated_by', 0);
        $this->createIndex('idx_subject_id_4155_55', 'exam_subject', 'subject_id', 0);
        $this->createIndex('idx_exam_id_4155_56', 'exam_subject', 'exam_id', 0);
        $this->createIndex('idx_created_by_4155_57', 'exam_subject', 'created_by', 0);
        $this->createIndex('idx_updated_by_4155_58', 'exam_subject', 'updated_by', 0);
        $this->createIndex('idx_publication_type_id_4192_59', 'publication', 'publication_type_id', 0);
        $this->createIndex('idx_special_event_participation_id_4232_60', 'special_event_attendance', 'special_event_participation_id', 0);
        $this->createIndex('idx_stu_master_id_4232_61', 'special_event_attendance', 'stu_master_id', 0);
        $this->createIndex('idx_UNIQUE_emp_master_id_427_62', 'staff_educational', 'emp_master_id', 1);
        $this->createIndex('idx_educational_qual_id_427_63', 'staff_educational', 'educational_qual_id', 0);
        $this->createIndex('idx_emp_master_id_427_64', 'staff_educational', 'emp_master_id', 0);
        $this->createIndex('idx_UNIQUE_stu_master_id_4308_65', 'stu_prefect', 'stu_master_id', 1);
        $this->createIndex('idx_created_by_4308_66', 'stu_prefect', 'created_by', 0);
        $this->createIndex('idx_updated_by_4308_67', 'stu_prefect', 'updated_by', 0);
        $this->createIndex('idx_prefect_type_id_4308_68', 'stu_prefect', 'prefect_type_id', 0);
        $this->createIndex('idx_UNIQUE_stu_status_name_4346_69', 'stu_status', 'stu_status_name', 1);
        $this->createIndex('idx_updated_by_4346_70', 'stu_status', 'updated_by', 0);
        $this->createIndex('idx_created_by_4346_71', 'stu_status', 'created_by', 0);
        $this->createIndex('idx_UNIQUE_name_4387_72', 'house', 'name', 1);
        $this->createIndex('idx_captain_4387_73', 'house', 'captain', 0);
        $this->createIndex('idx_vice_captain_4387_74', 'house', 'vice_captain', 0);
        $this->createIndex('idx_emp_master_id_4387_75', 'house', 'emp_master_id', 0);
        $this->createIndex('idx_UNIQUE_msg_details_4426_76', 'msg_of_day', 'msg_details', 1);
        $this->createIndex('idx_created_by_4426_77', 'msg_of_day', 'created_by', 0);
        $this->createIndex('idx_updated_by_4426_78', 'msg_of_day', 'updated_by', 0);
        $this->createIndex('idx_par_master_id_453_79', 'stu_parent', 'par_master_id', 0);
        $this->createIndex('idx_updated_by_453_80', 'stu_parent', 'updated_by', 0);
        $this->createIndex('idx_created_by_453_81', 'stu_parent', 'created_by', 0);
        $this->createIndex('idx_stu_master_id_453_82', 'stu_parent', 'stu_master_id', 0);
        $this->createIndex('idx_stu_par_relation_id_453_83', 'stu_parent', 'stu_par_relation_id', 0);
        $this->createIndex('idx_created_by_4567_84', 'entity_states', 'created_by', 0);
        $this->createIndex('idx_UNIQUE_par_unique_id_4628_85', 'par_info', 'par_unique_id', 1);
        $this->createIndex('idx_UNIQUE_par_info_par_master_id_4628_86', 'par_info', 'par_info_par_master_id', 1);
        $this->createIndex('idx_UNIQUE_par_email_id_4628_87', 'par_info', 'par_email_id', 1);
        $this->createIndex('idx_UNIQUE_par_mobile_no_4629_88', 'par_info', 'par_mobile_no', 1);
        $this->createIndex('idx_UNIQUE_par_attendance_card_id_4629_89', 'par_info', 'par_attendance_card_id', 1);
        $this->createIndex('idx_par_info_par_master_id_4629_90', 'par_info', 'par_info_par_master_id', 0);
        $this->createIndex('idx_faith_life_category_id_4667_91', 'faith_life_comment', 'faith_life_category_id', 0);
        $this->createIndex('idx_participant_category_id_4746_92', 'special_events', 'participant_category_id', 0);
        $this->createIndex('idx_term_id_4783_93', 'sub_term', 'term_id', 0);
        $this->createIndex('idx_stu_master_id_4819_94', 'past_student', 'stu_master_id', 0);
        $this->createIndex('idx_UNIQUE_emp_master_id_49_95', 'master_in_charge', 'emp_master_id', 1);
        $this->createIndex('idx_emp_master_id_49_96', 'master_in_charge', 'emp_master_id', 0);
        $this->createIndex('idx_club_society_id_49_97', 'master_in_charge', 'club_society_id', 0);
        $this->createIndex('idx_sport_category_id_49_98', 'master_in_charge', 'sport_category_id', 0);
        $this->createIndex('idx_house_id_49_99', 'master_in_charge', 'house_id', 0);
        $this->createIndex('idx_UNIQUE_description_5021_00', 'stream', 'description', 1);
        $this->createIndex('idx_class_grade_id_5064_01', 'marking_flag', 'class_grade_id', 0);
        $this->createIndex('idx_term_id_5064_02', 'marking_flag', 'term_id', 0);
        $this->createIndex('idx_grade_id_5064_03', 'marking_flag', 'grade_id', 0);
        $this->createIndex('idx_created_by_5064_04', 'marking_flag', 'created_by', 0);
        $this->createIndex('idx_updated_by_5064_05', 'marking_flag', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_stu_master_id_51_06', 'student_scholarship', 'stu_master_id', 1);
        $this->createIndex('idx_scholarship_id_51_07', 'student_scholarship', 'scholarship_id', 0);
        $this->createIndex('idx_stu_master_id_51_08', 'student_scholarship', 'stu_master_id', 0);
        $this->createIndex('idx_UNIQUE_par_status_name_5173_09', 'par_status', 'par_status_name', 1);
        $this->createIndex('idx_created_by_5173_10', 'par_status', 'created_by', 0);
        $this->createIndex('idx_updated_by_5173_11', 'par_status', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_stu_master_id_5214_12', 'student_club_society', 'stu_master_id', 1);
        $this->createIndex('idx_stu_master_id_5214_13', 'student_club_society', 'stu_master_id', 0);
        $this->createIndex('idx_position_id_5215_14', 'student_club_society', 'position_id', 0);
        $this->createIndex('idx_club_society_id_5215_15', 'student_club_society', 'club_society_id', 0);
        $this->createIndex('idx_updated_by_5268_16', 'fees_category_details', 'updated_by', 0);
        $this->createIndex('idx_created_by_5268_17', 'fees_category_details', 'created_by', 0);
        $this->createIndex('idx_fees_details_category_id_5268_18', 'fees_category_details', 'fees_details_category_id', 0);
        $this->createIndex('idx_UNIQUE_description_5303_19', 'prefect_type', 'description', 1);
        $this->createIndex('idx_updated_by_5417_20', 'fees_payment_transaction', 'updated_by', 0);
        $this->createIndex('idx_created_by_5417_21', 'fees_payment_transaction', 'created_by', 0);
        $this->createIndex('idx_fees_pay_tran_bank_id_5417_22', 'fees_payment_transaction', 'fees_pay_tran_bank_id', 0);
        $this->createIndex('idx_fees_pay_tran_collect_id_5417_23', 'fees_payment_transaction', 'fees_pay_tran_collect_id', 0);
        $this->createIndex('idx_fees_pay_tran_stu_id_5417_24', 'fees_payment_transaction', 'fees_pay_tran_stu_id', 0);
        $this->createIndex('idx_fees_pay_tran_stream_id_5417_25', 'fees_payment_transaction', 'fees_pay_tran_stream_id', 0);
        $this->createIndex('idx_fees_pay_tran_sclass_id_5417_26', 'fees_payment_transaction', 'fees_pay_tran_sclass_id', 0);
        $this->createIndex('idx_fees_pay_tran_section_id_5417_27', 'fees_payment_transaction', 'fees_pay_tran_section_id', 0);
        $this->createIndex('idx_emp_cadd_city_5458_28', 'emp_address', 'emp_cadd_city', 0);
        $this->createIndex('idx_emp_cadd_state_5458_29', 'emp_address', 'emp_cadd_state', 0);
        $this->createIndex('idx_emp_cadd_country_5459_30', 'emp_address', 'emp_cadd_country', 0);
        $this->createIndex('idx_emp_padd_city_5459_31', 'emp_address', 'emp_padd_city', 0);
        $this->createIndex('idx_emp_padd_state_5459_32', 'emp_address', 'emp_padd_state', 0);
        $this->createIndex('idx_emp_padd_country_5459_33', 'emp_address', 'emp_padd_country', 0);
        $this->createIndex('idx_grading_id_5499_34', 'stu_assignment_mark', 'grading_id', 0);
        $this->createIndex('idx_assignment_id_5499_35', 'stu_assignment_mark', 'assignment_id', 0);
        $this->createIndex('idx_grade_subject_id_5499_36', 'stu_assignment_mark', 'grade_subject_id', 0);
        $this->createIndex('idx_stu_master_id_5499_37', 'stu_assignment_mark', 'stu_master_id', 0);
        $this->createIndex('idx_created_by_5499_38', 'stu_assignment_mark', 'created_by', 0);
        $this->createIndex('idx_updated_by_5499_39', 'stu_assignment_mark', 'updated_by', 0);
        $this->createIndex('idx_UNIQUE_par_designation_name_5537_40', 'par_designation', 'par_designation_name', 1);
        $this->createIndex('idx_UNIQUE_par_designation_alias_5537_41', 'par_designation', 'par_designation_alias', 1);
        $this->createIndex('idx_created_by_5537_42', 'par_designation', 'created_by', 0);
        $this->createIndex('idx_updated_by_5537_43', 'par_designation', 'updated_by', 0);
        $this->createIndex('idx_par_cadd_city_5586_44', 'par_address', 'par_cadd_city', 0);
        $this->createIndex('idx_par_cadd_state_5586_45', 'par_address', 'par_cadd_state', 0);
        $this->createIndex('idx_par_cadd_country_5586_46', 'par_address', 'par_cadd_country', 0);
        $this->createIndex('idx_par_padd_city_5586_47', 'par_address', 'par_padd_city', 0);
        $this->createIndex('idx_par_padd_state_5586_48', 'par_address', 'par_padd_state', 0);
        $this->createIndex('idx_par_padd_country_5586_49', 'par_address', 'par_padd_country', 0);
        $this->createIndex('idx_grade_subject_id_5663_50', 'assignment', 'grade_subject_id', 0);
        $this->createIndex('idx_UNIQUE_emp_status_name_5713_51', 'emp_status', 'emp_status_name', 1);
        $this->createIndex('idx_created_by_5713_52', 'emp_status', 'created_by', 0);
        $this->createIndex('idx_updated_by_5713_53', 'emp_status', 'updated_by', 0);
        $this->createIndex('idx_emp_master_id_5757_54', 'staff_past_service', 'emp_master_id', 0);
        $this->createIndex('idx_UNIQUE_par_department_name_5796_55', 'par_department', 'par_department_name', 1);
        $this->createIndex('idx_UNIQUE_par_department_alias_5796_56', 'par_department', 'par_department_alias', 1);
        $this->createIndex('idx_updated_by_5796_57', 'par_department', 'updated_by', 0);
        $this->createIndex('idx_created_by_5796_58', 'par_department', 'created_by', 0);
        $this->createIndex('idx_updated_by_5835_59', 'stu_category', 'updated_by', 0);
        $this->createIndex('idx_created_by_5835_60', 'stu_category', 'created_by', 0);
        $this->createIndex('idx_stu_master_id_5877_61', 'achievement', 'stu_master_id', 0);
        $this->createIndex('idx_club_society_id_5878_62', 'achievement', 'club_society_id', 0);
        $this->createIndex('idx_created_by_5878_63', 'achievement', 'created_by', 0);
        $this->createIndex('idx_updated_by_5878_64', 'achievement', 'updated_by', 0);
        $this->createIndex('idx_special_event_id_5924_65', 'special_event_participation', 'special_event_id', 0);
        $this->createIndex('idx_class_grade_id_5924_66', 'special_event_participation', 'class_grade_id', 0);
        $this->createIndex('idx_sport_category_id_5924_67', 'special_event_participation', 'sport_category_id', 0);
        $this->createIndex('idx_club_society_id_5924_68', 'special_event_participation', 'club_society_id', 0);
        $this->createIndex('idx_stu_master_id_6008_69', 'stu_discipline', 'stu_master_id', 0);
        $this->createIndex('idx_warning_level_id_6008_70', 'stu_discipline', 'warning_level_id', 0);
        $this->createIndex('idx_created_by_6008_71', 'stu_discipline', 'created_by', 0);
        $this->createIndex('idx_updated_by_6008_72', 'stu_discipline', 'updated_by', 0);
        $this->createIndex('idx_created_by_6088_73', 'fees_schedule', 'created_by', 0);
        $this->createIndex('idx_updated_by_6089_74', 'fees_schedule', 'updated_by', 0);
        $this->createIndex('idx_fees_schedule_stream_id_6089_75', 'fees_schedule', 'fees_schedule_stream_id', 0);
        $this->createIndex('idx_fees_schedule_sclass_id_6089_76', 'fees_schedule', 'fees_schedule_sclass_id', 0);
        $this->createIndex('idx_fees_schedule_section_id_6089_77', 'fees_schedule', 'fees_schedule_section_id', 0);
        $this->createIndex('idx_stu_master_id_6129_78', 'student_disability', 'stu_master_id', 0);
        $this->createIndex('idx_UNIQUE_emp_master_id_6168_79', 'staff_professional', 'emp_master_id', 1);
        $this->createIndex('idx_professional_qual_id_6168_80', 'staff_professional', 'professional_qual_id', 0);
        $this->createIndex('idx_emp_master_id_6168_81', 'staff_professional', 'emp_master_id', 0);
        $this->createIndex('idx_UNIQUE_emp_department_name_6208_82', 'emp_department', 'emp_department_name', 1);
        $this->createIndex('idx_UNIQUE_emp_department_alias_6208_83', 'emp_department', 'emp_department_alias', 1);
        $this->createIndex('idx_updated_by_6208_84', 'emp_department', 'updated_by', 0);
        $this->createIndex('idx_created_by_6208_85', 'emp_department', 'created_by', 0);

        $this->execute('SET foreign_key_checks = 0');
        $this->execute('SET foreign_key_checks = 1;');

        $this->execute('SET foreign_key_checks = 0');
        $this->insert('{{%grades}}', ['id' => '1', 'code' => 'A', 'name' => 'A', 'order' => '1', 'visible' => '0', 'program_id' => '4', 'created_by' => 1, 'created_at' => '', 'updated_by' => '1', 'updated_at' => '2016-02-20 14:57:20']);
        $this->insert('{{%relationships}}', ['id' => '1', 'name' => 'Father']);
        $this->insert('{{%relationships}}', ['id' => '2', 'name' => 'Mother']);
        $this->insert('{{%relationships}}', ['id' => '3', 'name' => 'Brother']);
        $this->insert('{{%relationships}}', ['id' => '4', 'name' => 'Guardian']);
        $this->insert('{{%relationships}}', ['id' => '5', 'name' => 'Sponsor']);
        $this->insert('{{%relationships}}', ['id' => '6', 'name' => 'None']);
        $this->insert('{{%national_holidays}}', ['national_holiday_id' => '1', 'national_holiday_name' => 'Jamhuri Day', 'national_holiday_date' => '2015-12-12', 'national_holiday_remarks' => '', 'created_at' => '2015-05-27 15:24:10', 'created_by' => '1', 'updated_at' => '2015-09-05 11:43:23', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%national_holidays}}', ['national_holiday_id' => '2', 'national_holiday_name' => 'Mashujaa Day', 'national_holiday_date' => '2015-10-20', 'national_holiday_remarks' => '', 'created_at' => '2015-05-27 15:24:26', 'created_by' => '1', 'updated_at' => '2015-09-05 11:43:01', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%national_holidays}}', ['national_holiday_id' => '3', 'national_holiday_name' => 'Labour Day', 'national_holiday_date' => '2015-05-01', 'national_holiday_remarks' => '', 'created_at' => '2015-05-27 15:24:47', 'created_by' => '1', 'updated_at' => '2015-09-05 11:42:42', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%national_holidays}}', ['national_holiday_id' => '4', 'national_holiday_name' => 'Madaraka Day', 'national_holiday_date' => '2015-06-01', 'national_holiday_remarks' => '', 'created_at' => '2015-05-27 15:25:02', 'created_by' => '1', 'updated_at' => '2015-09-05 11:42:18', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%national_holidays}}', ['national_holiday_id' => '5', 'national_holiday_name' => 'New Year Day', 'national_holiday_date' => '2015-01-01', 'national_holiday_remarks' => '', 'created_at' => '2015-05-27 15:25:15', 'created_by' => '1', 'updated_at' => '2015-09-05 11:41:57', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%parameter}}', ['id' => '1', 'name' => 'Allow Student to Register', 'value' => '1', 'value2' => '', 'narration' => 'Allow Student to Register 
0-Students can register
1-Students cannot register']);
        $this->insert('{{%parameter}}', ['id' => '2', 'name' => 'Allow Parents to Register', 'value' => '1', 'value2' => '', 'narration' => 'Allow Parents to Register 
0-Parents can register
1-Parents cannot register']);
        $this->insert('{{%parameter}}', ['id' => '3', 'name' => 'Require Birth Certificate', 'value' => '1', 'value2' => '', 'narration' => 'Require Birth Certificate']);
        $this->insert('{{%parameter}}', ['id' => '4', 'name' => 'Require ID/Passport NO', 'value' => '0', 'value2' => '', 'narration' => 'Require ID/Passport NO']);
        $this->insert('{{%parameter}}', ['id' => '5', 'name' => 'Require Leaving Certificate', 'value' => '0', 'value2' => '', 'narration' => 'Require Leaving Certificate']);
        $this->insert('{{%parameter}}', ['id' => '6', 'name' => 'Allow Parents to Register', 'value' => '1', 'value2' => '', 'narration' => 'Allow Parents to Register 
0-Parents can register
1-Parents cannot register']);
        $this->insert('{{%parameter}}', ['id' => '7', 'name' => 'Allow Parents to Register', 'value' => '1', 'value2' => '', 'narration' => 'Allow Parents to Register 
0-Parents can register
1-Parents cannot register']);
        $this->insert('{{%parameter}}', ['id' => '8', 'name' => '', 'value' => '', 'value2' => '', 'narration' => '']);
        $this->insert('{{%parameter}}', ['id' => '9', 'name' => '', 'value' => '', 'value2' => '', 'narration' => '']);
        $this->insert('{{%parameter}}', ['id' => '10', 'name' => '', 'value' => '', 'value2' => '', 'narration' => '']);
        $this->insert('{{%subject}}', ['subject_id' => '1', 'description' => 'English', 'created_by' => 1, 'created_at' => '', 'updated_by' => '1', 'updated_at' => '2016-02-20 13:23:01', 'subject_code' => 'ENG', 'gov_subject_code' => '101', 'program_id' => '2']);
        $this->insert('{{%subject}}', ['subject_id' => '2', 'description' => 'Swahili', 'created_by' => 1, 'created_at' => '', 'updated_by' => '1', 'updated_at' => '2016-02-20 13:23:01', 'subject_code' => 'SWA', 'gov_subject_code' => '102', 'program_id' => '2']);
        $this->insert('{{%subject}}', ['subject_id' => '3', 'description' => 'Maths', 'created_by' => 1, 'created_at' => '', 'updated_by' => '1', 'updated_at' => '2016-02-20 13:23:01', 'subject_code' => 'MAT', 'gov_subject_code' => '103', 'program_id' => '2']);
        $this->insert('{{%subject}}', ['subject_id' => '4', 'description' => 'Science', 'created_by' => 1, 'created_at' => '', 'updated_by' => '1', 'updated_at' => '2016-02-20 13:23:01', 'subject_code' => 'SCI', 'gov_subject_code' => '104', 'program_id' => '2']);
        $this->insert('{{%subject}}', ['subject_id' => '5', 'description' => 'Social Studies', 'created_by' => 1, 'created_at' => '', 'updated_by' => '1', 'updated_at' => '2016-02-20 13:23:01', 'subject_code' => 'SST', 'gov_subject_code' => '105', 'program_id' => '3']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '1', 'emp_designation_name' => 'Head of Department', 'emp_designation_alias' => 'HOD', 'created_at' => '2015-05-27 15:45:22', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '2', 'emp_designation_name' => 'Assistant Professor', 'emp_designation_alias' => 'Assi.Prof.', 'created_at' => '2015-05-27 15:45:36', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '3', 'emp_designation_name' => 'Associate Professor', 'emp_designation_alias' => 'Asso.Prof.', 'created_at' => '2015-05-27 15:45:45', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '4', 'emp_designation_name' => 'Peon', 'emp_designation_alias' => 'peon', 'created_at' => '2015-05-27 15:45:56', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '5', 'emp_designation_name' => 'Librarian', 'emp_designation_alias' => 'Librarian', 'created_at' => '2015-05-27 15:46:09', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '6', 'emp_designation_name' => 'Admin', 'emp_designation_alias' => 'Admin', 'created_at' => '2015-05-27 15:46:22', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_designation}}', ['emp_designation_id' => '7', 'emp_designation_name' => 'Senior Clerk', 'emp_designation_alias' => 'Sr.Clerk', 'created_at' => '2015-05-27 15:46:34', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%par_category}}', ['par_category_id' => '1', 'par_category_name' => 'Not Applicable', 'par_category_alias' => 'NA', 'created_at' => '2015-09-12 17:53:20', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%religion}}', ['religion_id' => '1', 'description' => 'Christian', 'update_at' => '']);
        $this->insert('{{%notice}}', ['notice_id' => '1', 'notice_title' => 'Next Week Summer Exam ', 'notice_description' => 'summer Exam will be conducted on Next week. All The Best', 'notice_user_type' => 'S', 'notice_date' => '2015-06-01', 'notice_file_path' => '', 'created_at' => '2015-05-27 15:26:29', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%notice}}', ['notice_id' => '2', 'notice_title' => 'Monthly Report', 'notice_description' => 'All Employee have to submit their report on month end.', 'notice_user_type' => 'E', 'notice_date' => '2015-06-05', 'notice_file_path' => '', 'created_at' => '2015-05-27 15:27:23', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%notice}}', ['notice_id' => '3', 'notice_title' => 'Summer Vacation', 'notice_description' => 'Summer Vacation starts from June to  2nd week of July.', 'notice_user_type' => '0', 'notice_date' => '2015-05-30', 'notice_file_path' => '', 'created_at' => '2015-05-27 15:28:37', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%notice}}', ['notice_id' => '4', 'notice_title' => 'Attendance Report', 'notice_description' => 'All Employees collect their class wise  attendance report', 'notice_user_type' => 'E', 'notice_date' => '2015-05-29', 'notice_file_path' => '', 'created_at' => '2015-05-27 15:30:35', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%notice}}', ['notice_id' => '5', 'notice_title' => 'Exam From Fill', 'notice_description' => 'All Students come and fill their exam forms', 'notice_user_type' => 'S', 'notice_date' => '2015-05-25', 'notice_file_path' => '', 'created_at' => '2015-05-27 15:33:07', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%notice}}', ['notice_id' => '6', 'notice_title' => 'Blah', 'notice_description' => '\"S\" => \'Student\', ', 'notice_user_type' => 'P', 'notice_date' => '2015-09-01', 'notice_file_path' => '', 'created_at' => '2015-09-06 10:26:11', 'created_by' => '1', 'updated_at' => '2015-09-06 10:27:33', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%emp_category}}', ['emp_category_id' => '1', 'emp_category_name' => 'Regular', 'emp_category_alias' => 'regular', 'created_at' => '2015-05-27 15:46:59', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_category}}', ['emp_category_id' => '2', 'emp_category_name' => 'Rejoin', 'emp_category_alias' => 'rejoin', 'created_at' => '2015-05-27 15:47:11', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_category}}', ['emp_category_id' => '3', 'emp_category_name' => 'Resign', 'emp_category_alias' => 'resign', 'created_at' => '2015-05-27 15:47:18', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_category}}', ['emp_category_id' => '4', 'emp_category_name' => 'Transfer', 'emp_category_alias' => 'transfer', 'created_at' => '2015-05-27 15:47:25', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%stu_status}}', ['stu_status_id' => '1', 'stu_status_name' => 'Rejoin', 'stu_status_description' => 'Rejoin', 'created_at' => '2015-05-27 15:43:22', 'created_by' => '1', 'updated_at' => '2015-09-12 15:56:40', 'updated_by' => '1', 'is_status' => '2']);
        $this->insert('{{%stu_status}}', ['stu_status_id' => '2', 'stu_status_name' => 'Non-Sponsered', 'stu_status_description' => 'Non-Sponsered', 'created_at' => '2015-05-27 15:44:12', 'created_by' => '1', 'updated_at' => '2015-09-12 15:56:35', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%stu_status}}', ['stu_status_id' => '3', 'stu_status_name' => 'Sponsered', 'stu_status_description' => 'Sponsered', 'created_at' => '2015-05-27 15:44:37', 'created_by' => '1', 'updated_at' => '2015-09-12 15:56:17', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%house}}', ['house_id' => '1', 'name' => 'Longonot', 'colour' => '#ffff00', 'description' => 'Longonot House', 'captain' => 0, 'capacity' => '120', 'vice_captain' => 0, 'emp_master_id' => 0, 'update_at' => '2015-10-05 09:52:29']);
        $this->insert('{{%entity_states}}', ['state_id' => '0', 'state_type' => 'S', 'state_description' => 'Active', 'created_at' => '2015-09-17 10:26:55', 'created_by' => '1']);
        $this->insert('{{%entity_states}}', ['state_type' => 'S', 'state_description' => 'Approved', 'created_at' => '2015-09-17 10:26:54', 'created_by' => '1']);
        $this->insert('{{%entity_states}}', ['state_type' => 'S', 'state_description' => 'Deleted', 'created_at' => '2015-09-17 10:26:55', 'created_by' => '1']);
        $this->insert('{{%entity_states}}', ['state_type' => 'S', 'state_description' => 'Pending: Awaiting Approval', 'created_at' => '2015-09-17 10:26:55', 'created_by' => '1']);
        $this->insert('{{%entity_states}}', ['state_type' => 'S', 'state_description' => 'Queued: Awaiting Approval', 'created_at' => '2015-09-17 10:26:55', 'created_by' => '1']);
        $this->insert('{{%school_years}}', ['id' => '1', 'name' => 'Year 2016', 'start_date' => '2016-03-01', 'start_year' => '', 'end_date' => '2016-11-30', 'end_year' => '', 'school_days' => '16', 'order' => '1', 'visible' => '1', 'updated_by' => '1', 'created_by' => '1', 'created_at' => '2016-03-02 18:13:44', 'updated_at' => '2016-03-02 18:13:44']);
        $this->insert('{{%par_status}}', ['par_status_id' => '1', 'par_status_name' => 'Register', 'par_status_description' => 'Pending Approval', 'created_at' => '2015-09-17 10:31:14', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%par_status}}', ['par_status_id' => '2', 'par_status_name' => 'Pending Approval', 'par_status_description' => 'Approval in Progress', 'created_at' => '2015-09-17 10:31:14', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%par_status}}', ['par_status_id' => '3', 'par_status_name' => 'Approval', 'par_status_description' => 'Approved', 'created_at' => '2015-09-17 10:31:14', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%par_status}}', ['par_status_id' => '4', 'par_status_name' => 'Denied', 'par_status_description' => 'Rejected', 'created_at' => '2015-09-17 10:31:14', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%education_programmes}}', ['id' => '2', 'code' => 'CrÃ¨che', 'name' => 'CrÃ¨che', 'duration' => '1', 'order' => '1', 'visible' => '1', 'updated_by' => '1', 'created_by' => '1', 'modified' => '', 'created_at' => '2016-02-10 19:06:23', 'updated_at' => '2016-02-11 20:24:52']);
        $this->insert('{{%education_programmes}}', ['id' => '3', 'code' => 'FS', 'name' => 'FS', 'duration' => '2', 'order' => '2', 'visible' => '1', 'updated_by' => '1', 'created_by' => '1', 'modified' => '', 'created_at' => '2016-02-10 19:06:39', 'updated_at' => '2016-02-11 20:25:30']);
        $this->insert('{{%education_programmes}}', ['id' => '4', 'code' => 'GSCE', 'name' => 'GSCE', 'duration' => '8', 'order' => '1', 'visible' => '1', 'updated_by' => '1', 'created_by' => '1', 'modified' => '', 'created_at' => '2016-02-10 19:07:08', 'updated_at' => '2016-02-11 20:32:36']);
        $this->insert('{{%par_department}}', ['par_department_id' => '1', 'par_department_name' => 'Not Applicable', 'par_department_alias' => 'NA', 'created_at' => '2015-09-12 17:48:04', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%stu_category}}', ['stu_category_id' => '1', 'stu_category_name' => 'Normal', 'created_at' => '2015-05-27 15:45:26', 'created_by' => '1', 'updated_at' => '2015-09-12 15:26:43', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%stu_category}}', ['stu_category_id' => '2', 'stu_category_name' => 'Morning', 'created_at' => '2015-05-27 15:45:32', 'created_by' => '1', 'updated_at' => '2015-09-12 15:26:34', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%stu_category}}', ['stu_category_id' => '3', 'stu_category_name' => 'Evenining', 'created_at' => '2015-05-27 15:45:41', 'created_by' => '1', 'updated_at' => '2015-09-12 15:26:25', 'updated_by' => '1', 'is_status' => '0']);
        $this->insert('{{%school_calender}}', ['id' => '1', 'name' => 'Term 1', 'start_date' => '2016-01-04', 'end_date' => '2016-04-07', 'school_days' => '425', 'year_id' => '1', 'event_type' => '1', 'updated_by' => '1', 'created_by' => '1', 'is_status' => '1', 'created_at' => '2016-03-02 19:24:49', 'updated_at' => '2016-03-02 19:24:49']);
        $this->insert('{{%fees_schedule}}', ['fees_schedule_id' => '1', 'fees_schedule_desc' => 'Tuition Fees', 'fees_schedule_sclass_id' => '1', 'fees_schedule_stream_id' => '1', 'fees_schedule_section_id' => '1', 'fees_schedule_total_amount' => '0.00', 'fees_schedule_min_inst' => 0, 'fees_schedule_start_date' => '2015-10-05', 'fees_schedule_end_date' => '2015-10-05', 'fees_schedule_due_date' => '2015-10-05', 'created_at' => '2015-10-05 15:54:49', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%fees_schedule}}', ['fees_schedule_id' => '2', 'fees_schedule_desc' => 'First Term Fees', 'fees_schedule_sclass_id' => '1', 'fees_schedule_stream_id' => '1', 'fees_schedule_section_id' => '9', 'fees_schedule_total_amount' => '0.00', 'fees_schedule_min_inst' => 0, 'fees_schedule_start_date' => '2015-10-01', 'fees_schedule_end_date' => '2015-10-01', 'fees_schedule_due_date' => '2015-10-01', 'created_at' => '2015-10-05 15:55:30', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_department}}', ['emp_department_id' => '1', 'emp_department_name' => 'MCA Department', 'emp_department_alias' => 'MCA Dept', 'created_at' => '2015-05-27 15:43:24', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_department}}', ['emp_department_id' => '2', 'emp_department_name' => 'BCA Department', 'emp_department_alias' => 'BCA Dept', 'created_at' => '2015-05-27 15:43:41', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_department}}', ['emp_department_id' => '3', 'emp_department_name' => 'MBA Department', 'emp_department_alias' => 'MBA Dept', 'created_at' => '2015-05-27 15:43:49', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_department}}', ['emp_department_id' => '4', 'emp_department_name' => 'B.Sc.IT Department', 'emp_department_alias' => 'B.Sc.IT ', 'created_at' => '2015-05-27 15:44:31', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->insert('{{%emp_department}}', ['emp_department_id' => '5', 'emp_department_name' => 'M.Sc.IT Department', 'emp_department_alias' => 'M.Sc.IT', 'created_at' => '2015-05-27 15:44:54', 'created_by' => '1', 'updated_at' => '', 'updated_by' => 1, 'is_status' => '0']);
        $this->execute('SET foreign_key_checks = 1;');
    }

    public function down() {
        echo "m160705_093743_regions cannot be reverted.\n";

        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS grades');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS relationships');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS batches');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_leave');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS civil_status');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS national_holidays');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS exam_admissions');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_docs');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS fees_schedule_detail');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS subject_teacher');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_seminar');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_external_activity');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_info');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_discipline');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS warning_level');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_leave_type');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS section_head');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS parameter');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_sub_term_mark');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_sport');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS race');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS faith_life_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_club_society');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_guardians');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_info');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS publication_type');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS subject');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS professional_qualification');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS faith_life_rating');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_designation');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS grading');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS section_assignment');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS section');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS participant_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS religion');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS class_grade');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_sport');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_docs');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS notice');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS fees_collect_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_leave');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS term');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_docs');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_seminar');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_master');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_master');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS school_calendar');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS streams');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_class_info');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_suspend_details');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS club_society');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS exam_subject');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS publication');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS special_event_attendance');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_educational');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_prefect');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_status');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS house');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS msg_of_day');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS appointment_nature');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_parent');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS entity_states');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_info');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS faith_life_comment');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS class_subjects');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS special_events');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS sub_term');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS past_student');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS school_years');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS master_in_charge');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS donation_type');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS assessment_items');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stream');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS marking_flag');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_scholarship');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS merit_award');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_status');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_club_society');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS fees_category_details');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS prefect_type');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS security_questions');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_leave_status');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS fees_payment_transaction');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_address');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_assignment_mark');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_designation');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_address');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS education_programmes');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS assignment');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_status');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_past_service');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS par_department');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_category');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS achievement');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS special_event_participation');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS school_calender');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS stu_discipline');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS sport_sub');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS fees_schedule');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS student_disability');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS staff_professional');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS emp_department');
        $this->execute('SET foreign_key_checks = 1;');

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
