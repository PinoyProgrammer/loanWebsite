<?php

use yii\db\Migration;

class m170907_180411_members_list extends Migration {

    public function safeUp() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        /* MYSQL */
        if (!in_array('{{%members}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%members}}', [
                    'member_id' => $this->primaryKey(),
                    'user_id' => $this->integer()->notNull(),
                    'surname_name' => $this->string(20)->notNull(),
                    'other_name' => $this->string(64)->notNull(),
                    'member_type' => $this->integer()->notNull(),
                    'date_of_birth' => $this->date(),
                    'mobile' => $this->string(20)->notNull(),
                    'use_mobile_or_bank' => $this->integer()->notNull(),
                    'date_joined' => $this->date()->notNull(),
                    'kin_name' => $this->string(64)->notNull(),
                    'relationship' => $this->string(64)->notNull(),
                    'kin_address' => $this->string(64)->notNull(),
                    'kin_telephone' => $this->string(64)->notNull(),
                    'beneficiary_no' => $this->string(64)->notNull(),
                    'beneficiary_name' => $this->string(64)->notNull(),
                    'bank_name' => $this->string(64)->notNull(),
                    'bank_branch' => $this->string(64)->notNull(),
                    'bank_account_name' => $this->string(64)->notNull(),
                    'bank_account_no' => $this->string(64)->notNull(),
                    'bank_swift_code' => $this->string(64)->notNull(),
                    'id_number' => $this->string(64)->notNull(),
                    'id_type' => $this->integer()->notNull(),
                    'preffered_provider' => $this->integer()->notNull(),
                    'nominee_no' => $this->string(64)->notNull(),
                    'pin_number' => $this->string(64)->notNull(),
                    'introducer' => $this->string(64)->notNull(),
                    'marital_status' => $this->string(64)->notNull(),
                    'occupation' => $this->string(64)->notNull(),
                    'dept_code' => $this->integer()->notNull(),
                    'photo' => $this->string(255)->notNull(),
                    'signature' => $this->string(64)->notNull(),
                    'gender' => $this->string(6)->notNull(),
                    'salutation' => $this->string(64)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
    }

    public function safeDown() {
        echo "m170907_180411_members_list cannot be reverted.\n";

        return false;
    }

    /*
      // Use up()/down() to run migration code without a transaction.
      public function up()
      {

      }

      public function down()
      {
      echo "m170907_180411_members_list cannot be reverted.\n";

      return false;
      }
     */
}
