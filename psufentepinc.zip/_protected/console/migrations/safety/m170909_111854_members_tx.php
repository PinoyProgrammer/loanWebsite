<?php

use yii\db\Migration;

class m170909_111854_members_tx extends Migration
{
   

    public function safeUp() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        /* MYSQL */
        if (!in_array('{{%member_types}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%member_types}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(64)->notNull(),
                    'status' => $this->integer()->notNull(),                    
                    'minimum_age' => $this->integer(),
                    'maximum_age' => $this->integer(),
                    'maximum_shares' => $this->decimal(12, 2),
                    'entrance_fee' => $this->decimal(12, 2),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%member_shares}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%member_shares}}', [
                    'member_id' => $this->primaryKey(),
                    'account_number' => $this->string(64)->notNull(),
                    'is_loanable' => $this->integer(),
                    'date_applied' => $this->date()->notNull(),
                    'no_of_shares' => $this->decimal(12, 2),
                    'shares_amount' => $this->decimal(12, 2),
                    'shares_approved_at' => $this->datetime(),
                    'shares_approved_by' => $this->integer(),
                    'shares_approve_reject' => $this->integer(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
        
        if (!in_array('{{%shares_transactions}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%shares_transactions}}', [
                    'id' => $this->primaryKey(),
                    'type_id' => $this->integer()->notNull(),
                    'member_id' => $this->integer()->notNull(),
                    'no_of_shares' => $this->decimal(12, 2),
                    'shares_amount' => $this->decimal(12, 2),
                    'status' => $this->integer()->notNull()->defaultValue(1),
                    'tx_date' => $this->date()->notNull(),
                    'tx_ref' => $this->string(50)->notNull(),
                    'tx_type' =>$this->string(50)->notNull(),
                    'tx_description' => $this->string(100)->notNull(),
                    'tx_approved_at' => $this->datetime(),
                    'tx_approved_by' => $this->integer(),
                    'tx_approve_reject' => $this->integer(),
                    'created_at' => $this->datetime()->notNull(),
                    'updated_at' => $this->datetime()->notNull(),
                    'created_by' => $this->integer(),
                    'updated_by' => $this->integer(),
                        ], $tableOptions_mysql);
            }
        }
    }

    public function safeDown() {
        echo "m170907_145358_loans cannot be reverted.\n";
    }

    /*
      // Use up()/down() to run migration code without a transaction.
      public function up()
      {

      }

      public function down()
      {
      echo "m170907_145358_loans cannot be reverted.\n";

      return false;
      }
     */
}
