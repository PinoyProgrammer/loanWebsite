<?php

use yii\db\Migration;

class m170905_083908_content_manager extends Migration {

    public function safeUp() {
        $tableName = '{{%page%}}';
        $columns = [
            'id' => $this->string(),
            'title' => $this->string(),
            'body' => $this->text(),
            'PRIMARY KEY([[id]])',
        ];
        $this->createTable($tableName, $columns);
    }

    public function safeDown() {
        echo "m170905_083908_content_manager cannot be reverted.\n";

        return false;
    }

    /*
      // Use up()/down() to run migration code without a transaction.
      public function up()
      {

      }

      public function down()
      {
      echo "m170905_083908_content_manager cannot be reverted.\n";

      return false;
      }
     */
}
