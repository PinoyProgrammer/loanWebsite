<?php

use yii\db\Migration;

class m160101_000009_create_inv_tables extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */
        if (!in_array('approvedreasons', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%approvedreasons}}', [
                    'id' => $this->primaryKey(),
                    'reasons' => $this->string(45)->notNull(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('item_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%item_category}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(50)->null(),
                    'part_of' => $this->integer()->notNull()->defaultValue(0),
                    'created_at' => $this->datetime(),
                    'updated_at' => $this->datetime(),
                    'updated_by' => $this->integer()->null(),
                    'created_by' => $this->integer()->null(),
                    'branch_id' => $this->integer()->null(),
                    'start_code' => $this->string(10)->notNull(),
                    'gl_sales' => $this->integer()->null(),
                    'gl_cogs' => $this->integer()->null(),
                    'gl_purchases' => $this->integer()->null()
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('item_details', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%item_details}}', [
                    'id' => $this->primaryKey(),
                    'item_id' => $this->integer()->null(),
                    'branch_id' => $this->integer(1)->notNull(),
                    'tax_id' => $this->integer()->null()->defaultValue(0),
                    'uom_id' => $this->integer()->null()->defaultValue(0),
                    'unit_cost' => $this->decimal(12,2)->null()->defaultValue(0),
                    'credit_price' => $this->decimal(12,2)->null()->defaultValue(0),
                    'retail_price' => $this->decimal(12,2)->null()->defaultValue(0),
                    'wholesale_price' => $this->decimal(12,2)->null()->defaultValue(0),
                    'opening_stock' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_supplied' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_issued' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_sold' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_return' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_adjustment' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_on_order' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_available' => $this->decimal(12,2)->null()->defaultValue(0),
                    'in_stock' => $this->decimal(12,2)->null()->defaultValue(0),
                    'back_order' => $this->decimal(12,2)->null()->defaultValue(0),
                    'order_balance' => $this->decimal(12,2)->null()->defaultValue(0),
                    'stock_count' => $this->decimal(12,2)->null()->defaultValue(0),
                    'stock_diff' => $this->decimal(12,2)->null()->defaultValue(0),
                    'cfactor' => $this->integer()->null()->defaultValue(1),
                    'qty_return_in' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_transfer_out' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_transfer_in' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_return_out' => $this->decimal(12,2)->null()->defaultValue(0),
                    'supplier_id' => $this->integer()->null()->defaultValue(0),
                    'created_at' => $this->datetime(),
                    'updated_at' => $this->datetime(),
                    'updated_by' => $this->integer()->null(),
                    'created_by' => $this->integer()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('item_tx', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%item_tx}}', [
                    'id' => $this->primaryKey(),
                    'branch_id' => $this->integer()->null()->defaultValue(0),
                    'supplier_id' => $this->integer()->null(),
                    'customer_id' => $this->integer()->null(),
                    'vatamount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'subtotal' => $this->decimal(12,2)->null()->defaultValue(0),
                    'total' => $this->decimal(12,2)->null()->defaultValue(0),
                    'docno' => $this->string(45)->null(),
                    'doctype' => $this->string(45)->null(),
                    'txdate' => $this->date(),
                    'created_at' => $this->datetime(),
                    'updated_at' => $this->datetime(),
                    'updated_by' => $this->integer()->null(),
                    'created_by' => $this->integer()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('item_tx_details', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%item_tx_details}}', [
                    'id' => $this->primaryKey(),
                    'item_id' => $this->integer()->null(),
                    'item_id_tx' => $this->integer()->null(),
                    'tax_id' => $this->integer()->null(),
                    'uom_id' => $this->integer()->null(),
                    'unit_cost' => $this->decimal(12,2)->null()->defaultValue(0),
                    'vatrate' => $this->decimal(12,2)->null()->defaultValue(0),
                    'credit_price' => $this->decimal(12,2)->null()->defaultValue(0),
                    'retail_price' => $this->decimal(12,2)->null()->defaultValue(0),
                    'wholesale_price' => $this->decimal(12,2)->null()->defaultValue(0),
                    'opening_stock' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_supplied' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_issued' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_sold' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_return' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_on_order' => $this->decimal(12,2)->null()->defaultValue(0),
                    'order_balance' => 'DOUBLE(25,2) NULL',
                    'qty_available' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_in_stock' => $this->decimal(12,2)->null()->defaultValue(0),
                    'stock_count' => $this->decimal(12,2)->null()->defaultValue(0),
                    'stock_diff' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_return_in' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_transfer_out' => $this->decimal(12,2)->null()->defaultValue(0),
                    'qty_transfer_in' => $this->decimal(12,2)->null()->defaultValue(0),
                    'vatamount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'subtotal' => $this->decimal(12,2)->null()->defaultValue(0),
                    'total' => $this->decimal(12,2)->null()->defaultValue(0),
                    'status' => $this->integer()->notNull()->defaultValue(0),
                    'created_at' => $this->datetime(),
                    'updated_at' => $this->datetime(),
                    'updated_by' => $this->integer()->null(),
                    'created_by' => $this->integer()->null(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('items', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%items}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(145)->notNull(),
                    'part_number' => $this->string(45)->null(),
                    'unitcost' => $this->decimal(12,2)->null()->defaultValue(0),
                    'uom_id' => $this->integer()->null()->defaultValue(0),
                    'category_id' => $this->integer()->null()->defaultValue(0),
                    'status' => $this->integer()->notNull()->defaultValue(0),
                    'part_of' => $this->integer()->null(),
                    'created_at' => $this->datetime(),
                    'updated_at' => $this->datetime(),
                    'updated_by' => $this->integer()->null(),
                    'created_by' => $this->integer()->null(),
                    'code' => $this->string(10)->notNull(),
                    'tax_id' => $this->integer()->null()
                        ], $tableOptions_mysql);
            }
        }


        /* MYSQL */
        if (!in_array('quotationitems', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%quotationitems}}', [
                    'id' => $this->primaryKey(),
                    'docno' => $this->string(64)->notNull()->defaultValue(''),
                    'doctype' => $this->string(64)->notNull()->defaultValue(''),
                    'productcode' => $this->string(64)->notNull()->defaultValue(''),
                    'projectid' => $this->string(64)->notNull()->defaultValue(''),
                    'description' => $this->text(),
                    'partnumber' => $this->string(64)->notNull()->defaultValue(''),
                    'qty' => $this->decimal(12,2)->null()->defaultValue(0),
                    'quoteprice' => $this->decimal(12,2)->null()->defaultValue(0),
                    'goodmount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'vatamount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'vatrate' => $this->decimal(12,2)->null()->defaultValue(0),
                    'totalamount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'date' => $this->date(),
                    'deptcode' => $this->string(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('quotations', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%quotations}}', [
                    'id' => $this->primaryKey(),
                    'date' => $this->date(),
                    'docno' => $this->string(64)->notNull()->defaultValue(''),
                    'doctype' => $this->string(64)->notNull()->defaultValue(''),
                    'custcode' => $this->string(64)->notNull()->defaultValue(''),
                    'projectid' => $this->string(64)->notNull()->defaultValue(''),
                    'contactperson' => $this->string(64)->notNull()->defaultValue(''),
                    'suppliercode' => $this->string(64)->null()->defaultValue(''),
                    'terms' => $this->text(),
                    'remarks' => $this->text(),
                    'totalamount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'preparedby' => $this->string(64)->notNull()->defaultValue(''),
                    'approvedby' => $this->string(64)->notNull()->defaultValue(''),
                    'status' => $this->string(1)->null()->defaultValue(''),
                    'deptcode' => $this->string(1)->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }


        /* MYSQL */
        if (!in_array('unit_of_measure', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%unit_of_measure}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(50)->null(),
                    'part_of' => $this->integer()->notNull()->defaultValue(0),
                    'part_of_factor' => $this->decimal(12,6)->notNull(),
                    'prefix' => $this->string(3)->null()->defaultValue('')
                        ], $tableOptions_mysql);
            }
        }
        $this->createIndex('idx_UNIQUE_reasons_3796_09', 'approvedreasons', 'reasons', 1);
        $this->createIndex('idx_UNIQUE_code_6158_22', 'items', 'code', 1);
        $this->execute('SET foreign_key_checks = 0');
        $this->insert('{{%unit_of_measure}}', ['id' => '1', 'name' => 'Grammes', 'part_of' => '2', 'part_of_factor' => '1000.000000', 'prefix' => 'g']);
        $this->insert('{{%unit_of_measure}}', ['id' => '2', 'name' => 'Kilograms', 'part_of' => '1', 'part_of_factor' => '0.001000', 'prefix' => 'Kg']);
        $this->insert('{{%unit_of_measure}}', ['id' => '3', 'name' => 'Pieces', 'part_of' => '22', 'part_of_factor' => '12.000000', 'prefix' => 'PCs']);
        $this->insert('{{%unit_of_measure}}', ['id' => '4', 'name' => 'Pkts', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '5', 'name' => 'Ltrs', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '6', 'name' => 'glass', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '7', 'name' => 'Pairs', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '8', 'name' => 'Pkts', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '9', 'name' => 'Cup', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '10', 'name' => 'Ream', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '11', 'name' => 'Dozen', 'part_of' => '3', 'part_of_factor' => '0.083333', 'prefix' => 'DZ']);
        $this->insert('{{%unit_of_measure}}', ['id' => '12', 'name' => 'Lot', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '13', 'name' => 'Pax', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '14', 'name' => 'Plate', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '15', 'name' => 'Mtrs', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '16', 'name' => 'Fts', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '17', 'name' => 'Tot', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '18', 'name' => 'Days', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '19', 'name' => 'bags', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '20', 'name' => 'Bushes', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '21', 'name' => 'Box', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '22', 'name' => 'Gross', 'part_of' => '3', 'part_of_factor' => '0.083333', 'prefix' => 'GRS']);
        $this->insert('{{%unit_of_measure}}', ['id' => '23', 'name' => 'Rolls', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '24', 'name' => 'Carton', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '25', 'name' => 'Sets', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);
        $this->insert('{{%unit_of_measure}}', ['id' => '26', 'name' => 'Tubes', 'part_of' => '0', 'part_of_factor' => '0.000000', 'prefix' => '']);

        $this->execute('SET foreign_key_checks = 1');
    }

    public function down() {
        echo "m160618_114255_alter_table_user cannot be reverted.\n";
        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
