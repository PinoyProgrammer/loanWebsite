<?php

use yii\db\Migration;

class m160101_000010_create_fa_tables extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */
        if (!in_array('asset_category', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%asset_category}}', [
                    'id' => $this->primaryKey(),                    
                    'name' => $this->string(64)->null(),
                    'dept_method_id' => $this->integer()->null(),
                    'dept_method_rate' => $this->decimal(12,2)->null()->defaultValue(0),
                    'gl_asset' => $this->integer(10)->null(),
                    'gl_depreciation_expense' => $this->integer(10)->null(),
                    'gl_accum_depreciation' => $this->integer(10)->null()->defaultValue(0),
                    'gl_asset_disposal' => $this->integer(10)->null(),
                    'asset_life' => $this->decimal(12,2)->null()->defaultValue(0),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'created_by' => $this->integer()->null(),
                    'created_at' => $this->datetime(),
                    'updated_by' => $this->integer()->null(),
                    'updated_at' => $this->datetime(),
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('asset_tx', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%asset_tx}}', [
                    'id' => $this->primaryKey(),
                    'txdate' => $this->date(),
                    'docno' => $this->string(45)->null(),
                    'doctype' => $this->string(45)->null(),
                    'amount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'asset_id' => $this->integer()->notNull()->defaultValue(0),
                    'particulars' => $this->string(45)->null(),
                    'narration' => $this->string(45)->null(),
                    'shiftnumber' => $this->integer()->notNull()->defaultValue(0),
                    'deptcode' => $this->integer()->notNull()->defaultValue(0),
                    'created_date' => $this->datetime(),
                    'updated_date' => $this->datetime(),
                    'created_by' => $this->integer()->notNull()->defaultValue(0),
                    'updated_by' => $this->integer()->notNull()->defaultValue(0),
                    'cauditnumber' => $this->string(64)->null(),
                    'vatamount' => $this->decimal(12,2)->null()->defaultValue(0),
                    'subtotal' => $this->decimal(12,2)->null()->defaultValue(0),
                    'ref_id' => $this->integer()->null(),
                    'supplier_id' => $this->integer()->null(),
                    'customer_id' => $this->integer()->null(),
                    'qty' => $this->decimal(12,2)->notNull()->defaultValue(0)
                        ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('assets', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%assets}}', [
                    'id' => $this->primaryKey(),
                    'category_id' => $this->string(50)->null(),
                    'name' => $this->string(64)->null(),
                    'serial_no' => $this->string(128)->null(),
                    'supplier_id' => $this->integer()->null(),
                    'date_of_purchase' => $this->date(),
                    'last_date' => $this->date(),
                    'age_to_date' => $this->decimal(12,2)->null()->defaultValue(0),
                    'asset_life' => $this->decimal(12,2)->null()->defaultValue(0),
                    'dept_method_id' => $this->integer()->null(),
                    'dept_method_rate' => $this->decimal(12,2)->null()->defaultValue(0),
                    'cost' => $this->decimal(12,2)->null()->defaultValue(0),
                    'accumulated_depreciation' => $this->decimal(12,2)->null()->defaultValue(0),
                    'book_value' => $this->decimal(12,2)->null()->defaultValue(0),
                    'quantity' => $this->decimal(12,2)->null()->defaultValue(0),
                    'residue_value' => $this->decimal(12,2)->null()->defaultValue(0),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'created_by' => $this->integer()->null(),
                    'updated_by' => $this->integer()->null(),
                    'updated_at' => $this->datetime(),
                    'created_at' => $this->datetime(),
                    'tax_id' => $this->integer()->null(),
                        ], $tableOptions_mysql);
            }
        }
        $this->execute('SET foreign_key_checks = 0');
        $this->insert('{{%asset_category}}', ['name' => 'Buildings and Constructions', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '239', 'gl_depreciation_expense' => '241', 'gl_accum_depreciation' => '240', 'gl_asset_disposal' => '99', 'asset_life' => '0.90', 'id' => '1', 'company_id' => '0', 'created_by' => '1', 'created_at' => '2016-09-25 18:37:00', 'updated_by' => '1', 'updated_at' => '2016-09-25 18:37:00']);
        $this->insert('{{%asset_category}}', ['name' => 'Furniture and Fixtures', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '32', 'gl_depreciation_expense' => '156', 'gl_accum_depreciation' => '41', 'gl_asset_disposal' => '92', 'asset_life' => '5.00', 'id' => '2', 'company_id' => '0', 'created_by' => '1', 'created_at' => '2016-09-25 18:48:00', 'updated_by' => '1', 'updated_at' => '2016-09-25 18:48:00']);
        $this->insert('{{%asset_category}}', ['name' => 'Office Equipments', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '3', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->insert('{{%asset_category}}', ['name' => 'Motor Vehicles', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '4', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->insert('{{%asset_category}}', ['name' => 'Computer Equipments', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '5', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->insert('{{%asset_category}}', ['name' => 'Other Depreciable Property', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '6', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->insert('{{%asset_category}}', ['name' => 'Leasehold Improvements', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '7', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->insert('{{%asset_category}}', ['name' => 'Machines and Equipment', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '8', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->insert('{{%asset_category}}', ['name' => 'Office Improvements', 'dept_method_id' => '2', 'dept_method_rate' => '15', 'gl_asset' => '', 'gl_depreciation_expense' => '', 'gl_accum_depreciation' => '0', 'gl_asset_disposal' => '', 'asset_life' => '', 'id' => '9', 'company_id' => '0', 'created_by' => '', 'created_at' => '', 'updated_by' => '', 'updated_at' => '']);
        $this->execute('SET foreign_key_checks = 1;');
    }

    public function down() {
        echo "m160703_115517_add_company_id cannot be reverted.\n";

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
