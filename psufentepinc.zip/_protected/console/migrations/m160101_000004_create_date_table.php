<?php

use yii\db\Migration;

class m160101_000004_create_date_table extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */
        if (!in_array('_dates', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%_dates}}', [
                    'd' => $this->date() ,
                        ], $tableOptions_mysql);
            }
        }
    }

    public function down() {
        echo "m160611_095147_create_date_table cannot be reverted.\n";

        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS _dates');
        $this->execute('SET foreign_key_checks = 1;');
        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
