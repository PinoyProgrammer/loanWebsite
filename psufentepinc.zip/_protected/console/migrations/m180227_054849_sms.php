<?php

use yii\db\Migration;

/**
 * Class m180227_054849_sms
 */
class m180227_054849_sms extends Migration {

    /**
     * {@inheritdoc}
     */
    public function safeUp() {

        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        /* MYSQL */
        if (!in_array('{{%pax}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%pax}}', [
                    'id' => $this->primaryKey(),
                    'pnr_number' => $this->string(10)->notNull(),
                    'firstname' => $this->string(50)->notNull(),
                    'lastname' => $this->string(50)->notNull(),
                    'flt_date' => $this->dateTime()->notNull(),
                    'fltno' => $this->string(10)->notNull(),
                    'depart' => $this->string(10)->notNull(),
                    'arrive' => $this->string(10)->notNull(),
                    'home_phone' => $this->string(50)->notNull(),
                    'business_phone' => $this->string(50)->notNull(),
                    'other_phone' => $this->string(50)->notNull(),
                    'travel_phone' => $this->string(50)->notNull(),
                    'mobile_phone' => $this->string(50)->notNull(),
                    'valid_phone' => $this->string(10)->notNull(),
                    'valid_phone_prefix' => $this->string(5)->notNull(),
                    'email' => $this->string(100)->notNull(),
                    'flt_time' => $this->dateTime()->notNull(),
                    'created_at' => $this->dateTime()->notNull(),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%compulsory_receivers}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%compulsory_receivers}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(200)->notNull(),
                    'smsno' => $this->string(100)->notNull(),
                    'status' => $this->integer()->notNull()->defaultValue(1),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%message_queue}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%message_queue}}', [
                    'id' => $this->primaryKey(),
                    'template_id' => $this->integer()->notNull(),
                    'created_at' => $this->dateTime()->notNull(),
                    'created_by' => $this->integer()->notNull(),
                    'pax_id' => $this->integer()->notNull(),
                    'status' => $this->integer()->notNull()->defaultValue(1),
                    'api_status' => $this->string(200)->notNull(),
                    'message' => $this->string(200)->notNull(),
                    'sms_no' => $this->string(20)->notNull(),
                        ], $tableOptions_mysql);
            }
            $this->execute('SET foreign_key_checks = 0');
            $this->addForeignKey('fk_message_queue_1', '{{%message_queue}}', 'template_id', '{{%templates}}', 'id', 'CASCADE', 'CASCADE');
            $this->addForeignKey('fk_message_queue_2', '{{%message_queue}}', 'pax_id', '{{%pax}}', 'id', 'CASCADE', 'CASCADE');
            $this->execute('SET foreign_key_checks = 1');
        }
         if (!in_array('{{%templates}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%templates}}', [
                    'id' => $this->primaryKey(),
                    'message' => $this->string(200)->notNull(),
                    'title' => $this->string(100)->notNull(),
                    'created_at' => $this->dateTime()->notNull(),
                    'user_id' => $this->integer()->notNull(),
                    'status' => $this->integer()->notNull()->defaultValue(1),
                        ], $tableOptions_mysql);
            }
        }
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown() {
        echo "m180227_054849_sms cannot be reverted.\n";

        return false;
    }

    /*
      // Use up()/down() to run migration code without a transaction.
      public function up()
      {

      }

      public function down()
      {
      echo "m180227_054849_sms cannot be reverted.\n";

      return false;
      }
     */
}
