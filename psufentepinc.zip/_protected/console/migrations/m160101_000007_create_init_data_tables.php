<?php

use yii\db\Migration;

class m160101_000007_create_init_data_tables extends Migration {

    public function up() {

        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";


        /* MYSQL */
        if (!in_array('{{%country}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%country}}', [
                    'countrycode' => $this->string(11)->notNull(),
                    'countryname' => $this->string(45)->null(),
                    'nationality' => $this->string(45)->null(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }


        /* MYSQL */
        if (!in_array('{{%files}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%files}}', [
                    'file_id' => $this->primaryKey(),
                    'file_path' => $this->string(256)->notNull(),
                    'file_name' => $this->string(56)->notNull(),
                    'file_size' => $this->string(56)->notNull(),
                    'file_type' => $this->string(56)->notNull(),
                    'display_type' => $this->string(25)->notNull(),
                    'description' => $this->string(200)->notNull(),
                    'created_by' => $this->integer()->notNull(),
                    'creation_date' => $this->datetime(),
                    'last_update_by' => $this->integer()->notNull(),
                    'last_update_date' => $this->datetime(),
                    'module_name' => $this->string(60)->null(),
                    'document_type' => $this->string(50)->null(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'referenceid' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }



        /* MYSQL */
        if (!in_array('{{%org}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%org}}', [
                    'org_id' => $this->primaryKey(),
                    'org' => $this->string(56)->notNull(),
                    'code' => $this->string(5)->notNull(),
                    'type' => $this->string(56)->notNull(),
                    'description' => $this->string(200)->notNull(),
                    'enterprise_org_id' => $this->integer()->null(),
                    'legal_org_id' => $this->integer()->null(),
                    'business_org_id' => $this->integer()->null(),
                    'inventory_org_id' => $this->integer()->null(),
                    'ef_id' => $this->integer()->null(),
                    'status' => $this->integer()->null()->defaultValue(1),
                    'rev_enabled' => $this->string(50)->null(),
                    'rev_number' => $this->integer()->null(),
                    'address_id' => $this->integer()->null(),
                    'created_by' => $this->integer()->notNull(),
                    'creation_date' => $this->datetime(),
                    'last_update_by' => $this->integer()->notNull(),
                    'last_update_date' => $this->datetime(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                    'org_logo' => $this->string(255)->null(),
                        ], $tableOptions_mysql);
            }
        }


        if (!in_array('{{%titles}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%titles}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(45)->notNull(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%county}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%county}}', [
                    'id' => $this->primaryKey(),
                    'code' => $this->string(4)->notNull(),
                    'name' => $this->string(45)->notNull(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%idtypes}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%idtypes}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(45)->notNull(),
                    'company_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        if (!in_array('{{%constituency}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%constituency}}', [
                    'id' => $this->primaryKey(),
                    'name' => $this->string(45)->notNull(),
                    'county_id' => $this->integer()->notNull()->defaultValue(0),
                        ], $tableOptions_mysql);
            }
        }
        



        $this->insert('{{%org}}', ['org_id' => '1', 'org' => 'SYS', 'code' => 'SYS', 'type' => 'ENTERPRISE', 'description' => 'System', 'enterprise_org_id' => '', 'legal_org_id' => '', 'business_org_id' => '', 'inventory_org_id' => '', 'ef_id' => '', 'status' => '0', 'rev_enabled' => '', 'rev_number' => '', 'address_id' => '', 'created_by' => '1', 'creation_date' => '2016-07-03 17:27:00', 'last_update_by' => '1', 'last_update_date' => '2016-07-03 17:27:00', 'company_id' => '0', 'org_logo' => '']);
        $this->insert('{{%titles}}', ['id' => '1', 'name' => 'Mr', 'company_id' => '0']);
        $this->insert('{{%titles}}', ['id' => '2', 'name' => 'Mrs', 'company_id' => '0']);
        $this->insert('{{%titles}}', ['id' => '3', 'name' => 'Miss', 'company_id' => '0']);
        $this->insert('{{%titles}}', ['id' => '4', 'name' => 'Dr', 'company_id' => '0']);
        $this->insert('{{%titles}}', ['id' => '5', 'name' => 'Prof', 'company_id' => '0']);
        $this->insert('{{%titles}}', ['id' => '6', 'name' => 'Rev', 'company_id' => '0']);
        $this->insert('{{%titles}}', ['id' => '7', 'name' => 'Hon', 'company_id' => '0']);
        
        $this->execute('SET foreign_key_checks = 0');
        $this->insert('{{%country}}', ['countrycode' => '+211', 'countryname' => 'Southern Sudan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AD', 'countryname' => 'Andorra', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AE', 'countryname' => 'United Arab Emirates', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AF', 'countryname' => 'Afghanistan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AG', 'countryname' => 'Antigua and Barbuda', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AI', 'countryname' => 'Anguilla', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AL', 'countryname' => 'Albania', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AM', 'countryname' => 'Armenia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AN', 'countryname' => 'Netherlands Antilles', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AO', 'countryname' => 'Angola', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AQ', 'countryname' => 'Antarctica', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AR', 'countryname' => 'Argentina', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AS', 'countryname' => 'American Samoa', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AT', 'countryname' => 'Austria', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AU', 'countryname' => 'Australia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AW', 'countryname' => 'Aruba', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AX', 'countryname' => '??land Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'AZ', 'countryname' => 'Azerbaijan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BA', 'countryname' => 'Bosnia and Herzegovina', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BB', 'countryname' => 'Emrysdos', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BD', 'countryname' => 'Bangladesh', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BE', 'countryname' => 'Belgium', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BF', 'countryname' => 'Burkina Faso', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BG', 'countryname' => 'Bulgaria', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BH', 'countryname' => 'Bahrain', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BI', 'countryname' => 'Burundi', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BJ', 'countryname' => 'Benin', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BL', 'countryname' => 'Saint BarthÃƒÂ©lemy', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BM', 'countryname' => 'Bermuda', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BN', 'countryname' => 'Brunei Darussalam', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BO', 'countryname' => 'Bolivia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BR', 'countryname' => 'Brazil', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BS', 'countryname' => 'Bahamas', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BT', 'countryname' => 'Bhutan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BV', 'countryname' => 'Bouvet Island', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BW', 'countryname' => 'Botswana', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BY', 'countryname' => 'Belarus', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'BZ', 'countryname' => 'Belize', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CA', 'countryname' => 'Canada', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CC', 'countryname' => 'Cocos (Keeling) Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CD', 'countryname' => 'Congo, The Democratic Republic of the', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CF', 'countryname' => 'Central African Republic', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CG', 'countryname' => 'Congo', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CH', 'countryname' => 'Switzerland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CI', 'countryname' => 'CÃƒÂ´te D Ivoire', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CK', 'countryname' => 'Cook Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CL', 'countryname' => 'Chile', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CM', 'countryname' => 'Cameroon', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CN', 'countryname' => 'China', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CO', 'countryname' => 'Colombia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CR', 'countryname' => 'Costa Rica', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CU', 'countryname' => 'Cuba', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CV', 'countryname' => 'Cape Verde', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CX', 'countryname' => 'Christmas Island', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CY', 'countryname' => 'Cyprus', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'CZ', 'countryname' => 'Czech Republic', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'DE', 'countryname' => 'Germany', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'DJ', 'countryname' => 'Djibouti', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'DK', 'countryname' => 'Denmark', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'DM', 'countryname' => 'Dominica', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'DO', 'countryname' => 'Dominican Republic', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'DZ', 'countryname' => 'Algeria', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'EC', 'countryname' => 'Ecuador', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'EE', 'countryname' => 'Estonia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'EG', 'countryname' => 'Egypt', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'EH', 'countryname' => 'Western Sahara', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ER', 'countryname' => 'Eritrea', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ES', 'countryname' => 'Spain', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ET', 'countryname' => 'Ethiopia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'FI', 'countryname' => 'Finland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'FJ', 'countryname' => 'Fiji', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'FK', 'countryname' => 'Falkland Islands (Malvinas)', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'FM', 'countryname' => 'Micronesia, Federated States of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'FO', 'countryname' => 'Faroe Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'FR', 'countryname' => 'France', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GA', 'countryname' => 'Gabon', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GB', 'countryname' => 'United Kingdom', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GD', 'countryname' => 'Grenada', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GE', 'countryname' => 'Georgia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GF', 'countryname' => 'French Guiana', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GG', 'countryname' => 'Guernsey', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GH', 'countryname' => 'Ghana', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GI', 'countryname' => 'Gibraltar', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GL', 'countryname' => 'Greenland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GM', 'countryname' => 'Gambia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GN', 'countryname' => 'Guinea', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GP', 'countryname' => 'Guadeloupe', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GQ', 'countryname' => 'Equatorial Guinea', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GR', 'countryname' => 'Greece', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GS', 'countryname' => 'South Georgia and the South Sandwich Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GT', 'countryname' => 'Guatemala', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GU', 'countryname' => 'Guam', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GW', 'countryname' => 'Guinea-Bissau', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'GY', 'countryname' => 'Guyana', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'HK', 'countryname' => 'Hong Kong', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'HM', 'countryname' => 'Heard Island and McDonald Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'HN', 'countryname' => 'Honduras', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'HR', 'countryname' => 'Croatia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'HT', 'countryname' => 'Haiti', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'HU', 'countryname' => 'Hungary', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ID', 'countryname' => 'Indonesia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IE', 'countryname' => 'Ireland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IL', 'countryname' => 'Israel', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IM', 'countryname' => 'Isle of Man', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IN', 'countryname' => 'India', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IO', 'countryname' => 'British Indian Ocean Territory', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IQ', 'countryname' => 'Iraq', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IR', 'countryname' => 'Iran, Islamic Republic of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IS', 'countryname' => 'Iceland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'IT', 'countryname' => 'Italy', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'JE', 'countryname' => 'Jersey', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'JM', 'countryname' => 'Jamaica', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'JO', 'countryname' => 'Jordan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'JP', 'countryname' => 'Japan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KE', 'countryname' => 'Kenya', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KG', 'countryname' => 'Kyrgyzstan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KH', 'countryname' => 'Cambodia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KI', 'countryname' => 'Kiribati', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KM', 'countryname' => 'Comoros', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KN', 'countryname' => 'Saint Kitts and Nevis', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KP', 'countryname' => 'Korea, Democratic Peoples Republic of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KR', 'countryname' => 'Korea, Republic of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KW', 'countryname' => 'Kuwait', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KY', 'countryname' => 'Cayman Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'KZ', 'countryname' => 'Kazakhstan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LA', 'countryname' => 'Lao Peoples Democratic Republic', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LB', 'countryname' => 'Lebanon', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LC', 'countryname' => 'Saint Lucia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LI', 'countryname' => 'Liechtenstein', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LK', 'countryname' => 'Sri Lanka', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LR', 'countryname' => 'Liberia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LS', 'countryname' => 'Lesotho', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LT', 'countryname' => 'Lithuania', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LU', 'countryname' => 'Luxembourg', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LV', 'countryname' => 'Latvia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'LY', 'countryname' => 'Libyan Arab Jamahiriya', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MA', 'countryname' => 'Morocco', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MC', 'countryname' => 'Monaco', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MD', 'countryname' => 'Moldova, Republic of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ME', 'countryname' => 'Montenegro', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MF', 'countryname' => 'Saint Martin', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MG', 'countryname' => 'Madagascar', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MH', 'countryname' => 'Marshall Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MK', 'countryname' => 'Macedonia, The Former Yugoslav Republic of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ML', 'countryname' => 'Mali', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MM', 'countryname' => 'Myanmar', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MN', 'countryname' => 'Mongolia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MO', 'countryname' => 'Macao', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MP', 'countryname' => 'Northern Mariana Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MQ', 'countryname' => 'Martinique', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MR', 'countryname' => 'Mauritania', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MS', 'countryname' => 'Montserrat', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MT', 'countryname' => 'Malta', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MU', 'countryname' => 'Mauritius', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MV', 'countryname' => 'Maldives', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MW', 'countryname' => 'Malawi', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MX', 'countryname' => 'Mexico', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MY', 'countryname' => 'Malaysia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'MZ', 'countryname' => 'Mozambique', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NA', 'countryname' => 'Namibia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NC', 'countryname' => 'New Caledonia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NE', 'countryname' => 'Niger', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NF', 'countryname' => 'Norfolk Island', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NG', 'countryname' => 'Nigeria', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NI', 'countryname' => 'Nicaragua', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NL', 'countryname' => 'Netherlands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NO', 'countryname' => 'Norway', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NP', 'countryname' => 'Nepal', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NR', 'countryname' => 'Nauru', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NU', 'countryname' => 'Niue', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'NZ', 'countryname' => 'New Zealand', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'OM', 'countryname' => 'Oman', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PA', 'countryname' => 'Panama', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PE', 'countryname' => 'Peru', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PF', 'countryname' => 'French Polynesia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PG', 'countryname' => 'Papua New Guinea', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PH', 'countryname' => 'Philippines', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PK', 'countryname' => 'Pakistan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PL', 'countryname' => 'Poland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PM', 'countryname' => 'Saint Pierre and Miquelon', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PN', 'countryname' => 'Pitcairn', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PR', 'countryname' => 'Puerto Rico', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PS', 'countryname' => 'Palestinian Territory, Occupied', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PT', 'countryname' => 'Portugal', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PW', 'countryname' => 'Palau', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'PY', 'countryname' => 'Paraguay', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'QA', 'countryname' => 'Qatar', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'RE', 'countryname' => 'Reunion', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'RO', 'countryname' => 'Romania', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'RS', 'countryname' => 'Serbia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'RU', 'countryname' => 'Russian Federation', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'RW', 'countryname' => 'Rwanda', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SA', 'countryname' => 'Saudi Arabia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SB', 'countryname' => 'Solomon Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SC', 'countryname' => 'Seychelles', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SD', 'countryname' => 'Sudan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SE', 'countryname' => 'Sweden', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SG', 'countryname' => 'Singapore', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SH', 'countryname' => 'Saint Helena', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SI', 'countryname' => 'Slovenia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SJ', 'countryname' => 'Svalbard and Jan Mayen', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SK', 'countryname' => 'Slovakia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SL', 'countryname' => 'Sierra Leone', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SM', 'countryname' => 'San Marino', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SN', 'countryname' => 'Senegal', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SO', 'countryname' => 'Somalia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SR', 'countryname' => 'Suriname', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ST', 'countryname' => 'Sao Tome and Principe', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SV', 'countryname' => 'El Salvador', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SY', 'countryname' => 'Syrian Arab Republic', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'SZ', 'countryname' => 'Swaziland', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TC', 'countryname' => 'Turks and Caicos Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TD', 'countryname' => 'Chad', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TF', 'countryname' => 'French Southern Territories', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TG', 'countryname' => 'Togo', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TH', 'countryname' => 'Thailand', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TJ', 'countryname' => 'Tajikistan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TK', 'countryname' => 'Tokelau', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TL', 'countryname' => 'Timor-Leste', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TM', 'countryname' => 'Turkmenistan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TN', 'countryname' => 'Tunisia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TO', 'countryname' => 'Tonga', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TR', 'countryname' => 'Turkey', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TT', 'countryname' => 'Trinidad and Tobago', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TV', 'countryname' => 'Tuvalu', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TW', 'countryname' => 'Taiwan, Province Of China', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'TZ', 'countryname' => 'Tanzania, United Republic of', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'UA', 'countryname' => 'Ukraine', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'UG', 'countryname' => 'Uganda', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'UM', 'countryname' => 'United States Minor Outlying Islands', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'US', 'countryname' => 'United States', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'UY', 'countryname' => 'Uruguay', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'UZ', 'countryname' => 'Uzbekistan', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VA', 'countryname' => 'Holy See (Vatican City State)', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VC', 'countryname' => 'Saint Vincent and the Grenadines', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VE', 'countryname' => 'Venezuela', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VG', 'countryname' => 'Virgin Islands, British', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VI', 'countryname' => 'Virgin Islands, U.S.', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VN', 'countryname' => 'Viet Nam', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'VU', 'countryname' => 'Vanuatu', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'WF', 'countryname' => 'Wallis And Futuna', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'WS', 'countryname' => 'Samoa', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'YE', 'countryname' => 'Yemen', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'YT', 'countryname' => 'Mayotte', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ZA', 'countryname' => 'South Africa', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ZM', 'countryname' => 'Zambia', 'nationality' => '', 'company_id' => '0']);
        $this->insert('{{%country}}', ['countrycode' => 'ZW', 'countryname' => 'Zimbabwe', 'nationality' => '', 'company_id' => '0']);
        $this->execute('SET foreign_key_checks = 1');
    }

    public function down() {
        echo "m160705_093840_add_address cannot be reverted.\n";
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `address`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `address_reference`');
        $this->execute('SET foreign_key_checks = 1;');
        return false;
    }

    /*
      Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
