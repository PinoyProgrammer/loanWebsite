<?php

use yii\db\Migration;

class m170514_175800_option_lines extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";

        if (!in_array('{{%option_line}}', $tables)) {
            //if ($dbType == "mysql") {
            $this->createTable('{{%option_line}}', [
                'option_line_id' => $this->primaryKey(),
                'option_line_code' => $this->string(255)->null(),
                'description' => $this->string(255)->null(),
                'priority' => $this->integer()->notNull(),
                'status' => $this->integer()->notNull(),
                'created_at' => $this->timestamp()->null(),
                'updated_at' => $this->timestamp()->null(),
                'created_by' => $this->integer()->null(),
                'updated_by' => $this->integer()->null(),
                    ], $tableOptions_mysql);
            //}
        }
    }

    public function down() {
        echo "m170514_175800_option_lines cannot be reverted.\n";

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
