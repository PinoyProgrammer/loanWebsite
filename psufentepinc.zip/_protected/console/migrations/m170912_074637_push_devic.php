<?php

use yii\db\Migration;

class m170912_074637_push_devic extends Migration {

    public function safeUp() {

        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        /* MYSQL */
        if (!in_array('{{%push_devices}}', $tables)) {
            if ($dbType == "mysql") {
                $this->createTable('{{%push_devices}}', [
                    'device_id' => $this->primaryKey(),
                    'device_token' => $this->string(200)->notNull(),
                    'id_token' => $this->string(100)->notNull(),
                    'status' => $this->integer()->notNull()->defaultValue(1),
                    'user_id' => $this->integer()->notNull(),
                    'language' => $this->string(2)->notNull(),
                    'platform' => $this->string(10)->notNull(),
                    'created_at' => $this->datetime()->notNull(),
                        ], $tableOptions_mysql);
            }
            $this->createIndex('device_token_unique', '{{%push_devices}}', 'device_token', 1);
        }
    }

    public function safeDown() {
        echo "m170912_074637_push_devic cannot be reverted.\n";

        return false;
    }

    /*
      // Use up()/down() to run migration code without a transaction.
      public function up()
      {

      }

      public function down()
      {
      echo "m170912_074637_push_devic cannot be reverted.\n";

      return false;
      }
     */
}
