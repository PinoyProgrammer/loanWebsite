<?php

use yii\db\Migration;

class m160101_000005_menus extends Migration {

    public function up() {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */
        if (!in_array('{{%user_group_permission}}n', $tables)) {
            //if ($dbType == "mysql") {
                $this->createTable('{{%user_group_permission}}', [
                    'id' => $this->primaryKey(),
                    'menu_id' => $this->integer()->defaultValue(0),
                    'menu_item_id' => $this->integer()->defaultValue(0),
                    'group_id' => $this->integer()->defaultValue(0),
                    'can_create' => $this->integer()->defaultValue(0),
                    'can_update' => $this->integer()->defaultValue(0),
                    'can_view' => $this->integer()->defaultValue(0),
                    'can_delete' => $this->integer()->defaultValue(0),
                    'can_chmod' => $this->integer()->defaultValue(0),
                    'created_by' => $this->integer()->defaultValue(0),
                    'created_at' => $this->datetime(),
                        ], $tableOptions_mysql);
           // }
        }

        /* MYSQL */
        if (!in_array('user_menu', $tables)) {
            //if ($dbType == "mysql") {
                $this->createTable('{{%user_menu}}', [
                    'menu_id' => $this->primaryKey(),
                    'menu_url' => $this->string()->defaultValue(''),
                    'description' => $this->string()->defaultValue(''),
                    'active' => $this->integer()->defaultValue(0),
                    'company_type' => $this->integer()->defaultValue(1),
                    'dept_type' => $this->integer()->defaultValue(1),
                    'ord' => $this->integer()->defaultValue(0),
                    'fa' => $this->string(45)->defaultValue(''),
                        ], $tableOptions_mysql);
            //}
        }

        /* MYSQL */
        if (!in_array('{{%user_menu_item}}', $tables)) {
           // if ($dbType == "mysql") {
                $this->createTable('{{%user_menu_item}}', [
                    'menu_item_id' => $this->primaryKey(),
                    'menu_id' => $this->integer()->notNull(),
                    'menu_item_url' => $this->string(128)->null(),
                    'description' => $this->string(128)->null(),
                    'dept_type' => $this->integer()->defaultValue(0),
                    'company_type' => $this->integer()->defaultValue(0),
                    'active' => $this->integer()->defaultValue(0),
                    'ord' => $this->integer()->defaultValue(0),
                    'fa' => $this->string()->defaultValue(''),
                    'type' => $this->string(1)->null(),
                        ], $tableOptions_mysql);
            //}
        }

        /* MYSQL */
        if (!in_array('{{%user_permissions}}', $tables)) {
            //if ($dbType == "mysql") {
                $this->createTable('{{%user_permissions}}', [
                    'id' => $this->primaryKey(),
                    'menu_id' => $this->integer()->defaultValue(0),
                    'menu_item_id' => $this->integer()->defaultValue(0),
                    'user_id' => $this->integer()->defaultValue(0),
                    'can_create' => $this->integer()->defaultValue(0),
                    'can_update' => $this->integer()->defaultValue(0),
                    'can_view' => $this->integer()->defaultValue(0),
                    'can_delete' => $this->integer()->defaultValue(0),
                    'can_chmod' => $this->integer()->defaultValue(0),
                    'created_by' => $this->integer()->defaultValue(0),
                    'created_at' => $this->datetime(),
                        ], $tableOptions_mysql);
            //}
        }

        /* MYSQL */
        

        //$this->execute('SET IDENTITY_INSERT user_menu ON');
        //$this->execute('truncate {{%user_menu}} ');
        //$this->execute('truncate {{%user_menu_item}} ');
        //$this->execute('SET IDENTITY_INSERT user_menu OFF');
    }

    public function down() {
        echo "m161222_111120_menus cannot be reverted.\n";

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
