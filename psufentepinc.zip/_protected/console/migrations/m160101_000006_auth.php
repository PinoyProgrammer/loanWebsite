<?php

use yii\db\Migration;

class m160101_000006_auth extends Migration {

    public function up() {
        //$this->dropTable('auth');
        $this->createTable('{{%auth}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'source' => $this->string()->notNull(),
            'source_id' => $this->string()->notNull(),
        ]);

        $this->addForeignKey('fk-auth-user_id-user-id', '{{%auth}}', 'user_id', '{{%users}}', 'user_id', 'CASCADE', 'CASCADE');
    }

    public function down() {
        echo "m161113_080903_auth cannot be reverted.\n";
        $this->dropTable('auth');
        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
