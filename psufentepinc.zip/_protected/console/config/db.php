<?php
$DB="flyfivfo_sms";
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname='.$DB,
    'username' => 'root',
    'password' => 'Rolexe540',
    'tablePrefix' => 'sms_',
    'charset' => 'utf8',
    'enableSchemaCache' => false,
];
