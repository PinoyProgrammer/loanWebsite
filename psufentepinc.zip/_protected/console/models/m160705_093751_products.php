<?php

use yii\db\Migration;

class m160705_093751_products extends Migration
{
    public function up()
    {


//$tables = Yii::$app->db->schema->getTableNames();
//$dbType = $this->db->driverName;
//$tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
//$tableOptions_mssql = "";
//$tableOptions_pgsql = "";
//$tableOptions_sqlite = "";
///* MYSQL */
//if (!in_array('products', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%products}}', [
//		'productcode' => 'INT(11) NOT NULL',
//		0 => 'PRIMARY KEY (`productcode`)',
//		'barcode' => 'VARCHAR(128) NULL',
//		'productname' => 'VARCHAR(145) NOT NULL',
//		'partnumber' => 'VARCHAR(45) NULL',
//		'isdiscont' => 'TINYINT(1) NULL',
//		'istockitem' => 'TINYINT(1) NULL',
//		'isproditem' => 'TINYINT(1) NULL DEFAULT \'0\'',
//		'unitcost' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodrprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodwprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodcprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'uomcode' => 'INT(11) NULL DEFAULT \'0\'',
//		'openingstock' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtysupplied' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyissued' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtysold' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'salereturn' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreturn' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'adjustment' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyondeposit' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyonorder' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyavailable' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'instock' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reorderlevel' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reorderqty' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'value' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'backorder' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'orderbalance' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'stockcount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'taxratecode' => 'VARCHAR(3) NULL DEFAULT \'0\'',
//		'stockdiff' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'stockcategorycode' => 'INT(11) NULL DEFAULT \'0\'',
//		'cfactor' => 'INT(11) NULL DEFAULT \'1\'',
//		'id' => 'INT(10) UNSIGNED NULL',
//		'unitpackaging' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'productcode2' => 'VARCHAR(45) NULL',
//		'qtyreturnin' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtytransferout' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtytransferin' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreturnout' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'suppliercode' => 'VARCHAR(45) NULL',
//		'glsales' => 'VARCHAR(45) NULL',
//		'glcogs' => 'VARCHAR(45) NULL',
//		'glpurchases' => 'VARCHAR(45) NULL',
//		'lastdate' => 'DATE NULL',
//		'glaccountreceivable' => 'VARCHAR(11) NULL DEFAULT \'0\'',
//		'glcustomerdeposits' => 'VARCHAR(11) NULL DEFAULT \'0\'',
//		'categoryid' => 'INT(11) NULL DEFAULT \'0\'',
//		'subcategoryid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'typeid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'status' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'parentid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('productdetails', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%productdetails}}', [
//		'productcode' => 'INT(11) NOT NULL',
//		0 => 'PRIMARY KEY (`productcode`)',
//		'barcode' => 'VARCHAR(128) NULL',
//		'partnumber' => 'VARCHAR(45) NULL',
//		'isdiscont' => 'TINYINT(1) NULL DEFAULT \'0\'',
//		'istockitem' => 'TINYINT(1) NULL DEFAULT \'1\'',
//		'isproditem' => 'TINYINT(1) NULL DEFAULT \'0\'',
//		'deptcode' => 'TINYINT(1) NOT NULL',
//		6 => 'KEY (`deptcode`)',
//		'unitcost' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodrprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodwprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodcprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'uomcode' => 'INT(11) NULL DEFAULT \'0\'',
//		'openingstock' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtysupplied' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyissued' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtysold' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'salereturn' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreturn' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'adjustment' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyondeposit' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyonorder' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyavailable' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'instock' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reorderlevel' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reorderqty' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'value' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'backorder' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'orderbalance' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'stockcount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'taxratecode' => 'VARCHAR(3) NULL DEFAULT \'0\'',
//		'stockdiff' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'stockcategorycode' => 'INT(11) NULL DEFAULT \'0\'',
//		'cfactor' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'id' => 'INT(10) UNSIGNED NULL',
//		'unitpackaging' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'productcode2' => 'VARCHAR(45) NULL',
//		'qtyreturnin' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtytransferout' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtytransferin' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreturnout' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'suppliercode' => 'VARCHAR(45) NULL',
//		'glsales' => 'VARCHAR(45) NULL',
//		'glcogs' => 'VARCHAR(45) NULL',
//		'glpurchases' => 'VARCHAR(45) NULL',
//		'lastdate' => 'DATE NULL',
//		'parentid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'status' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'qtyunaccounted' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreplaced' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('producttransactions', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%producttransactions}}', [
//		'productcode' => 'INT(11) NULL DEFAULT \'0\'',
//		'productname' => 'VARCHAR(45) NULL',
//		'partnumber' => 'VARCHAR(45) NULL',
//		'isdiscont' => 'VARCHAR(45) NULL DEFAULT \'0\'',
//		'istockitem' => 'VARCHAR(45) NULL DEFAULT \'0\'',
//		'isproditem' => 'VARCHAR(45) NULL DEFAULT \'0\'',
//		'unitcost' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodrprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodwprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'prodcprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'uomcode' => 'VARCHAR(45) NULL DEFAULT \'0\'',
//		'openingstock' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtysupplied' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyissued' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtysold' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'salereturn' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreturn' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'adjustment' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyondeposit' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyonorder' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'orderbalance' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyavailable' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'instock' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reorderlevel' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reorderqty' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'value' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'backorder' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'stockcount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'taxratecode' => 'VARCHAR(45) NULL DEFAULT \'0\'',
//		'stockdiff' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'stockcategorycode' => 'INT(10) UNSIGNED NULL DEFAULT \'0\'',
//		'vatrate' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//		'suppliercode' => 'VARCHAR(45) NULL',
//		'invoicesamount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'goodsamount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'docno' => 'VARCHAR(45) NULL',
//		'doctype' => 'VARCHAR(45) NULL',
//		'amount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'vatamount' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'usercode' => 'VARCHAR(45) NULL',
//		'date' => 'DATE NULL',
//		'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		41 => 'PRIMARY KEY (`id`)',
//		'qtyreturnin' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtytransferout' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtytransferin' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'departmentcode' => 'VARCHAR(45) NULL',
//		'salepersoncode' => 'VARCHAR(45) NULL',
//		'customercode' => 'VARCHAR(45) NULL',
//		'qtymade' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtypacked' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'shiftnumber' => 'VARCHAR(45) NULL',
//		'startserial' => 'VARCHAR(64) NULL',
//		'endserial' => 'VARCHAR(64) NULL',
//		'adjustmentcode' => 'VARCHAR(45) NULL',
//		'timestamp' => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ',
//		'projectid' => 'VARCHAR(4) NULL',
//		'description' => 'TEXT NULL',
//		'deptcode' => 'INT(11) NULL DEFAULT \'0\'',
//		'tillno' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//		'cauditnumber' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//		'parentid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'status' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'qtyunaccounted' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'qtyreplaced' => 'DOUBLE(25,5) NULL DEFAULT \'0\'',
//		'reference' => 'VARCHAR(50) NOT NULL DEFAULT \'\'',
//		'creference2' => 'VARCHAR(50) NOT NULL DEFAULT \'\'',
//		'orderno' => 'VARCHAR(50) NOT NULL DEFAULT \'\'',
//		'productcode1' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'productcode2' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'productcode3' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'productcode4' => 'INT(11) NOT NULL DEFAULT \'0\'',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('refgroups', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%refgroups}}', [
//		'refgroupid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`refgroupid`)',
//		'refgroupname' => 'VARCHAR(45) NOT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('stockcategory', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%stockcategory}}', [
//		'categoryid' => 'INT(10) NOT NULL DEFAULT \'0\'',
//		'parentid' => 'INT(11) NULL DEFAULT \'0\'',
//		'subcategoryid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'typeid' => 'INT(11) NOT NULL DEFAULT \'0\'',
//		'name' => 'VARCHAR(50) NULL',
//		'glaccountno' => 'INT(11) NULL',
//		'startcode' => 'INT(11) NULL DEFAULT \'0\'',
//		'id' => 'INT(10) NOT NULL AUTO_INCREMENT',
//		7 => 'PRIMARY KEY (`id`)',
//		'glsales' => 'VARCHAR(45) NULL',
//		'glcogs' => 'VARCHAR(45) NULL',
//		'glpurchases' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('reference_table', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%reference_table}}', [
//		'id' => 'INT(11) NOT NULL',
//		0 => 'PRIMARY KEY (`id`)',
//		'refname' => 'VARCHAR(45) NULL',
//		'refgroupid' => 'INT(11) NULL',
//	], $tableOptions_mysql);
//}
//}
//$this->dropPrimaryKey("productcode",'productdetails') ;
//$this->addPrimaryKey('productdetails_pk', 'productdetails', ['productcode', 'deptcode']);
// 
//$this->execute('SET foreign_key_checks = 0');
//$this->insert('{{%refgroups}}',['refgroupid'=>'1','refgroupname'=>'Main Group']);
//$this->insert('{{%stockcategory}}',['categoryid'=>'1','parentid'=>'0','subcategoryid'=>'0','typeid'=>'0','name'=>'Not Applicable','glaccountno'=>'','startcode'=>'1093','id'=>'1','glsales'=>'40000','glcogs'=>'50000','glpurchases'=>'12000']);
//$this->insert('{{%stockcategory}}',['categoryid'=>'2','parentid'=>'0','subcategoryid'=>'0','typeid'=>'0','name'=>'Others','glaccountno'=>'','startcode'=>'2066','id'=>'2','glsales'=>'40200','glcogs'=>'50500','glpurchases'=>'12050']);
//$this->insert('{{%reference_table}}',['id'=>'1','refname'=>'Others','refgroupid'=>'1']);
//$this->execute('SET foreign_key_checks = 1;');
//

    }

    public function down()
    {
        echo "m160705_093751_products cannot be reverted.\n";
$this->execute('SET foreign_key_checks = 0');
$this->execute('DROP TABLE IF EXISTS `products`');
$this->execute('SET foreign_key_checks = 1;');
$this->execute('SET foreign_key_checks = 0');
$this->execute('DROP TABLE IF EXISTS `productdetails`');
$this->execute('SET foreign_key_checks = 1;');
$this->execute('SET foreign_key_checks = 0');
$this->execute('DROP TABLE IF EXISTS `producttransactions`');
$this->execute('SET foreign_key_checks = 1;');
$this->execute('SET foreign_key_checks = 0');
$this->execute('DROP TABLE IF EXISTS `refgroups`');
$this->execute('SET foreign_key_checks = 1;');
$this->execute('SET foreign_key_checks = 0');
$this->execute('DROP TABLE IF EXISTS `stockcategory`');
$this->execute('SET foreign_key_checks = 1;');
$this->execute('SET foreign_key_checks = 0');
$this->execute('DROP TABLE IF EXISTS `reference_table`');
$this->execute('SET foreign_key_checks = 1;');
        return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
