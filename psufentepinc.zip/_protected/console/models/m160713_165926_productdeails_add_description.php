<?php

use yii\db\Migration;

class m160713_165926_productdeails_add_description extends Migration {

    public function up() {
//        $this->addColumn("productdetails", "description", "text");
    }

    public function down() {
        echo "m160713_165926_productdeails_add_description cannot be reverted.\n";
        $this->dropColumn("productdetails", "description");
        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
