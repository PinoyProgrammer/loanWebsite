<?php

use yii\db\Migration;

class m160705_105131_qoutations extends Migration {

    public function up() {
//        $tables = Yii::$app->db->schema->getTableNames();
//        $dbType = $this->db->driverName;
//        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
//        $tableOptions_mssql = "";
//        $tableOptions_pgsql = "";
//        $tableOptions_sqlite = "";
//        /* MYSQL */
//        if (!in_array('quotations', $tables)) {
//            if ($dbType == "mysql") {
//                $this->createTable('{{%quotations}}', [
//                    'id' => 'INT(4) NOT NULL AUTO_INCREMENT',
//                    0 => 'PRIMARY KEY (`id`)',
//                    'date' => 'DATE NULL',
//                    'docno' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'doctype' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'custcode' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'projectid' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'contactperson' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'suppliercode' => 'VARCHAR(64) NULL DEFAULT \'\'',
//                    'terms' => 'TEXT NULL',
//                    'remarks' => 'TEXT NULL',
//                    'totalamount' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'preparedby' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'approvedby' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'status' => 'VARCHAR(1) NOT NULL DEFAULT \'\'',
//                    'deptcode' => 'VARCHAR(1) NOT NULL DEFAULT \'0\'',
//                        ], $tableOptions_mysql);
//            }
//        }
//
//        /* MYSQL */
//        if (!in_array('quotationitems', $tables)) {
//            if ($dbType == "mysql") {
//                $this->createTable('{{%quotationitems}}', [
//                    'id' => 'INT(4) NOT NULL AUTO_INCREMENT',
//                    0 => 'PRIMARY KEY (`id`)',
//                    'docno' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'doctype' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'productcode' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'projectid' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'description' => 'TEXT NULL',
//                    'partnumber' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//                    'qty' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'quoteprice' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'goodmount' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'vatamount' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'vatrate' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'totalamount' => 'DOUBLE(25,2) NULL DEFAULT \'0\'',
//                    'date' => 'DATE NULL',
//                    'deptcode' => 'VARCHAR(1) NOT NULL DEFAULT \'0\'',
//                        ], $tableOptions_mysql);
//            }
//        }
    }

    public function down() {
        echo "m160705_105131_qoutations cannot be reverted.\n";
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `quotations`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `quotationitems`');
        $this->execute('SET foreign_key_checks = 1;');
        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
