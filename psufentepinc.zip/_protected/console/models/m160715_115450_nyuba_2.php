<?php

use yii\db\Migration;

class m160715_115450_nyuba_2 extends Migration {

    public function up() {
        
//        $this->addColumn("{{%glaccount}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%suites}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%rentreturns}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%expenses}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%county}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%currency}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%interestmethod}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%taxrates}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%accessibilitymethods}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%depreciationmethod}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%idtypes}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%billingcontrol}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%billableitems}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%expensetype}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%customer}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%titles}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%baddebts}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%tenanttransactions}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%glatransactions}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%paymentmethod}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%bank}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%building}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%assets}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%country}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%summary}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%floors}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%assetcategory}}", "company_id", "integer not null default 0");
//        $this->addColumn("{{%approvedreasons}}", "company_id", "integer not null default 0");
//    
        
    }

    public function down() {
        echo "m160715_115450_nyuba_2 cannot be reverted.\n";

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
