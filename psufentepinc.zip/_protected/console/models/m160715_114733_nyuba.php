<?php

use yii\db\Migration;

class m160715_114733_nyuba extends Migration {

    public function up() {


//$tables = Yii::$app->db->schema->getTableNames();
//$dbType = $this->db->driverName;
//$tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
//$tableOptions_mssql = "";
//$tableOptions_pgsql = "";
//$tableOptions_sqlite = "";
///* MYSQL */
//if (!in_array('landlords', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%landlords}}', [
//		'landlordid' => 'INT(128) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`landlordid`)',
//		'landlordname' => 'VARCHAR(128) NULL',
//		'bankcode' => 'VARCHAR(10) NULL',
//		'commissionrate' => 'DOUBLE(25,5) NULL',
//		'bfwd' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'deposits' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'rent' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'servicecharges' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'monthlyrate' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'utilitypaid' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'commissionamount' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'netamount' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'remmitances' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,5) NULL DEFAULT 0',
//		'glincome' => 'VARCHAR(10) NULL',
//		'glcommission' => 'VARCHAR(10) NULL',
//		'advancethreshold' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'interestonadvance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'interestrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('landlordtransactions', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%landlordtransactions}}', [
//		'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'landlordid' => 'INT(11) NOT NULL',
//		'buildingid' => 'INT(11) NOT NULL',
//		'date' => 'DATE NULL',
//		'docno' => 'VARCHAR(45) NULL',
//		'doctype' => 'VARCHAR(45) NULL',
//		'usercode' => 'VARCHAR(45) NULL',
//		'narration' => 'VARCHAR(100) NULL',
//		'amount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'userid' => 'INT(11) NOT NULL DEFAULT 0',
//		'timestamp' => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('glaccount', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%glaccount}}', [
//		'glaccounttype' => 'INT(10) NULL',
//		'glaccountname' => 'VARCHAR(90) NULL',
//		'currency' => 'VARCHAR(45) NULL',
//		'taxratecode' => 'VARCHAR(3) NULL',
//		'bfwd' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'debit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'credit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'glaccountno' => 'INT(10) NOT NULL',
//		8 => 'PRIMARY KEY (`glaccountno`)',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('suites', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%suites}}', [
//		'buildingid' => 'INT(11) NOT NULL',
//		0 => 'PRIMARY KEY (`buildingid`)',
//		'suitenumber' => 'VARCHAR(45) NOT NULL',
//		1 => 'KEY (`suitenumber`)',
//		'suitename' => 'VARCHAR(45) NULL',
//		'taxrate' => 'VARCHAR(45) NULL',
//		'deposit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'rent' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'servicecharges' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'montlyrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'currenttenant' => 'VARCHAR(45) NULL',
//		'dateoccupied' => 'DATE NULL',
//		'datevacated' => 'DATE NULL',
//		'occupancystatus' => 'VARCHAR(45) NULL',
//		'glaccountreceivable' => 'VARCHAR(45) NULL',
//		'glcustomersdeposits' => 'VARCHAR(45) NULL',
//		'glincome' => 'VARCHAR(45) NULL',
//		'glpenalty' => 'VARCHAR(45) NULL',
//		'dueday' => 'INT(11) NULL DEFAULT 0',
//		'tenantid' => 'VARCHAR(45) NULL',
//		'contractstartdate' => 'DATE NULL',
//		'contractenddate' => 'DATE NULL',
//		'contractduration' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'commissionrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'commissionamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'penaltyrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'penaltyamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'incharge' => 'VARCHAR(45) NULL DEFAULT \'0.00\'',
//		'glcommission' => 'VARCHAR(10) NULL',
//		'suiteid' => 'INT(11) NOT NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('rentreturns', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%rentreturns}}', [
//		'returnid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//                0 => 'PRIMARY KEY (`returnid`)',
//		'buildingid' => 'VARCHAR(45) NOT NULL',
//		'suitenumber' => 'VARCHAR(45) NOT NULL',
//		'landlordid' => 'VARCHAR(45) NULL',
//		'tenantid' => 'VARCHAR(45) NULL',
//		'currenttenant' => 'VARCHAR(45) NULL',
//		'deposit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'rent' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'servicecharges' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'montlyrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'bfwd' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'invoiceytd' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'creditnotesytd' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'jan' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'feb' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'mar' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'apr' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'may' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'jun' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'jul' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'aug' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'sep' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'oct' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'nov' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'dece' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'receiptsytd' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'penaltyamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'currentreceipts' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'depositrefund' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'commissionrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'currentcommissionamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'utilitypaid' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'duetolandlord' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'paidtolandlord' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balanceduetolandlord' => 'DOUBLE(25,2) NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('expenses', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%expenses}}', [
//		'date' => 'DATE NULL',
//		'docno' => 'VARCHAR(45) NULL',
//		'doctype' => 'VARCHAR(45) NULL',
//		'amount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'narration' => 'VARCHAR(45) NULL',
//		'glaccount' => 'VARCHAR(45) NULL DEFAULT 0',
//		'typename' => 'VARCHAR(45) NULL',
//		'note' => 'VARCHAR(45) NULL',
//		'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		8 => 'PRIMARY KEY (`id`)',
//		'shiftnumber' => 'VARCHAR(4) NULL',
//		'deptcode' => 'INT(1) NOT NULL DEFAULT 0',
//		'cauditnumber' => 'VARCHAR(20) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('county', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%county}}', [
//		'code' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`code`)',
//		'name' => 'VARCHAR(45) NOT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('currency', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%currency}}', [
//		'currencyid' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`currencyid`)',
//		'currencyname' => 'VARCHAR(45) NULL',
//		'currencysymbol' => 'VARCHAR(45) NULL',
//		'exchangerate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'ishomecurrency' => 'TINYINT(1) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('interestmethod', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%interestmethod}}', [
//		'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'name' => 'VARCHAR(45) NOT NULL',
//		'calculation' => 'VARCHAR(45) NOT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('taxrates', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%taxrates}}', [
//		'taxratecode' => 'VARCHAR(3) NOT NULL',
//		0 => 'PRIMARY KEY (`taxratecode`)',
//		'taxratename' => 'VARCHAR(45) NULL',
//		'invat' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'outvat' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'rates' => 'VARCHAR(45) NOT NULL',
//		'glaccountno' => 'INT(11) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('accessibilitymethods', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%accessibilitymethods}}', [
//		'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'method' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('depreciationmethod', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%depreciationmethod}}', [
//		'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'name' => 'VARCHAR(45) NOT NULL',
//		'calculation' => 'VARCHAR(45) NOT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('idtypes', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%idtypes}}', [
//		'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'idtypename' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('billingcontrol', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%billingcontrol}}', [
//		'lastbilldate' => 'DATE NULL',
//		'billmonth' => 'VARCHAR(45) NULL',
//		'buildingid' => 'VARCHAR(45) NULL',
//		'buildingid2' => 'VARCHAR(45) NULL',
//		'billmonth2' => 'VARCHAR(45) NULL',
//		'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		5 => 'PRIMARY KEY (`id`)',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('billableitems', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%billableitems}}', [
//		'itemid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`itemid`)',
//		'itemname' => 'VARCHAR(45) NULL',
//		'rate' => 'VARCHAR(45) NULL',
//		'glaccountno' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('expensetype', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%expensetype}}', [
//		'code' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`code`)',
//		'typename' => 'VARCHAR(50) NULL',
//		'glaccountnumber' => 'VARCHAR(45) NULL',
//		'taxratecode' => 'VARCHAR(4) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('customer', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%customer}}', [
//		'custcode' => 'VARCHAR(10) NOT NULL',
//		0 => 'PRIMARY KEY (`custcode`)',
//		'name' => 'VARCHAR(64) NULL',
//		'phone' => 'VARCHAR(64) NULL',
//		'email' => 'VARCHAR(64) NULL',
//		'national_id' => 'VARCHAR(64) NULL',
//		'postaladdress' => 'VARCHAR(64) NULL',
//		'mobilephone' => 'VARCHAR(64) NULL',
//		'location' => 'VARCHAR(64) NULL',
//		'isactive' => 'TINYINT(1) NULL DEFAULT 0',
//		'balancebf' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'salesamt' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'salesreturnsamt' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'orderbalance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'saleorders' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'paymentamt' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'adjustments' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'creditstatus' => 'VARCHAR(4) NULL DEFAULT \'No\'',
//		'creditlimit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'town' => 'VARCHAR(64) NULL',
//		'website' => 'VARCHAR(64) NULL',
//		'contactperson' => 'VARCHAR(64) NULL',
//		'pinnumber' => 'VARCHAR(64) NULL',
//		'datecreated' => 'DATE NULL',
//		'glaccountno' => 'INT(10) NULL',
//		'glaccountreceivable' => 'VARCHAR(45) NULL',
//		'glcustomerdeposits' => 'VARCHAR(45) NULL',
//		'iscontract' => 'VARCHAR(4) NULL',
//		'contractperiods' => 'VARCHAR(45) NULL',
//		'contractamount' => 'DOUBLE(25,2) NULL',
//		'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		30 => 'KEY (`id`)',
//		'headoffice' => 'VARCHAR(10) NULL DEFAULT 0',
//		'deptcode' => 'VARCHAR(1) NOT NULL DEFAULT 0',
//		'custtype' => 'VARCHAR(1) NULL DEFAULT 0',
//		'regionid' => 'INT(10) NOT NULL DEFAULT 0',
//		'nextinvoicedate' => 'DATE NULL',
//		'lastinvoicedate' => 'DATE NULL',
//		'productcode' => 'VARCHAR(228) NULL',
//		'intervalperiod' => 'INT(11) NOT NULL DEFAULT 0',
//		'vatnumber' => 'VARCHAR(50) NOT NULL DEFAULT 0',
//		'idnumber' => 'VARCHAR(50) NOT NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('titles', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%titles}}', [
//		'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'name' => 'VARCHAR(45) NOT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('baddebts', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%baddebts}}', [
//		'transactionid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`transactionid`)',
//		'date' => 'DATE NULL',
//		'tenantid' => 'VARCHAR(45) NULL',
//		'tenantname' => 'VARCHAR(45) NULL',
//		'buildingid' => 'VARCHAR(45) NULL',
//		'suitenumber' => 'VARCHAR(45) NULL',
//		'deposit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'amount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'particulars' => 'VARCHAR(45) NULL',
//		'arrears' => 'DOUBLE NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('tenanttransactions', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%tenanttransactions}}', [
//		'transactionid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`transactionid`)',
//		'date' => 'DATE NULL',
//		'doctype' => 'VARCHAR(45) NULL',
//		'docno' => 'VARCHAR(45) NULL',
//		'tenantid' => 'VARCHAR(45) NULL',
//		'tenantname' => 'VARCHAR(45) NULL',
//		'buildingid' => 'VARCHAR(45) NULL',
//		'suitenumber' => 'VARCHAR(45) NULL',
//		'amount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'netamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'taxamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'particulars' => 'VARCHAR(45) NULL',
//		'timestamp' => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ',
//		'ref2' => 'VARCHAR(45) NULL',
//		'callocs' => 'TEXT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('unittypes', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%unittypes}}', [
//		'unittypeid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`unittypeid`)',
//		'unittypename' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('glatransactions', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%glatransactions}}', [
//		'transcode' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`transcode`)',
//		'glaaccountcode' => 'VARCHAR(45) NULL',
//		'docno' => 'VARCHAR(45) NULL',
//		'doctype' => 'VARCHAR(45) NULL',
//		'credit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'debit' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'narration' => 'TEXT NULL',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'user' => 'VARCHAR(45) NULL',
//		'date' => 'DATE NULL',
//		'glaccountno' => 'INT(10) NOT NULL',
//		'glaccountname' => 'VARCHAR(45) NULL',
//		'glaccounttype' => 'VARCHAR(45) NULL',
//		'currency' => 'VARCHAR(45) NULL',
//		'taxratecode' => 'VARCHAR(3) NULL',
//		'timestamp' => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ',
//		'deptcode' => 'INT(11) NULL DEFAULT 0',
//		'cauditnumber' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('paymentmethod', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%paymentmethod}}', [
//		'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'name' => 'VARCHAR(45) NOT NULL',
//		'glaccountno' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('bank', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%bank}}', [
//		'bankcode' => 'VARCHAR(10) NOT NULL',
//		0 => 'PRIMARY KEY (`bankcode`)',
//		'bankname' => 'VARCHAR(50) NOT NULL',
//		'creditamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'debitamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balance' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'balancecf' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'id' => 'INT(10) UNSIGNED NOT NULL',
//		'glaccountno' => 'VARCHAR(60) NULL',
//		'accounttype' => 'VARCHAR(64) NOT NULL DEFAULT \'\'',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('building', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%building}}', [
//		'buildingid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`buildingid`)',
//		'buildingname' => 'VARCHAR(45) NULL',
//		'landlordid' => 'INT(128) NULL DEFAULT 0',
//		'noofunits' => 'INT(11) NULL DEFAULT 0',
//		'unittypeid' => 'VARCHAR(45) NULL',
//		'dueday' => 'INT(11) NULL DEFAULT 0',
//		'location' => 'VARCHAR(45) NULL',
//		'lrno' => 'VARCHAR(45) NULL',
//		'deposits' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'rents' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'servicecharge' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'caretaker' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('assets', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%assets}}', [
//		'assetid' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`assetid`)',
//		'categorycode' => 'VARCHAR(50) NULL',
//		'assetname' => 'VARCHAR(256) NULL',
//		'department' => 'VARCHAR(45) NULL',
//		'serialno' => 'VARCHAR(128) NULL',
//		'suppliercode' => 'VARCHAR(45) NULL',
//		'dateofpurchase' => 'DATE NULL',
//		'lastdate' => 'DATE NULL',
//		'agetodate' => 'INT(4) NULL',
//		'assetlife' => 'VARCHAR(45) NULL',
//		'depreciationmethodname' => 'VARCHAR(45) NULL',
//		'depreciationrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'cost' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'accumulateddepreciation' => 'DOUBLE(25,2) NULL',
//		'bookvalue' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'glasset' => 'INT(10) NULL DEFAULT 0',
//		'gldeprecexpense' => 'INT(10) NULL DEFAULT 0',
//		'glaccumdepreciation' => 'INT(10) NULL DEFAULT 0',
//		'depreciationmethodid' => 'INT(10) NULL DEFAULT 0',
//		'departmentcode' => 'INT(10) NULL DEFAULT 0',
//		'glassetdisposal' => 'INT(10) NULL DEFAULT 0',
//		'quantity' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'residuevalue' => 'DOUBLE(25,2) NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('country', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%country}}', [
//		'countrycode' => 'VARCHAR(11) NOT NULL',
//		0 => 'PRIMARY KEY (`countrycode`)',
//		'countryname' => 'VARCHAR(45) NULL',
//		'nationality' => 'VARCHAR(45) NULL DEFAULT \'\'',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('summary', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%summary}}', [
//		'date' => 'DATE NOT NULL',
//		0 => 'PRIMARY KEY (`date`)',
//		'shiftno' => 'INT(10) UNSIGNED NOT NULL',
//		1 => 'KEY (`shiftno`)',
//		'grosssale' => 'DOUBLE(25,2) NULL',
//		'discounts' => 'DOUBLE NULL',
//		'creditsales' => 'DOUBLE(25,2) NULL',
//		'cashsales' => 'DOUBLE(25,2) NULL',
//		'costofsales' => 'DOUBLE(25,2) NULL',
//		'grossprofit' => 'DOUBLE(25,2) NULL',
//		'debtpaid' => 'DOUBLE(25,2) NULL',
//		'depositsreceived' => 'DOUBLE(25,2) NULL',
//		'expensespaid' => 'DOUBLE(25,2) NULL',
//		'staffallowances' => 'DOUBLE NULL',
//		'bankdeposit' => 'DOUBLE(25,2) NULL',
//		'expectedcash' => 'DOUBLE(25,2) NULL',
//		'cashinhand' => 'DOUBLE(25,2) NULL',
//		'shortorexcess' => 'DOUBLE(25,2) NULL',
//		'cashiercode' => 'VARCHAR(60) NULL',
//		'bankwithdrawal' => 'DOUBLE(25,2) NULL',
//		'supplierpayment' => 'DOUBLE(25,2) NULL',
//		'totalcashin' => 'DOUBLE(25,2) NULL',
//		'totalcashout' => 'DOUBLE(25,2) NULL',
//		'summary' => 'DOUBLE(25,2) NULL',
//		'departmentreceipts' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'shiftnumber' => 'VARCHAR(4) NULL DEFAULT \'1\'',
//		'bfwd' => 'DOUBLE(25,2) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('floors', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%floors}}', [
//		'floorno' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`floorno`)',
//		'floorname' => 'VARCHAR(45) NULL',
//		'accessibility' => 'VARCHAR(45) NULL',
//		'noofrooms' => 'INT(8) NULL',
//		'roomtypes' => 'VARCHAR(45) NULL',
//		'location' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('assetcategory', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%assetcategory}}', [
//		'categoryname' => 'VARCHAR(256) NULL',
//		'depreciationmethodname' => 'VARCHAR(64) NULL',
//		'depreciationmethodrate' => 'DOUBLE NULL',
//		'glasset' => 'INT(10) NULL',
//		'gldepreciationexpense' => 'INT(10) NULL',
//		'glaccumdepreciation' => 'INT(10) NULL DEFAULT 0',
//		'depreciationmethodid' => 'INT(10) NULL',
//		'glassetdisposal' => 'INT(10) NULL',
//		'assetlife' => 'DOUBLE(25,2) NULL',
//		'categorycode' => 'INT(8) NOT NULL AUTO_INCREMENT',
//		9 => 'PRIMARY KEY (`categorycode`)',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('approvedreasons', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%approvedreasons}}', [
//		'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
//		0 => 'PRIMARY KEY (`id`)',
//		'reasons' => 'VARCHAR(45) NOT NULL',
//	], $tableOptions_mysql);
//}
//}
// 
///* MYSQL */
//if (!in_array('tenants', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%tenants}}', [
//		'tenantid' => 'INT(11) NOT NULL',
//		0 => 'PRIMARY KEY (`tenantid`)',
//		'tenantname' => 'VARCHAR(45) NULL',
//		'idtype' => 'VARCHAR(45) NULL',
//		'idnumber' => 'VARCHAR(45) NULL',
//		'address' => 'TEXT NULL',
//		'telephone' => 'VARCHAR(45) NULL',
//		'employer' => 'VARCHAR(45) NULL',
//		'nextofkinname' => 'VARCHAR(45) NULL',
//		'nextofkinaddress' => 'VARCHAR(45) NULL',
//		'nextofkintel' => 'VARCHAR(45) NULL',
//		'buildingid' => 'INT(11) NULL',
//		'suitenumber' => 'VARCHAR(45) NULL',
//		'dateoccupied' => 'DATE NULL',
//		'datevacated' => 'DATE NULL',
//		'status' => 'VARCHAR(45) NULL',
//		'lastreceiptdate' => 'DATE NULL',
//		'bfwd' => 'DOUBLE(25,2) NULL',
//		'invoices' => 'DOUBLE(25,2) NULL',
//		'receipts' => 'DOUBLE(25,2) NULL',
//		'creditnotes' => 'DOUBLE(25,2) NULL',
//		'arrears' => 'DOUBLE(25,2) NULL',
//		'netamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'taxamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'glaccountreceivable' => 'VARCHAR(45) NULL',
//		'glcustomersdeposits' => 'VARCHAR(45) NULL',
//		'glincome' => 'VARCHAR(45) NULL',
//		'glpenalty' => 'VARCHAR(45) NULL',
//		'penaltyamount' => 'DOUBLE(25,2) NULL DEFAULT 0',
//		'penaltyrate' => 'DOUBLE(25,2) NULL DEFAULT 0',
//	], $tableOptions_mysql);
//}
//}
//if (!in_array('membersbank', $tables))  { 
//if ($dbType == "mysql") {
//	$this->createTable('{{%membersbank}}', [
//		'bankcode' => 'VARCHAR(45) NOT NULL',
//		0 => 'PRIMARY KEY (`bankcode`)',
//		'bankname' => 'VARCHAR(45) NULL',
//		'bankbranch' => 'VARCHAR(45) NULL',
//		'town' => 'VARCHAR(45) NULL',
//		'swiftcode' => 'VARCHAR(45) NULL',
//		'telephone' => 'VARCHAR(45) NULL',
//	], $tableOptions_mysql);
//}
//}
// 
//$this->createIndex('rentreturns_idx_unique', 'rentreturns', ['suitenumber', 'buildingid'],1);
//$this->createIndex('idx_UNIQUE_name_9539_02','county','name',1);
//$this->createIndex('idx_UNIQUE_name_0918_03','titles','name',1);
//$this->createIndex('idx_transcode_134_04','glatransactions','transcode',0);
//$this->createIndex('idx_UNIQUE_reasons_2201_05','approvedreasons','reasons',1);
// 
//$this->execute('SET foreign_key_checks = 0');
//$this->insert('{{%landlords}}',['landlordid'=>'1','landlordname'=>'Watermark','bankcode'=>'E001','commissionrate'=>'0.20000','bfwd'=>'0.00000','deposits'=>'0.00000','rent'=>'-1000.00000','servicecharges'=>'0.00000','monthlyrate'=>'0.00000','utilitypaid'=>'0.00000','commissionamount'=>'2.00000','netamount'=>'-1002.00000','remmitances'=>'0.00000','balance'=>'0.00000','glincome'=>'20000','glcommission'=>'45400','advancethreshold'=>'0.00','interestonadvance'=>'0.00','interestrate'=>'0.00']);
//$this->insert('{{%landlordtransactions}}',['id'=>'1','landlordid'=>'1','buildingid'=>'1','date'=>'2016-07-15','docno'=>'1001','doctype'=>'Rent Receipts','usercode'=>'admin','narration'=>'07/2016','amount'=>'500.00','balance'=>'500.00','userid'=>'0','timestamp'=>'2016-07-15 11:36:15']);
//$this->insert('{{%landlordtransactions}}',['id'=>'2','landlordid'=>'1','buildingid'=>'1','date'=>'2016-07-15','docno'=>'1002','doctype'=>'Payment','usercode'=>'admin','narration'=>'Commission 07/2016','amount'=>'-2.00','balance'=>'0.00','userid'=>'0','timestamp'=>'2016-07-15 11:57:31']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'10','glaccountname'=>'Petty Cash','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'61500.00','credit'=>'414332.00','balance'=>'0.00','glaccountno'=>'10000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'10','glaccountname'=>'Cash In Hand','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'2407753.90','credit'=>'68563.64','balance'=>'0.00','glaccountno'=>'10100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'10','glaccountname'=>'Cash In Hand - Cashier 1','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'10200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'10','glaccountname'=>'Payroll Cash Account','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'10300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'10','glaccountname'=>'Credit/Debit Cards Account','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'10400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'10','glaccountname'=>'Cash In Bank','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'10500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'8','glaccountname'=>'Accounts Receivable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'3800.00','credit'=>'500.00','balance'=>'0.00','glaccountno'=>'11000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'8','glaccountname'=>'Accounts Receivable Service','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'4815.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'11100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'8','glaccountname'=>'Other Receivables','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'11400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'8','glaccountname'=>'Allowance for Doubtful Account','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'11500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Raw Materials-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'3771401.00','credit'=>'4426622.12','balance'=>'0.00','glaccountno'=>'12000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Finished Goods-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'3355.21','credit'=>'1538348.48','balance'=>'0.00','glaccountno'=>'12050']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Rejects-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Others-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12150']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Used Containers-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Books-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12250']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Magazines-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Service Parts-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12350']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'9','glaccountname'=>'Other-Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'12400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'11','glaccountname'=>'Prepaid Expenses','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'14000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'11','glaccountname'=>'Employee Advances','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'14100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'11','glaccountname'=>'Notes Receivable-Current','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'14200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'11','glaccountname'=>'Work in Process','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'14300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'7','glaccountname'=>'Supplier Deposits','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'14400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'11','glaccountname'=>'Other Current Assets','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'14700']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Furniture and Fixtures','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Office Equipments','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Motor Vehicles','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Computer Equipments','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15210']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Other Depreciable Property','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Leasehold Improvements','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Building','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Office Improvements','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'15600']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'4','glaccountname'=>'Land','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'16900']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - Furniture','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - Office Equipmennts','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - Motor Vehicles','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation- Computers','currency'=>'Kenya Shilling','taxratecode'=>'E','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17210']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - Other','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - Leasehol','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - Building','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'5','glaccountname'=>'Accum. Depreciation - office I','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'17600']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'6','glaccountname'=>'Deposits','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'19000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'6','glaccountname'=>'Organization Costs','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'19100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'6','glaccountname'=>'Accum. Amortiz. - Org. Costs','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'19150']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'6','glaccountname'=>'Note Receivable-Noncurrent','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'19200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'6','glaccountname'=>'Other Noncurrent Assets','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'19900']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'13','glaccountname'=>'Accounts Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'413534.00','credit'=>'3174.00','balance'=>'0.00','glaccountno'=>'20000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'0','glaccountname'=>'Inter Departmental Purchases','currency'=>'KES','taxratecode'=>'A','bfwd'=>'0.00','debit'=>'3740569.00','credit'=>'3740569.00','balance'=>'0.00','glaccountno'=>'20100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Accrued Expenses','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Catering Levy Payable','currency'=>'Kenya Shilling','taxratecode'=>'E','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23050']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'VAT/Sales Tax Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'3499.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Wages Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'NSSF Deductions Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'NHIF Deductions Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23301']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'SACCO/WELFARE Deductions','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23302']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'P.A.Y.E Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'23400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Other Taxes Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'24000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Employee Benefits Payable','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'24100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Current Portion Long-Term Debt','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'24200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Customer Deposits','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'24400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Other Current Liabilities','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'24800']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'14','glaccountname'=>'Suspense-Clearing Account','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'24900']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'15','glaccountname'=>'Notes Payable-Noncurrent','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'27000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'15','glaccountname'=>'Deferred Revenue','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'27100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'15','glaccountname'=>'Other Long-Term Liabilities','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'27400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Testing This','currency'=>'Dirham','taxratecode'=>'A','bfwd'=>'2000.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'34500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Testing This','currency'=>'Dirham','taxratecode'=>'A','bfwd'=>'6000.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'34501']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'17','glaccountname'=>'Common Stock','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'39003']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'19','glaccountname'=>'Paid-in Capital','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'39004']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'18','glaccountname'=>'Retained Earnings','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'39005']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'19','glaccountname'=>'Dividends Paid','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'39007']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'16','glaccountname'=>'System Opening Balances','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'64000.00','balance'=>'0.00','glaccountno'=>'39009']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Raw Materials','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'2384768.12','balance'=>'0.00','glaccountno'=>'40000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Rent Income','currency'=>'Kenya Shilling','taxratecode'=>'E','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'40100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Finished Goods','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'40200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Rejects','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'40400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Others','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'40600']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Used Containers','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'40800']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Books','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'41000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Magazines','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'41200']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales-Other Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'41400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Repair Service Income','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'41600']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Interest Income','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'41800']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Other Income','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'42000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Finance Charge Income','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'2.00','balance'=>'0.00','glaccountno'=>'45400']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Shipping Charges Reimbursed','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'45500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales Returns and Allowances','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'48000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'2','glaccountname'=>'Sales Discounts','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'49000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Raw Materials','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'675735.12','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'50000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Finished Goods','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'1538420.94','credit'=>'226989.00','balance'=>'0.00','glaccountno'=>'50500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Rejects','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'51000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Others','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'51500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Used Containers','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'52000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Books','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'52500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Magazines','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'53000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Service Parts','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'53500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Other Inventory','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'54000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Salaries and Wag','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'57000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Freight','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'57500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Cost of Sales-Other','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'58000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Inventory Adjustments','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'4860.00','credit'=>'22704.00','balance'=>'0.00','glaccountno'=>'58500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Purchase Returns and Allowance','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'59000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'3','glaccountname'=>'Purchase Discounts','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'59500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Housekeeping','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'60000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Advertising Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'60100']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Amortization Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'60500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Vehicle Running Expenses','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'61000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Bad Debt Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'61500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Bank Charges','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'62000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Cash Short/Excess','currency'=>'Kenya Shilling','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'62500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Charitable Contributions Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'63000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Web/dev site Hosting','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'63300']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Commissions and Fees Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'63500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Marketing and Promotions','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'63501']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'64000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Dues and Subscriptions Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'64500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Employee Benefit Programs Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'65000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Freight Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'65500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Gifts Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'66000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Income Tax Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'66500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Insurance Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'67000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Interest Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'67500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Laundry and Cleaning Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'68000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Legal and Professional Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'68500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Licenses Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'69000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Maintenance Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Accommodation Rent','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'74.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70001']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Accommodation Utilities','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70002']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Accrued Leave','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70003']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Advertising Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70004']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Air Travel Expense (International)','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70005']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Air Travel Expense (National)','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70006']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Aircraft Sub-Charter Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70007']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Audit And Taxation Fees','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70008']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Bank Charges','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70009']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Casual Staff','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70010']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Commissary','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70011']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Contributions And Donations','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70012']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Credit Charges (Late Payments)','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70013']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Data Processing Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70014']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Aircraft','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70015']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Computers','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70016']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Furniture And Fittings','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70017']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Maint Equipment and Tools','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70018']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Motor Vehicles','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70019']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Radio Equipment','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70020']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Depreciation - Software','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70021']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Description','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70022']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Email And Internet Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70023']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Engineering Consultants','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70024']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Engineering Medical Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70025']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Engineering Salaries And Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70026']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Engineering Staff Sundry Costs','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70027']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Engineering Training','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70028']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Entertainment','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70029']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Executive Salaries And Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70030']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Finance and Admin Medical Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70031']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Finance and Admin Salaries and Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70032']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Finance and Admin Staff Training','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70033']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Finance And Administration Consultants','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70034']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Finance And Administration Sundry Costs','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70035']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'General Insurance','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70036']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'General Licences','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70037']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Hiring Fees','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70038']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Hotel Accommodation And Subsistense','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70039']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Household Equipment (Non-Capital)','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70040']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Household Supplies','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70041']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Interest On Loan','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70042']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Land Travel','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70043']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Legal Fees','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70044']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Mobile Phone Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70045']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Motor Vehicle  Insurance And Licences','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70046']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Motor Vehicle Fuel And Lubricants','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70047']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Motor Vehicle Other Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70048']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Motor Vehicle Repairs And Maintenance','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70049']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Office Equipment Repairs And Maintenance','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70050']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Office Rent','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70051']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Office Repairs And Maintenance','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70052']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Office Utilities','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70053']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Operations Consultants','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70054']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Operations Salaries And Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70055']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Operations Staff Medical Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70056']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Operations Staff Sundry Costs','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70057']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Operations Staff Training','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70058']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Operations Staff Uniforms','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70059']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Other Professional Fees','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70060']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Outstation Office Rent','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70061']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Outstation Office Sundry Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70062']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Outstation Staff Salaries And Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70063']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Postage And Courier Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70064']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Pre-Operation Costs','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70065']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Printing And Stationery','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70066']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Profit','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70067']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Profit and Loss','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70068']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Promotional Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70069']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Route Costs','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70070']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sales ,Marketing and Reservations Sundry','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70071']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sales, Marketing and Res Consultants','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70072']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sales, Marketing and Reservations Medical','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70073']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sales, Marketing and Reservations Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70074']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sales. Marketing and Reservations Uniforms','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70075']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Security Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70076']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Security Staff Salaries And Wages','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70077']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sundry Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70078']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Sundry Sales And Marketing','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70079']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Telephone And Fax Expenses','currency'=>'','taxratecode'=>'','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70080']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Meals and Entertainment Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'70500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Office Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'71000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Payroll Tax Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'72000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Penalties and Fines Exp','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'72500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Other Taxes','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'73000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Postage Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'73500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Rent or Lease Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'74000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Repairs and Maintenance','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'74500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Supplies Services','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'75500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Telephone Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'76500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Salaries Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'77000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Wages Expense','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'77500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Utilities-Elec/water','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'78000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Printing and Stationery','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'78500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>' Miscellaneous [Unspecified]','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'89000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Purchase Disc-Expense Items','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'89500']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Gain/Loss on Sale of Assets','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'90000']);
//$this->insert('{{%glaccount}}',['glaccounttype'=>'1','glaccountname'=>'Transport Costs','currency'=>'KES','taxratecode'=>'Z','bfwd'=>'0.00','debit'=>'0.00','credit'=>'0.00','balance'=>'0.00','glaccountno'=>'90500']);
//$this->insert('{{%suites}}',['buildingid'=>'1','suitenumber'=>'01','suitename'=>'Baobab','taxrate'=>'A','deposit'=>'0.00','rent'=>'0.00','servicecharges'=>'0.00','montlyrate'=>'0.00','currenttenant'=>'Fly540','dateoccupied'=>'2016-07-15','datevacated'=>'2016-07-15','occupancystatus'=>'Occupied','glaccountreceivable'=>'11000','glcustomersdeposits'=>'23050','glincome'=>'20000','glpenalty'=>'45400','dueday'=>'15','tenantid'=>'1','contractstartdate'=>'2016-07-15','contractenddate'=>'2016-07-15','contractduration'=>'0.00','commissionrate'=>'0.00','commissionamount'=>'0.00','penaltyrate'=>'0.00','penaltyamount'=>'0.00','incharge'=>'-1','glcommission'=>'','suiteid'=>'0']);
//$this->insert('{{%rentreturns}}',['returnid'=>'1','buildingid'=>'1','suitenumber'=>'01','landlordid'=>'1','tenantid'=>'1','currenttenant'=>'Fly540','deposit'=>'0.00','rent'=>'0.00','servicecharges'=>'0.00','montlyrate'=>'0.00','bfwd'=>'3000.00','invoiceytd'=>'3800.00','creditnotesytd'=>'0.00','jan'=>'0.00','feb'=>'0.00','mar'=>'0.00','apr'=>'0.00','may'=>'0.00','jun'=>'0.00','jul'=>'-1000.00','aug'=>'0.00','sep'=>'0.00','oct'=>'0.00','nov'=>'0.00','dece'=>'0.00','receiptsytd'=>'-1000.00','balance'=>'2800.00','penaltyamount'=>'0.00','currentreceipts'=>'-1000.00','depositrefund'=>'0.00','commissionrate'=>'0.00','currentcommissionamount'=>'-2.00','utilitypaid'=>'0.00','duetolandlord'=>'0.00','paidtolandlord'=>'0.00','balanceduetolandlord'=>'0.00']);
//$this->insert('{{%expenses}}',['date'=>'2016-07-15','docno'=>'1000','doctype'=>'Expense Invoice','amount'=>'74.00','narration'=>'Cash Purchases','glaccount'=>'70001','typename'=>'Accommodation Rent','note'=>'1','id'=>'1','shiftnumber'=>'1','deptcode'=>'0','cauditnumber'=>'PI1468572320528']);
//$this->insert('{{%county}}',['code'=>'1','name'=>'Baringo County']);
//$this->insert('{{%county}}',['code'=>'2','name'=>'Bomet County']);
//$this->insert('{{%county}}',['code'=>'3','name'=>'Bungoma County']);
//$this->insert('{{%county}}',['code'=>'4','name'=>'Busia County']);
//$this->insert('{{%county}}',['code'=>'5','name'=>'Elgeyo/Marakwet County']);
//$this->insert('{{%county}}',['code'=>'6','name'=>'Embu County']);
//$this->insert('{{%county}}',['code'=>'7','name'=>'Garissa County']);
//$this->insert('{{%county}}',['code'=>'8','name'=>'Homa Bay County']);
//$this->insert('{{%county}}',['code'=>'9','name'=>'Isiolo County']);
//$this->insert('{{%county}}',['code'=>'10','name'=>'Kajiado County']);
//$this->insert('{{%county}}',['code'=>'11','name'=>'Kakamega County']);
//$this->insert('{{%county}}',['code'=>'12','name'=>'Kericho County']);
//$this->insert('{{%county}}',['code'=>'13','name'=>'Kiambu County']);
//$this->insert('{{%county}}',['code'=>'14','name'=>'Kilifi County']);
//$this->insert('{{%county}}',['code'=>'15','name'=>'Kirinyaga County']);
//$this->insert('{{%county}}',['code'=>'16','name'=>'Kisii County']);
//$this->insert('{{%county}}',['code'=>'17','name'=>'Kisumu County']);
//$this->insert('{{%county}}',['code'=>'18','name'=>'Kitui County']);
//$this->insert('{{%county}}',['code'=>'19','name'=>'Kwale County']);
//$this->insert('{{%county}}',['code'=>'20','name'=>'Laikipia County']);
//$this->insert('{{%county}}',['code'=>'21','name'=>'Lamu County']);
//$this->insert('{{%county}}',['code'=>'22','name'=>'Machakos County']);
//$this->insert('{{%county}}',['code'=>'23','name'=>'Makueni County']);
//$this->insert('{{%county}}',['code'=>'24','name'=>'Mandera County']);
//$this->insert('{{%county}}',['code'=>'25','name'=>'Marsabit County']);
//$this->insert('{{%county}}',['code'=>'26','name'=>'Meru County']);
//$this->insert('{{%county}}',['code'=>'27','name'=>'Migori County']);
//$this->insert('{{%county}}',['code'=>'28','name'=>'Mombasa County']);
//$this->insert('{{%county}}',['code'=>'29','name'=>'Murangâ€™a County']);
//$this->insert('{{%county}}',['code'=>'30','name'=>'Nairobi County']);
//$this->insert('{{%county}}',['code'=>'31','name'=>'Nakuru County']);
//$this->insert('{{%county}}',['code'=>'32','name'=>'Nandi County']);
//$this->insert('{{%county}}',['code'=>'33','name'=>'Narok County']);
//$this->insert('{{%county}}',['code'=>'34','name'=>'Nyamira County']);
//$this->insert('{{%county}}',['code'=>'35','name'=>'Nyandarua County']);
//$this->insert('{{%county}}',['code'=>'36','name'=>'Nyeri County']);
//$this->insert('{{%county}}',['code'=>'37','name'=>'Samburu County']);
//$this->insert('{{%county}}',['code'=>'38','name'=>'Siaya County']);
//$this->insert('{{%county}}',['code'=>'39','name'=>'Taita Taveta County']);
//$this->insert('{{%county}}',['code'=>'40','name'=>'Tana River County']);
//$this->insert('{{%county}}',['code'=>'41','name'=>'Tharaka Nithi County']);
//$this->insert('{{%county}}',['code'=>'42','name'=>'Trans Nzoia County']);
//$this->insert('{{%county}}',['code'=>'43','name'=>'Turkana County']);
//$this->insert('{{%county}}',['code'=>'44','name'=>'Uasin Gishu County']);
//$this->insert('{{%county}}',['code'=>'45','name'=>'Vihiga County']);
//$this->insert('{{%county}}',['code'=>'46','name'=>'Wajir County']);
//$this->insert('{{%county}}',['code'=>'47','name'=>'West Pokot County']);
//$this->insert('{{%currency}}',['currencyid'=>'1','currencyname'=>'Kenya Shilling','currencysymbol'=>'KSH','exchangerate'=>'1.00','ishomecurrency'=>'1']);
//$this->insert('{{%currency}}',['currencyid'=>'2','currencyname'=>'US Dollar','currencysymbol'=>'USD','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%currency}}',['currencyid'=>'3','currencyname'=>'Euro','currencysymbol'=>'Euro','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%currency}}',['currencyid'=>'4','currencyname'=>'Sterling Pound','currencysymbol'=>'GBP','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%currency}}',['currencyid'=>'5','currencyname'=>'Tanzania Shilling','currencysymbol'=>'TSH','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%currency}}',['currencyid'=>'6','currencyname'=>'Uganda Shilling','currencysymbol'=>'USH','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%currency}}',['currencyid'=>'7','currencyname'=>'Dirham','currencysymbol'=>'AED','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%currency}}',['currencyid'=>'8','currencyname'=>'Rwandan Franc','currencysymbol'=>'RWF','exchangerate'=>'0.00','ishomecurrency'=>'0']);
//$this->insert('{{%interestmethod}}',['id'=>'1','name'=>'Reducing Balance Method','calculation'=>'1']);
//$this->insert('{{%interestmethod}}',['id'=>'2','name'=>'Straight Line Method','calculation'=>'2']);
//$this->insert('{{%taxrates}}',['taxratecode'=>'A','taxratename'=>'Standard VAT Input/Output','invat'=>'10.00','outvat'=>'16.00','rates'=>'16.0','glaccountno'=>'10100']);
//$this->insert('{{%taxrates}}',['taxratecode'=>'E','taxratename'=>'Exempted','invat'=>'0.00','outvat'=>'0.00','rates'=>'0.00','glaccountno'=>'23100']);
//$this->insert('{{%taxrates}}',['taxratecode'=>'F','taxratename'=>'Fax','invat'=>'0.00','outvat'=>'10.00','rates'=>'10','glaccountno'=>'10000']);
//$this->insert('{{%taxrates}}',['taxratecode'=>'S','taxratename'=>'Catering Levy','invat'=>'2.00','outvat'=>'2.00','rates'=>'2.0','glaccountno'=>'11400']);
//$this->insert('{{%taxrates}}',['taxratecode'=>'Z','taxratename'=>'Zero Rated','invat'=>'0.00','outvat'=>'0.00','rates'=>'0.00','glaccountno'=>'23100']);
//$this->insert('{{%accessibilitymethods}}',['id'=>'1','method'=>'Lift/Stairs']);
//$this->insert('{{%depreciationmethod}}',['id'=>'1','name'=>'Reducing Balance Method','calculation'=>'1']);
//$this->insert('{{%depreciationmethod}}',['id'=>'2','name'=>'Straight Line Method','calculation'=>'2']);
//$this->insert('{{%idtypes}}',['id'=>'1','idtypename'=>'National ID']);
//$this->insert('{{%billingcontrol}}',['lastbilldate'=>'2016-07-15','billmonth'=>'','buildingid'=>'','buildingid2'=>'1','billmonth2'=>'07/2016','id'=>'1']);
//$this->insert('{{%billableitems}}',['itemid'=>'1','itemname'=>'Electricity','rate'=>'5000.0','glaccountno'=>'10000']);
//$this->insert('{{%expensetype}}',['code'=>'1','typename'=>'Accommodation Rent','glaccountnumber'=>'70001','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'2','typename'=>'Accommodation Utilities','glaccountnumber'=>'70002','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'3','typename'=>'Accrued Leave','glaccountnumber'=>'70003','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'4','typename'=>'Advertising Expenses','glaccountnumber'=>'70004','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'5','typename'=>'Air Travel Expense (International)','glaccountnumber'=>'70005','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'6','typename'=>'Air Travel Expense (National)','glaccountnumber'=>'70006','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'7','typename'=>'Aircraft Sub-Charter Expenses','glaccountnumber'=>'70007','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'8','typename'=>'Audit And Taxation Fees','glaccountnumber'=>'70008','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'9','typename'=>'Bank Charges','glaccountnumber'=>'70009','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'10','typename'=>'Casual Staff','glaccountnumber'=>'70010','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'11','typename'=>'Commissary','glaccountnumber'=>'70011','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'12','typename'=>'Contributions And Donations','glaccountnumber'=>'70012','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'13','typename'=>'Credit Charges (Late Payments)','glaccountnumber'=>'70013','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'14','typename'=>'Data Processing Expenses','glaccountnumber'=>'70014','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'15','typename'=>'Depreciation - Aircraft','glaccountnumber'=>'70015','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'16','typename'=>'Depreciation - Computers','glaccountnumber'=>'70016','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'17','typename'=>'Depreciation - Furniture And Fittings','glaccountnumber'=>'70017','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'18','typename'=>'Depreciation - Maint Equipment and Tools','glaccountnumber'=>'70018','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'19','typename'=>'Depreciation - Motor Vehicles','glaccountnumber'=>'70019','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'20','typename'=>'Depreciation - Radio Equipment','glaccountnumber'=>'70020','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'21','typename'=>'Depreciation - Software','glaccountnumber'=>'70021','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'22','typename'=>'Description','glaccountnumber'=>'70022','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'23','typename'=>'Email And Internet Expenses','glaccountnumber'=>'70023','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'24','typename'=>'Engineering Consultants','glaccountnumber'=>'70024','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'25','typename'=>'Engineering Medical Expenses','glaccountnumber'=>'70025','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'26','typename'=>'Engineering Salaries And Wages','glaccountnumber'=>'70026','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'27','typename'=>'Engineering Staff Sundry Costs','glaccountnumber'=>'70027','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'28','typename'=>'Engineering Training','glaccountnumber'=>'70028','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'29','typename'=>'Entertainment','glaccountnumber'=>'70029','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'30','typename'=>'Executive Salaries And Wages','glaccountnumber'=>'70030','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'31','typename'=>'Finance and Admin Medical Expenses','glaccountnumber'=>'70031','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'32','typename'=>'Finance and Admin Salaries and Wages','glaccountnumber'=>'70032','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'33','typename'=>'Finance and Admin Staff Training','glaccountnumber'=>'70033','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'34','typename'=>'Finance And Administration Consultants','glaccountnumber'=>'70034','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'35','typename'=>'Finance And Administration Sundry Costs','glaccountnumber'=>'70035','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'36','typename'=>'General Insurance','glaccountnumber'=>'70036','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'37','typename'=>'General Licences','glaccountnumber'=>'70037','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'38','typename'=>'Hiring Fees','glaccountnumber'=>'70038','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'39','typename'=>'Hotel Accommodation And Subsistense','glaccountnumber'=>'70039','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'40','typename'=>'Household Equipment (Non-Capital)','glaccountnumber'=>'70040','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'41','typename'=>'Household Supplies','glaccountnumber'=>'70041','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'42','typename'=>'Interest On Loan','glaccountnumber'=>'70042','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'43','typename'=>'Land Travel','glaccountnumber'=>'70043','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'44','typename'=>'Legal Fees','glaccountnumber'=>'70044','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'45','typename'=>'Mobile Phone Expenses','glaccountnumber'=>'70045','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'46','typename'=>'Motor Vehicle  Insurance And Licences','glaccountnumber'=>'70046','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'47','typename'=>'Motor Vehicle Fuel And Lubricants','glaccountnumber'=>'70047','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'48','typename'=>'Motor Vehicle Other Expenses','glaccountnumber'=>'70048','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'49','typename'=>'Motor Vehicle Repairs And Maintenance','glaccountnumber'=>'70049','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'50','typename'=>'Office Equipment Repairs And Maintenance','glaccountnumber'=>'70050','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'51','typename'=>'Office Rent','glaccountnumber'=>'70051','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'52','typename'=>'Office Repairs And Maintenance','glaccountnumber'=>'70052','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'53','typename'=>'Office Utilities','glaccountnumber'=>'70053','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'54','typename'=>'Operations Consultants','glaccountnumber'=>'70054','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'55','typename'=>'Operations Salaries And Wages','glaccountnumber'=>'70055','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'56','typename'=>'Operations Staff Medical Expenses','glaccountnumber'=>'70056','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'57','typename'=>'Operations Staff Sundry Costs','glaccountnumber'=>'70057','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'58','typename'=>'Operations Staff Training','glaccountnumber'=>'70058','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'59','typename'=>'Operations Staff Uniforms','glaccountnumber'=>'70059','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'60','typename'=>'Other Professional Fees','glaccountnumber'=>'70060','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'61','typename'=>'Outstation Office Rent','glaccountnumber'=>'70061','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'62','typename'=>'Outstation Office Sundry Expenses','glaccountnumber'=>'70062','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'63','typename'=>'Outstation Staff Salaries And Wages','glaccountnumber'=>'70063','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'64','typename'=>'Postage And Courier Expenses','glaccountnumber'=>'70064','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'65','typename'=>'Pre-Operation Costs','glaccountnumber'=>'70065','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'66','typename'=>'Printing And Stationery','glaccountnumber'=>'70066','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'67','typename'=>'Profit','glaccountnumber'=>'70067','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'68','typename'=>'Profit and Loss','glaccountnumber'=>'70068','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'69','typename'=>'Promotional Expenses','glaccountnumber'=>'70069','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'70','typename'=>'Route Costs','glaccountnumber'=>'70070','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'71','typename'=>'Sales ,Marketing and Reservations Sundry','glaccountnumber'=>'70071','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'72','typename'=>'Sales, Marketing and Res Consultants','glaccountnumber'=>'70072','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'73','typename'=>'Sales, Marketing and Reservations Medical','glaccountnumber'=>'70073','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'74','typename'=>'Sales, Marketing and Reservations Wages','glaccountnumber'=>'70074','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'75','typename'=>'Sales. Marketing and Reservations Uniforms','glaccountnumber'=>'70075','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'76','typename'=>'Security Expenses','glaccountnumber'=>'70076','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'77','typename'=>'Security Staff Salaries And Wages','glaccountnumber'=>'70077','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'78','typename'=>'Sundry Expenses','glaccountnumber'=>'70078','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'79','typename'=>'Sundry Sales And Marketing','glaccountnumber'=>'70079','taxratecode'=>'E']);
//$this->insert('{{%expensetype}}',['code'=>'80','typename'=>'Telephone And Fax Expenses','glaccountnumber'=>'70080','taxratecode'=>'E']);
//$this->insert('{{%customer}}',['custcode'=>'C001','name'=>'Cash Sales A/C','phone'=>'','email'=>'','national_id'=>'','postaladdress'=>'','mobilephone'=>'','location'=>'','isactive'=>'0','balancebf'=>'0.00','salesamt'=>'0.00','salesreturnsamt'=>'0.00','orderbalance'=>'0.00','saleorders'=>'0.00','paymentamt'=>'0.00','adjustments'=>'0.00','balance'=>'0.00','creditstatus'=>'No','creditlimit'=>'0.00','town'=>'','website'=>'','contactperson'=>'','pinnumber'=>'','datecreated'=>'','glaccountno'=>'','glaccountreceivable'=>'11000','glcustomerdeposits'=>'24400','iscontract'=>'','contractperiods'=>'','contractamount'=>'','id'=>'1','headoffice'=>'0','deptcode'=>'0','custtype'=>'0','regionid'=>'0','nextinvoicedate'=>'','lastinvoicedate'=>'','productcode'=>'','intervalperiod'=>'0','vatnumber'=>'0','idnumber'=>'0']);
//$this->insert('{{%customer}}',['custcode'=>'H001','name'=>'Head Office','phone'=>'','email'=>'','national_id'=>'','postaladdress'=>'','mobilephone'=>'','location'=>'null','isactive'=>'0','balancebf'=>'0.00','salesamt'=>'0.00','salesreturnsamt'=>'0.00','orderbalance'=>'0.00','saleorders'=>'0.00','paymentamt'=>'0.00','adjustments'=>'0.00','balance'=>'0.00','creditstatus'=>'','creditlimit'=>'0.00','town'=>'','website'=>'','contactperson'=>'','pinnumber'=>'','datecreated'=>'2016-07-15','glaccountno'=>'','glaccountreceivable'=>'11100','glcustomerdeposits'=>'23000','iscontract'=>'','contractperiods'=>'','contractamount'=>'','id'=>'2','headoffice'=>'H001','deptcode'=>'0','custtype'=>'1','regionid'=>'0','nextinvoicedate'=>'','lastinvoicedate'=>'','productcode'=>'','intervalperiod'=>'0','vatnumber'=>'','idnumber'=>'']);
//$this->insert('{{%titles}}',['id'=>'4','name'=>'Dr']);
//$this->insert('{{%titles}}',['id'=>'7','name'=>'Hon']);
//$this->insert('{{%titles}}',['id'=>'3','name'=>'Miss']);
//$this->insert('{{%titles}}',['id'=>'1','name'=>'Mr']);
//$this->insert('{{%titles}}',['id'=>'2','name'=>'Mrs']);
//$this->insert('{{%titles}}',['id'=>'5','name'=>'Prof']);
//$this->insert('{{%titles}}',['id'=>'6','name'=>'Rev']);
//$this->insert('{{%paymentmethod}}',['id'=>'1','name'=>'Cash','glaccountno'=>'10100']);
//$this->insert('{{%paymentmethod}}',['id'=>'2','name'=>'Bank','glaccountno'=>'0']);
//$this->insert('{{%paymentmethod}}',['id'=>'3','name'=>'ETF','glaccountno'=>'0']);
//$this->insert('{{%paymentmethod}}',['id'=>'4','name'=>'MPESA','glaccountno'=>'0']);
//$this->insert('{{%paymentmethod}}',['id'=>'5','name'=>'YU CASH','glaccountno'=>'0']);
//$this->insert('{{%paymentmethod}}',['id'=>'6','name'=>'ORANGE MONEY','glaccountno'=>'0']);
//$this->insert('{{%paymentmethod}}',['id'=>'7','name'=>'ZAP','glaccountno'=>'0']);
//$this->insert('{{%paymentmethod}}',['id'=>'8','name'=>'Merchant Cards','glaccountno'=>'10100']);
//$this->insert('{{%country}}',['countrycode'=>'+211','countryname'=>'Southern Sudan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AD','countryname'=>'Andorra','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AE','countryname'=>'United Arab Emirates','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AF','countryname'=>'Afghanistan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AG','countryname'=>'Antigua and Barbuda','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AI','countryname'=>'Anguilla','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AL','countryname'=>'Albania','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AM','countryname'=>'Armenia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AN','countryname'=>'Netherlands Antilles','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AO','countryname'=>'Angola','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AQ','countryname'=>'Antarctica','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AR','countryname'=>'Argentina','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AS','countryname'=>'American Samoa','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AT','countryname'=>'Austria','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AU','countryname'=>'Australia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AW','countryname'=>'Aruba','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AX','countryname'=>'??land Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'AZ','countryname'=>'Azerbaijan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BA','countryname'=>'Bosnia and Herzegovina','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BB','countryname'=>'Emrysdos','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BD','countryname'=>'Bangladesh','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BE','countryname'=>'Belgium','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BF','countryname'=>'Burkina Faso','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BG','countryname'=>'Bulgaria','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BH','countryname'=>'Bahrain','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BI','countryname'=>'Burundi','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BJ','countryname'=>'Benin','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BL','countryname'=>'Saint BarthÃƒÂ©lemy','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BM','countryname'=>'Bermuda','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BN','countryname'=>'Brunei Darussalam','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BO','countryname'=>'Bolivia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BR','countryname'=>'Brazil','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BS','countryname'=>'Bahamas','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BT','countryname'=>'Bhutan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BV','countryname'=>'Bouvet Island','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BW','countryname'=>'Botswana','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BY','countryname'=>'Belarus','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'BZ','countryname'=>'Belize','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CA','countryname'=>'Canada','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CC','countryname'=>'Cocos (Keeling) Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CD','countryname'=>'Congo, The Democratic Republic of the','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CF','countryname'=>'Central African Republic','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CG','countryname'=>'Congo','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CH','countryname'=>'Switzerland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CI','countryname'=>'CÃƒÂ´te D Ivoire','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CK','countryname'=>'Cook Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CL','countryname'=>'Chile','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CM','countryname'=>'Cameroon','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CN','countryname'=>'China','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CO','countryname'=>'Colombia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CR','countryname'=>'Costa Rica','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CU','countryname'=>'Cuba','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CV','countryname'=>'Cape Verde','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CX','countryname'=>'Christmas Island','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CY','countryname'=>'Cyprus','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'CZ','countryname'=>'Czech Republic','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'DE','countryname'=>'Germany','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'DJ','countryname'=>'Djibouti','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'DK','countryname'=>'Denmark','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'DM','countryname'=>'Dominica','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'DO','countryname'=>'Dominican Republic','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'DZ','countryname'=>'Algeria','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'EC','countryname'=>'Ecuador','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'EE','countryname'=>'Estonia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'EG','countryname'=>'Egypt','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'EH','countryname'=>'Western Sahara','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ER','countryname'=>'Eritrea','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ES','countryname'=>'Spain','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ET','countryname'=>'Ethiopia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'FI','countryname'=>'Finland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'FJ','countryname'=>'Fiji','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'FK','countryname'=>'Falkland Islands (Malvinas)','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'FM','countryname'=>'Micronesia, Federated States of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'FO','countryname'=>'Faroe Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'FR','countryname'=>'France','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GA','countryname'=>'Gabon','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GB','countryname'=>'United Kingdom','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GD','countryname'=>'Grenada','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GE','countryname'=>'Georgia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GF','countryname'=>'French Guiana','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GG','countryname'=>'Guernsey','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GH','countryname'=>'Ghana','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GI','countryname'=>'Gibraltar','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GL','countryname'=>'Greenland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GM','countryname'=>'Gambia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GN','countryname'=>'Guinea','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GP','countryname'=>'Guadeloupe','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GQ','countryname'=>'Equatorial Guinea','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GR','countryname'=>'Greece','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GS','countryname'=>'South Georgia and the South Sandwich Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GT','countryname'=>'Guatemala','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GU','countryname'=>'Guam','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GW','countryname'=>'Guinea-Bissau','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'GY','countryname'=>'Guyana','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'HK','countryname'=>'Hong Kong','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'HM','countryname'=>'Heard Island and McDonald Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'HN','countryname'=>'Honduras','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'HR','countryname'=>'Croatia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'HT','countryname'=>'Haiti','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'HU','countryname'=>'Hungary','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ID','countryname'=>'Indonesia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IE','countryname'=>'Ireland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IL','countryname'=>'Israel','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IM','countryname'=>'Isle of Man','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IN','countryname'=>'India','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IO','countryname'=>'British Indian Ocean Territory','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IQ','countryname'=>'Iraq','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IR','countryname'=>'Iran, Islamic Republic of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IS','countryname'=>'Iceland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'IT','countryname'=>'Italy','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'JE','countryname'=>'Jersey','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'JM','countryname'=>'Jamaica','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'JO','countryname'=>'Jordan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'JP','countryname'=>'Japan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KE','countryname'=>'Kenya','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KG','countryname'=>'Kyrgyzstan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KH','countryname'=>'Cambodia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KI','countryname'=>'Kiribati','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KM','countryname'=>'Comoros','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KN','countryname'=>'Saint Kitts and Nevis','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KP','countryname'=>'Korea, Democratic Peoples Republic of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KR','countryname'=>'Korea, Republic of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KW','countryname'=>'Kuwait','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KY','countryname'=>'Cayman Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'KZ','countryname'=>'Kazakhstan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LA','countryname'=>'Lao Peoples Democratic Republic','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LB','countryname'=>'Lebanon','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LC','countryname'=>'Saint Lucia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LI','countryname'=>'Liechtenstein','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LK','countryname'=>'Sri Lanka','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LR','countryname'=>'Liberia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LS','countryname'=>'Lesotho','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LT','countryname'=>'Lithuania','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LU','countryname'=>'Luxembourg','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LV','countryname'=>'Latvia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'LY','countryname'=>'Libyan Arab Jamahiriya','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MA','countryname'=>'Morocco','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MC','countryname'=>'Monaco','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MD','countryname'=>'Moldova, Republic of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ME','countryname'=>'Montenegro','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MF','countryname'=>'Saint Martin','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MG','countryname'=>'Madagascar','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MH','countryname'=>'Marshall Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MK','countryname'=>'Macedonia, The Former Yugoslav Republic of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ML','countryname'=>'Mali','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MM','countryname'=>'Myanmar','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MN','countryname'=>'Mongolia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MO','countryname'=>'Macao','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MP','countryname'=>'Northern Mariana Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MQ','countryname'=>'Martinique','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MR','countryname'=>'Mauritania','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MS','countryname'=>'Montserrat','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MT','countryname'=>'Malta','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MU','countryname'=>'Mauritius','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MV','countryname'=>'Maldives','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MW','countryname'=>'Malawi','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MX','countryname'=>'Mexico','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MY','countryname'=>'Malaysia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'MZ','countryname'=>'Mozambique','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NA','countryname'=>'Namibia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NC','countryname'=>'New Caledonia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NE','countryname'=>'Niger','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NF','countryname'=>'Norfolk Island','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NG','countryname'=>'Nigeria','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NI','countryname'=>'Nicaragua','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NL','countryname'=>'Netherlands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NO','countryname'=>'Norway','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NP','countryname'=>'Nepal','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NR','countryname'=>'Nauru','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NU','countryname'=>'Niue','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'NZ','countryname'=>'New Zealand','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'OM','countryname'=>'Oman','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PA','countryname'=>'Panama','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PE','countryname'=>'Peru','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PF','countryname'=>'French Polynesia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PG','countryname'=>'Papua New Guinea','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PH','countryname'=>'Philippines','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PK','countryname'=>'Pakistan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PL','countryname'=>'Poland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PM','countryname'=>'Saint Pierre and Miquelon','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PN','countryname'=>'Pitcairn','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PR','countryname'=>'Puerto Rico','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PS','countryname'=>'Palestinian Territory, Occupied','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PT','countryname'=>'Portugal','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PW','countryname'=>'Palau','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'PY','countryname'=>'Paraguay','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'QA','countryname'=>'Qatar','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'RE','countryname'=>'Reunion','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'RO','countryname'=>'Romania','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'RS','countryname'=>'Serbia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'RU','countryname'=>'Russian Federation','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'RW','countryname'=>'Rwanda','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SA','countryname'=>'Saudi Arabia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SB','countryname'=>'Solomon Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SC','countryname'=>'Seychelles','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SD','countryname'=>'Sudan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SE','countryname'=>'Sweden','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SG','countryname'=>'Singapore','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SH','countryname'=>'Saint Helena','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SI','countryname'=>'Slovenia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SJ','countryname'=>'Svalbard and Jan Mayen','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SK','countryname'=>'Slovakia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SL','countryname'=>'Sierra Leone','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SM','countryname'=>'San Marino','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SN','countryname'=>'Senegal','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SO','countryname'=>'Somalia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SR','countryname'=>'Suriname','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ST','countryname'=>'Sao Tome and Principe','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SV','countryname'=>'El Salvador','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SY','countryname'=>'Syrian Arab Republic','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'SZ','countryname'=>'Swaziland','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TC','countryname'=>'Turks and Caicos Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TD','countryname'=>'Chad','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TF','countryname'=>'French Southern Territories','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TG','countryname'=>'Togo','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TH','countryname'=>'Thailand','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TJ','countryname'=>'Tajikistan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TK','countryname'=>'Tokelau','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TL','countryname'=>'Timor-Leste','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TM','countryname'=>'Turkmenistan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TN','countryname'=>'Tunisia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TO','countryname'=>'Tonga','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TR','countryname'=>'Turkey','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TT','countryname'=>'Trinidad and Tobago','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TV','countryname'=>'Tuvalu','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TW','countryname'=>'Taiwan, Province Of China','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'TZ','countryname'=>'Tanzania, United Republic of','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'UA','countryname'=>'Ukraine','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'UG','countryname'=>'Uganda','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'UM','countryname'=>'United States Minor Outlying Islands','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'US','countryname'=>'United States','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'UY','countryname'=>'Uruguay','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'UZ','countryname'=>'Uzbekistan','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VA','countryname'=>'Holy See (Vatican City State)','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VC','countryname'=>'Saint Vincent and the Grenadines','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VE','countryname'=>'Venezuela','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VG','countryname'=>'Virgin Islands, British','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VI','countryname'=>'Virgin Islands, U.S.','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VN','countryname'=>'Viet Nam','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'VU','countryname'=>'Vanuatu','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'WF','countryname'=>'Wallis And Futuna','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'WS','countryname'=>'Samoa','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'YE','countryname'=>'Yemen','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'YT','countryname'=>'Mayotte','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ZA','countryname'=>'South Africa','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ZM','countryname'=>'Zambia','nationality'=>'']);
//$this->insert('{{%country}}',['countrycode'=>'ZW','countryname'=>'Zimbabwe','nationality'=>'']);
//$this->execute('SET foreign_key_checks = 1;');
//
    }

    public function down() {
        echo "m160715_114733_nyuba cannot be reverted.\n";

        return false;
    }

    /*
      // Use safeUp/safeDown to run migration code within a transaction
      public function safeUp()
      {
      }

      public function safeDown()
      {
      }
     */
}
